---
name: feedback
description: File a GitHub issue against gim-home/PraestoClaw with logs, environment, and recent conversation when the user reports a problem with PraestoClaw itself
metadata:
  activation:
    keywords: [feedback, 反馈, report bug, 报告问题, file issue, 提 issue, /feedback, praestoclaw bug]
    patterns:
      - "(?i)^/feedback\\b"
      - "(?i)\\b(file|report|submit|open)\\s+(a\\s+)?(bug|issue|feedback)\\b"
      - "(?i)(报告|反馈|提交|提个).*?(问题|bug|issue)"
---

# Feedback Assistant

Help the user file a GitHub issue against `gim-home/PraestoClaw` when they hit a bug or rough edge in PraestoClaw itself.

## When to use

- The user said `/feedback ...`
- The user expressed frustration about PraestoClaw's behavior and asked to report it (e.g. "this is broken, file a bug", "帮我反馈一下")
- The user explicitly asked to open an issue against the PraestoClaw repo

**Do NOT use** for:
- Bugs in the user's own code (use `bug-investigate` instead)
- Feature requests in third-party tools / MCP servers (those have their own repos)
- Generic Q&A about how PraestoClaw works (just answer)

## Workflow

This is a **two-turn** flow. Never submit on the first turn — always preview the draft and wait for the user to confirm.

### Two separate artifacts — keep them separate

Throughout this skill you maintain **two** versions of the issue content:

1. **Full body** — the raw, complete content that will be submitted to GitHub. Contains the **full** sanitized log tail (~200 lines), full recent conversation, full environment block. **Never summarize, paraphrase, or shorten** any field here. This is what a human developer will use to debug.
2. **Preview** — a chat-friendly rendering shown to the user for confirmation. Logs and conversation may be collapsed for readability (see step 6).

**Critical**: when the user confirms in Turn 2, you submit the **full body**, not the preview. Write the full body to the temp file used by `gh issue create`. Do not regenerate or re-summarize the content at submit time — that's how data drifts between what the user approved and what got filed.

Recommended approach: build the full body string first (steps 1–5), then derive the preview from it (step 6). Keep both in mind for Turn 2.

### Image attachments (screenshots from Teams)

The agent runtime cannot see image bytes — there's no multimodal pipeline. But when the user pasted screenshots, the gateway uploaded them to a public image host on ingest and the **URLs are already in your prompt** under an `[attachments: N image(s)...]` block, one URL per line.

Treat the attachments as ordinary content: for each URL, append `![screenshot N](url)` to the **full body** under a new `## Screenshots` section, render the same section in the preview (so the user can see the images they're filing), and proceed with the normal Turn 1 → Turn 2 confirmation flow below. No special opt-in keyword is required.

If the attachments block reports upload failures (e.g. `(1 upload(s) failed)`), include a `_screenshot N: upload failed at gateway_` note in the body so the developer sees the context exists, and on Turn 2 use step 8c (`--web`) so the user can drag the missing screenshots into the browser issue form.

### Turn 1 — Gather context and show the draft

1. **Read the user's complaint** from the current message (everything after `/feedback`, or the natural-language description). If the description is empty or just `/feedback`, ask one short follow-up: "What's the issue you'd like to report?" and stop.

2. **Collect environment** in parallel where possible:
   - `praestoclaw version` — version string
   - `python --version` and `uname -srm` (or `ver` on Windows) — OS / Python
   - `pwd` — current working directory
   - List active MCP servers and loaded skills from the **current conversation context** (you already know them — no extra tool call needed)

3. **Collect log tail**:
   ```bash
   praestoclaw logs -n 200
   ```
   If this prints "No log file configured" or "Log file not found", note it as `_log unavailable_` in the draft instead of failing.

4. **Sanitize before showing the draft.** Apply these substitutions to log tail and recent-conversation text:
   - Home directory paths → `~` (e.g. `/Users/alice/foo` → `/Users/~/foo`, `C:\Users\bob\…` → `C:\Users\~\…`)
   - Email / UPN addresses → `[email]`
   - Anything that looks like a token, key, or secret → `[redacted]` (the platform's leak detector will also scrub tool output, but be defensive in what you put in the issue body)

   Credential redaction is automatic on tool output; the items above are your responsibility because they come from filesystem paths and conversation text.

5. **Generate a title**: `[Feedback] <≤80 char summary>`. Imperative, specific, no trailing punctuation.
   - Good: `[Feedback] Agent drops attachments larger than 5MB silently`
   - Bad: `[Feedback] something broken`

6. **Show the draft to the user** as a chat reply. The preview is a **rendering** of the full body — it must show enough that the user knows what they're agreeing to submit, but logs can be visually collapsed.

   Format:

   ```markdown
   **Preview — issue to be filed at `gim-home/PraestoClaw`**

   **Title:** <generated title>
   **Labels:** feedback, user-report

   ---
   ## Description
   <full description from the full body — do NOT shorten>

   ## Environment
   - OS: <os>
   - Python: <python version>
   - PraestoClaw: <version>
   - Channel: <cli | teams | webchat | cloud>
   - CWD: <sanitized cwd>
   - MCP servers (<n>): <comma-separated names>
   - Skills loaded (<n>): <comma-separated names>

   ## Recent log tail
   _<N> lines collected (showing first 5 + last 5 below; full log will be in the issue)_
   ```
   <first 5 sanitized log lines>
   ...
   <last 5 sanitized log lines>
   ```

   ## Recent conversation
   **user**: <message, truncated to ~300 chars in the preview only>
   **assistant**: <message, truncated to ~300 chars in the preview only>
   ... (last ~10 turns, sanitized, tool calls folded as `[tool: name1, name2]`)
   ---

   Reply "好的 / 提交吧 / yes" to file it, or "算了 / 改一下" to cancel.
   You can also paste a new description and I'll redo the draft.
   ```

   The **only** parts that get visually compressed in the preview are:
   - Log tail: show first 5 + last 5 lines + a line count, **but keep all 200 lines in the full body**
   - Per-message truncation in "Recent conversation": ~300 chars in preview, ~600 chars in full body

   Everything else (title, labels, description, environment, MCP/skill lists) is identical between preview and full body.

7. **Stop.** Do not run `gh` yet. Wait for the user's next message.

### Turn 2 — Interpret confirmation and submit

The user's next message tells you what to do. Use the conversation context (you remember the draft you just showed) to classify their intent:

| Intent | Examples | Action |
|---|---|---|
| **submit** | "yes", "好", "好的", "提交吧", "go", "ok", "嗯", "没问题", "确认" | Run the `gh` command in step 8 |
| **cancel** | "算了", "别提了", "我再想想", "先别提", "重新来" alone | Reply "Canceled. Run `/feedback ...` any time to start over." and stop |
| **restart** | A fresh problem description ("补充一下，附件大小超过 5MB 时才出现", "换个角度…") | Treat as a new Turn 1 — regenerate the draft using the new description, keep environment/log/conversation as-is |
| **other** | Anything off-topic (user changed subject) | Drop the pending draft silently and respond to whatever they actually asked |

**Fail-safe**: if you're not sure, treat as `cancel` — never submit on ambiguous input. The cost of a missed submission is "user says yes again"; the cost of a wrong submission is a public, unredactable issue on the repo.

### 8. Submit (only on `submit` intent)

Filing an issue is a write action — the standard approval pipeline will show the user an Adaptive Card / CLI prompt before `gh` actually runs. That is the second checkpoint; trust it, don't try to add your own.

Go to step 8a by default. Use step 8c (`--web`) only if `gh` is not installed, or as the fall-through when the gateway reported per-image upload errors.

#### 8a. Submit headlessly with `gh issue create`

Write **the full body** (not the preview rendering) to a temp file first. The full body contains all ~200 log lines, untruncated conversation turns, and — when screenshots were attached — a `## Screenshots` section with `![screenshot N](url)` lines. Then:

```bash
# Write the FULL body (not the preview) to a temp file
cat > /tmp/praestoclaw-feedback-$$.md <<'BODY_EOF'
<the full sanitized body — all 200 log lines, full conversation, optional ## Screenshots>
BODY_EOF

gh issue create \
  --repo gim-home/PraestoClaw \
  --title "<title from preview>" \
  --body-file /tmp/praestoclaw-feedback-$$.md \
  --label feedback,user-report
```

The command prints the new issue URL on success. Reply to the user:

```
✅ Submitted: <url>
```

Then delete the temp file (`rm /tmp/praestoclaw-feedback-$$.md`).

#### 8c. Fallback — `gh` not installed, or image uploads failed

Two entry conditions:

- **`gh` is missing or `gh auth status` fails** → predominantly a fresh-install case. Build a pre-filled URL and ask the user to open it in a browser.
- **Screenshots were attached but the gateway reported upload errors** (and `gh` is available) → run `gh issue create --web` so the pre-filled new-issue page opens in their browser and they can drag-drop the screenshots.

**Path 1 — `gh` available, image upload failed → `--web`:**

```bash
cat > /tmp/praestoclaw-feedback-$$.md <<'BODY_EOF'
<full sanitized body — include a note "Screenshots: upload failed, please drag attachments here">
BODY_EOF

gh issue create \
  --repo gim-home/PraestoClaw \
  --title "<title from preview>" \
  --body-file /tmp/praestoclaw-feedback-$$.md \
  --label feedback,user-report \
  --web
```

Reply:

```
🌐 Image upload unavailable — opened the pre-filled issue in your browser. Drag your screenshots into the body and click Submit.
```

Then delete the temp file.

**Path 2 — `gh` unavailable → pre-filled URL:**

Build a URL the user can open manually:

```
https://github.com/gim-home/PraestoClaw/issues/new?title=<urlencoded title>&body=<urlencoded body>&labels=feedback,user-report
```

GitHub's URL length is roughly capped around 8KB. If your URL exceeds ~6500 chars, truncate the **end of the body** and append `_[truncated — paste the rest from your local log]_` before urlencoding. Reply:

```
`gh` CLI unavailable — open this URL in your browser to file the issue:
<url>
```

## Safety boundaries

- **Never submit without an explicit confirmation turn.** Even if the user says `/feedback yes please file this immediately`, still show the draft and wait. Filing a public issue is irreversible.
- **Never include unredacted home-directory paths or emails** in the body. If you're unsure whether a string is sensitive, redact it.
- **Never use `--no-edit` with `gh issue create`** — it bypasses behavior we rely on. (`--web` IS allowed, but only in step 8c.)
- **Do not pre-fill the user's GitHub username, org membership, or any identifier they didn't explicitly volunteer.**

## Pitfalls

- **Don't submit the preview rendering — submit the full body.** The preview compresses logs (first 5 + last 5) and truncates messages for readability. The issue body must contain all ~200 log lines and full (≤600 char) message turns. When in doubt, re-check: "is the temp file I'm about to pass to `--body-file` the full body, or the chat preview?"
- Don't paste the raw `praestoclaw logs` output without sanitizing — log lines often contain absolute paths under `/Users/<name>` and occasional emails from MCP responses.
- Don't truncate the **middle** of a log; the tail is what matters for debugging. Truncate from the front if needed.
- Don't try to `gh issue create` from the body string directly — large bodies break shell quoting. Always go through `--body-file`.
- Don't auto-attach screenshots or files — out of scope. If the user mentions an attachment, suggest they paste it into the issue after it's filed.
- If the user runs `/feedback` again before confirming the previous draft, treat that as **restart** — replace the pending draft, don't stack them.
