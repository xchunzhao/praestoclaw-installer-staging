"""Agent-Gateway transport ``t.*`` wire frames."""

from __future__ import annotations

import json
from enum import IntEnum
from typing import Annotated, Any, Literal

from pydantic import BaseModel, ConfigDict, Field, TypeAdapter

SUPPORTED_PROTOCOL_VERSION = 1
SUPPORTED_FEATURES = frozenset({"resume", "ack", "server_ping"})
DEFAULT_PING_INTERVAL_MS = 25_000
DEFAULT_PONG_TIMEOUT_MS = 20_000
DEFAULT_RESUME_TTL_MS = 300_000
DEFAULT_MAX_PAYLOAD_BYTES = 1_048_576
DEFAULT_MAX_OUTBOX_BYTES = 1_048_576


class TransportCloseCode(IntEnum):
    NORMAL = 1000
    AUTHENTICATION_FAILED = 1008
    SERVER_INTERNAL_ERROR = 1011
    PROTOCOL_ERROR = 4000
    SEQUENCE_ERROR = 4001
    PAYLOAD_TOO_LARGE = 4002
    HEARTBEAT_TIMEOUT = 4003
    SUPERSEDED = 4004
    RESUME_REJECTED = 4005
    VERSION_UNSUPPORTED = 4006


class TransportProtocolError(Exception):
    """Raised when a transport frame violates the wire contract."""

    def __init__(self, code: int | TransportCloseCode, error_code: str, message: str) -> None:
        super().__init__(message)
        self.close_code = int(code)
        self.error_code = error_code
        self.message = message


class TransportFrame(BaseModel):
    model_config = ConfigDict(extra="ignore")

    type: str


class TransportHelloFrame(TransportFrame):
    type: Literal["t.hello"] = "t.hello"
    protocol_version: int = Field(ge=1)
    min_protocol_version: int | None = Field(default=None, ge=1)
    features: list[str] = Field(default_factory=list)
    session_token: str | None = None
    last_received_seq: int = Field(default=0, ge=0)

    @property
    def effective_min_protocol_version(self) -> int:
        return self.min_protocol_version or self.protocol_version


class TransportWelcomeFrame(TransportFrame):
    type: Literal["t.welcome"] = "t.welcome"
    protocol_version: int
    features: list[str]
    session_id: str
    session_token: str
    connection_epoch: int
    resumed: bool
    resume_failed_reason: str | None = None
    last_received_seq: int
    ping_interval_ms: int
    pong_timeout_ms: int
    resume_ttl_ms: int
    max_payload_bytes: int
    max_outbox_bytes: int


class TransportPingFrame(TransportFrame):
    type: Literal["t.ping"] = "t.ping"


class TransportPongFrame(TransportFrame):
    type: Literal["t.pong"] = "t.pong"


class TransportDataFrame(TransportFrame):
    type: Literal["t.data"] = "t.data"
    seq: int = Field(ge=1)
    payload: Any


class TransportAckFrame(TransportFrame):
    type: Literal["t.ack"] = "t.ack"
    ack: int = Field(ge=0)


class TransportCloseFrame(TransportFrame):
    type: Literal["t.close"] = "t.close"
    code: int = 1000
    reason: str = ""


class TransportErrorFrame(TransportFrame):
    type: Literal["t.error"] = "t.error"
    code: str
    message: str


GatewayInboundTransportFrame = Annotated[
    TransportHelloFrame
    | TransportPongFrame
    | TransportDataFrame
    | TransportAckFrame
    | TransportCloseFrame,
    Field(discriminator="type"),
]

AgentInboundTransportFrame = Annotated[
    TransportWelcomeFrame
    | TransportPingFrame
    | TransportDataFrame
    | TransportAckFrame
    | TransportCloseFrame
    | TransportErrorFrame,
    Field(discriminator="type"),
]

AnyTransportFrame = Annotated[
    TransportHelloFrame
    | TransportWelcomeFrame
    | TransportPingFrame
    | TransportPongFrame
    | TransportDataFrame
    | TransportAckFrame
    | TransportCloseFrame
    | TransportErrorFrame,
    Field(discriminator="type"),
]

_gateway_inbound_adapter: TypeAdapter[GatewayInboundTransportFrame] = TypeAdapter(
    GatewayInboundTransportFrame
)
_agent_inbound_adapter: TypeAdapter[AgentInboundTransportFrame] = TypeAdapter(
    AgentInboundTransportFrame
)
_any_adapter: TypeAdapter[AnyTransportFrame] = TypeAdapter(AnyTransportFrame)


def parse_transport_frame(
    raw: str | bytes,
    *,
    role: Literal["gateway", "agent", "any"] = "gateway",
) -> GatewayInboundTransportFrame | AgentInboundTransportFrame | AnyTransportFrame:
    """Parse and validate a transport frame for the receiving side."""

    if isinstance(raw, bytes):
        try:
            raw = raw.decode("utf-8")
        except UnicodeDecodeError as exc:
            raise TransportProtocolError(
                TransportCloseCode.PROTOCOL_ERROR,
                "invalid_json",
                "transport frame must be UTF-8 text",
            ) from exc
    if not isinstance(raw, str):
        raise TransportProtocolError(
            TransportCloseCode.PROTOCOL_ERROR,
            "invalid_frame",
            "transport frame must be text",
        )
    try:
        data = json.loads(raw)
    except json.JSONDecodeError as exc:
        raise TransportProtocolError(
            TransportCloseCode.PROTOCOL_ERROR,
            "invalid_json",
            "transport frame must be valid JSON",
        ) from exc

    frame_type = data.get("type") if isinstance(data, dict) else None
    if not isinstance(frame_type, str) or not frame_type.startswith("t."):
        raise TransportProtocolError(
            TransportCloseCode.PROTOCOL_ERROR,
            "invalid_frame",
            "transport frame type must begin with t.",
        )

    adapter: TypeAdapter[Any]
    if role == "gateway":
        adapter = _gateway_inbound_adapter
    elif role == "agent":
        adapter = _agent_inbound_adapter
    else:
        adapter = _any_adapter
    try:
        return adapter.validate_python(data)
    except Exception as exc:
        raise TransportProtocolError(
            TransportCloseCode.PROTOCOL_ERROR,
            "invalid_frame",
            "transport frame schema is invalid",
        ) from exc


def encode_transport_frame(frame: TransportFrame | dict[str, Any]) -> str:
    """Serialize a transport frame to compact UTF-8 JSON text."""

    data = frame.model_dump() if isinstance(frame, TransportFrame) else frame
    return json.dumps(data, ensure_ascii=False, separators=(",", ":"))


def encoded_json_size(data: Any) -> int:
    return len(json.dumps(data, separators=(",", ":"), ensure_ascii=False).encode("utf-8"))
