"""Shared A2A protocol contracts."""

__all__ = []
