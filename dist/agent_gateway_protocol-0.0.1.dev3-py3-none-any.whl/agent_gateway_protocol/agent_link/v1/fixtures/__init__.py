"""Packaged Agent Link v1 contract fixtures."""
