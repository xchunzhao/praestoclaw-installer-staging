from __future__ import annotations

from enum import StrEnum
from typing import Any

from pydantic import Field

from agent_gateway_protocol.agent_link.v1._base import AgentLinkModel


class SourceIdentityKind(StrEnum):
    HUMAN = "human"
    AGENT = "agent"
    SCHEDULER = "scheduler"
    SYSTEM = "system"


class InitiatedBy(StrEnum):
    HUMAN = "human"
    AGENT = "agent"
    SCHEDULER = "scheduler"
    SYSTEM = "system"


class SourceIdentity(AgentLinkModel):
    id: str
    kind: SourceIdentityKind
    tenant_id: str | None = None
    display_name: str | None = None
    upn: str | None = None
    aad_object_id: str | None = None
    roles: list[str] = Field(default_factory=list)
    claims: dict[str, Any] = Field(default_factory=dict)


class ConversationIdentity(AgentLinkModel):
    conversation_id: str
    thread_id: str | None = None
    reply_to_id: str | None = None
    chat_kind: str | None = None
    parent_conversation_id: str | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)


class Attachment(AgentLinkModel):
    id: str | None = None
    name: str | None = None
    content_type: str | None = None
    url: str | None = None
    content: dict[str, Any] | None = None
    binary_ref: str | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)


class MessageContent(AgentLinkModel):
    content: str
    content_format: str = "text"
    attachments: list[Attachment] = Field(default_factory=list)
    metadata: dict[str, Any] = Field(default_factory=dict)


class SupervisorRoute(AgentLinkModel):
    mode: str
    logical_channel: str | None = None
    delivery_target: str | None = None
    thread_id: str | None = None
    fallback_routes: list[dict[str, Any]] = Field(default_factory=list)


class SupervisionContext(AgentLinkModel):
    initiated_by: InitiatedBy = InitiatedBy.HUMAN
    human_initiated: bool = True
    requires_human_visibility: bool = False
    notify_on_start: bool = False
    notify_on_finish: bool = False
    notify_on_error: bool = True
    supervisor_route: SupervisorRoute | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)
