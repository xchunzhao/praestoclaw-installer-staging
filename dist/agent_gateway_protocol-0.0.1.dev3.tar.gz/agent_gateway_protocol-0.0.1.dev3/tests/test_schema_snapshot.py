"""Snapshot test: pin the v1 wire shape of every protocol model.

If this test fails, you changed a wire model. Decide:

1. Intended change?
   - Run ``python scripts/dump_schemas.py`` to update the snapshot files.
   - Commit the diff. Reviewers MUST see this diff and ack the wire change.

2. Unintended?
   - Revert the model change.

Run with ``pytest --snapshot-update`` to auto-rewrite the snapshot files in
one step (equivalent to calling ``scripts/dump_schemas.py``).
"""

from __future__ import annotations

import json

import pytest

from scripts.dump_schemas import PACKAGES, SNAPSHOT_DIR, collect_package, write_snapshots


def pytest_addoption(parser):  # type: ignore[no-untyped-def]
    # NOTE: pytest auto-discovers addoption only in conftest.py; this is a
    # no-op when defined here but is kept for documentation. The actual flag
    # is wired in tests/conftest.py.
    pass


@pytest.fixture(scope="session")
def update_snapshots(request: pytest.FixtureRequest) -> bool:
    return bool(request.config.getoption("--snapshot-update", default=False))


@pytest.mark.parametrize("package", PACKAGES, ids=lambda p: p.split(".")[1])
def test_protocol_schema_snapshot(package: str, update_snapshots: bool) -> None:
    short = package.split(".")[1] + "_v1.json"
    snapshot_path = SNAPSHOT_DIR / short

    current = collect_package(package)
    current_text = json.dumps(current, indent=2, sort_keys=True, default=str) + "\n"

    if update_snapshots:
        write_snapshots()
        pytest.skip(f"snapshot updated: {snapshot_path.name}")

    assert snapshot_path.exists(), (
        f"missing snapshot {snapshot_path}; run `python scripts/dump_schemas.py`"
    )
    expected_text = snapshot_path.read_text(encoding="utf-8")

    if current_text != expected_text:
        # Compute a compact diff hint instead of dumping the whole blob.
        expected = json.loads(expected_text)
        added = sorted(set(current) - set(expected))
        removed = sorted(set(expected) - set(current))
        changed = sorted(k for k in (set(current) & set(expected)) if current[k] != expected[k])
        hint = (
            f"snapshot drift in {snapshot_path.name}:\n"
            f"  added:   {added or '-'}\n"
            f"  removed: {removed or '-'}\n"
            f"  changed: {changed or '-'}\n"
            "Run `python scripts/dump_schemas.py` and commit the diff if intended."
        )
        raise AssertionError(hint)
