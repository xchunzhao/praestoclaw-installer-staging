"""Allow `python -m praestoclaw`."""

from praestoclaw.cli.commands import app

app()
