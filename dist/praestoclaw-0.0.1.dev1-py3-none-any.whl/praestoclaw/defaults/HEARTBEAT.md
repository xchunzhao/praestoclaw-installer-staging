# Heartbeat

You are running as a periodic background task (default: every 30 minutes).
A `## Pre-flight` section above tells you which sections to RUN and which to SKIP.
Execute ONLY the RUN sections — do not re-check SKIP conditions.

If no RUN section produces actionable findings, reply with exactly `HEARTBEAT_OK`.

## Update

- Call `check_update()` THIS turn. If the tool is not loaded, run `tools(name="check_update")` first.
- The tool's `summary` is the ONLY source of truth for "current version" and "update available". Do NOT infer version state from MEMORY.md, Recent Activity, HISTORY, or earlier turns — those entries are stale by definition (an upgrade may have happened since they were written).
- If the tool says no update is available, do NOT emit an update notification, even if memory/history suggests one is pending.
- If the tool reports an update, quote the exact `current` and `latest` version strings it returned. Never reconstruct them from prior knowledge.

## Security

- Read `{PraestoClaw_Dir}/MEMORY.md` and scan for secrets. The Pre-flight reason may list specific types found, or indicate a scan error requiring manual review. Remove any secrets you find and include what you removed in the notification.

## User Profile

- Use `list_dir` and `search_files` to detect languages and frameworks in the workspace (look for config files like `package.json`, `requirements.txt`, `Cargo.toml`, `go.mod`, `*.csproj`, etc.). Update `{PraestoClaw_Dir}/USER.md` `## Tech Stack` if changed.
- Run `search_history(query="preferences", after="7d")` → update `## Preferences` with any explicit user preferences found (e.g. communication style, explanation depth, tool choices). Only record what the user stated or confirmed, not inferences.

## Skills

- Use `search_history` to find repeated tasks or workflows. Choose queries based on the workspace context (e.g. common tools, languages, or commands you see in history). Search both recent (`after="2d"`) and all-time.
- Store heartbeat-generated live skills and drafts only under `{PraestoClaw_Dir}/skills/` and `{PraestoClaw_Dir}/skill-draft/`. `{PraestoClaw_Dir}` is the user data directory (normally `~/.praestoclaw`), not the Git workspace.
- Do NOT create, restore, refresh, or modify heartbeat-generated artifacts under workspace customization directories such as `.github/skills/`, `.github/skill-draft/`, `.claude/skills/`, or `.claude/skill-draft/`; those paths are version-controlled project files and would pollute the user's git changes.

**Create** — when the pattern is non-trivial AND meets either threshold:
- 3+ similar operations in the last 2 days, OR
- 5+ similar operations across all history
- Write `{PraestoClaw_Dir}/skills/<name>.md` in SKILL.md format (YAML frontmatter: name, description, activation keywords; body: step-by-step instructions).
- If below threshold but promising: save draft to `{PraestoClaw_Dir}/skill-draft/<name>.md`.

**Modify** — use `list_dir` to enumerate `{PraestoClaw_Dir}/skills/`, then for each skill:
- Cross-check against recent sessions (`search_history`): are referenced paths, commands, or steps broken? Is there a simpler approach?
- If confident in improvement: save proposed update to `{PraestoClaw_Dir}/skill-draft/<name>.md` and include diff summary in notification. Do NOT overwrite the live skill.
- If signal is ambiguous or seen only once: skip.

Write the current timestamp to `{PraestoClaw_Dir}/skills/.last_updated` when done.

## Output

- If you have actionable findings, reply with a Markdown-formatted summary. Do not add a "Heartbeat" title or header — a prefix is added automatically. It will be delivered to the user.
- For user-facing notifications, prioritize the user's preferred language from `{PraestoClaw_Dir}/USER.md` (`## Preferences` → `Language`). If unavailable, use the dominant language from recent conversations. Keep code, file paths, and identifiers in original English.
- If nothing to report, reply with exactly `HEARTBEAT_OK`.
- Do NOT call `notify()` or any delivery tool — output delivery is handled externally.
