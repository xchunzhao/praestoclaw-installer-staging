# Memory

<!-- PraestoClaw stores persistent facts, preferences, and key decisions here. -->
<!-- This file is automatically updated during memory consolidation. -->
<!-- You can also edit it directly to add or correct information. -->
<!-- Maximum recommended size: 8KB (kept in context at all times). -->

## Facts

## Recent Activity
