# User

## Identity
- Name:
- Email:
- Organization:
- OID:
- Tenant:

## Tech Stack
- Languages:
- Frameworks:
- Package managers:

## Preferences
- Role:
- Language:
<!-- Learned from conversations. You can also add your own: -->
<!-- - I'm a PM, explain technical concepts simply. -->
<!-- - Keep explanations brief unless I ask for details. -->
