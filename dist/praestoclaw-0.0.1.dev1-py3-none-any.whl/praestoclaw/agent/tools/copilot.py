"""
Copilot tools — delegate coding/review tasks to GitHub Copilot CLI.

Tools
-----
  github_copilot  Submit a task (background or wait mode).
  github_copilot_status    Query task status / list all tasks.
  github_copilot_models    List available models with context limits and billing.

All three share a singleton CopilotDelegateService which owns one gh copilot
CLI process (via github-copilot-sdk JSON-RPC) for the lifetime of the Runtime.
"""

from __future__ import annotations

import asyncio
import uuid
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import TYPE_CHECKING, Any

from loguru import logger

from praestoclaw.agent.tools.base import Tool, ToolMetadata
from praestoclaw.bus.events import OutboundMessage
from praestoclaw.bus.queue import MessageBus
from praestoclaw.config.schema import ChannelType
from praestoclaw.security.risk import RiskAssessment, RiskPrompt, RiskScore

# ── Shared risk assessment for delegate tools (Copilot / Claude Code) ────────

_DELEGATE_FACTORS = (
    "4: Small scoped change, few files, wait mode",
    "5: Moderate change, clear scope",
    "6: Broad change, background mode, or touches config",
    "7: Large scope, modifies CI/CD, or no file restriction",
)


def _assess_delegate_risk(name: str, args: dict[str, Any]) -> RiskAssessment:
    """Shared assess_risk logic for Copilot and Claude Code delegate tools."""
    task_type = (args.get("task_type", "code") or "code").strip()
    mode = (args.get("mode", "background") or "background").strip()
    files = args.get("files") or []

    # Deterministic task types
    _TASK_SCORES: dict[str, tuple[int, str]] = {
        "review": (3, f"{name} review (code analysis)"),
        "research": (3, f"{name} research (read-focused analysis)"),
        "test": (4, f"{name} test (writes test files, may run tests)"),
    }
    entry = _TASK_SCORES.get(task_type)
    if entry:
        base, reason = entry
        # Background +1 only for low-risk tasks (review/research)
        if mode == "background" and base < 4:
            base += 1
        return RiskScore(min(base, 9), reason=reason)

    # code / unknown — LLM
    return RiskPrompt(
        context=(
            f"{name} {task_type} task — autonomous code changes.\n"
            f"Mode: {mode}, files: {files or 'any'}"
        ),
        range=(4, 7),
        factors=_DELEGATE_FACTORS,
    )


if TYPE_CHECKING:
    from praestoclaw.config.schema import CopilotToolConfig


# ── Task state ────────────────────────────────────────────────────────────────


class TaskStatus(str, Enum):
    PENDING = "pending"
    RUNNING = "running"
    DONE = "done"
    FAILED = "failed"


@dataclass
class CopilotTask:
    task_id: str
    task: str
    task_type: str
    status: TaskStatus = TaskStatus.PENDING
    result: str = ""
    error: str = ""
    notify_channel: ChannelType = ChannelType.CLI
    notify_channel_id: str = ""
    notify_thread_id: str | None = None
    asyncio_task: asyncio.Task | None = field(default=None, repr=False)


# ── Service ───────────────────────────────────────────────────────────────────


class CopilotDelegateService:
    """Singleton service managing the Copilot SDK client and task registry."""

    _TASK_TYPE_PROMPTS: dict[str, str] = {
        "code": (
            "Implement the following task. Write clean, minimal code. "
            "Only change what is necessary. Run tests when applicable."
        ),
        "review": (
            "Review the following code or task. Identify bugs, security issues, "
            "performance problems, and style violations. Be concise and actionable."
        ),
        "test": (
            "Write tests for the following task. Use the existing test framework "
            "and conventions in the codebase."
        ),
        "refactor": (
            "Refactor the following code. Keep behaviour identical. "
            "Improve readability, reduce duplication, and simplify where possible."
        ),
    }

    def __init__(
        self,
        workspace: Path,
        bus: MessageBus,
        config: CopilotToolConfig,
        github_token: str | None = None,
    ) -> None:
        self._workspace = workspace
        self._bus = bus
        self._config = config
        self._github_token = github_token
        self._tasks: dict[str, CopilotTask] = {}
        self._client: Any | None = None
        self._client_lock = asyncio.Lock()
        self._started = False
        self._semaphore = asyncio.Semaphore(config.max_concurrent)

    # ── Client lifecycle ──────────────────────────────────────────────────────

    async def _get_client(self) -> Any:
        """Return (or lazily start) the shared CopilotClient."""
        async with self._client_lock:
            if self._started:
                return self._client
            try:
                from copilot import CopilotClient  # type: ignore[import]

                opts: dict[str, Any] = {"cwd": str(self._workspace)}
                if self._config.cli_path:
                    opts["cli_path"] = self._config.cli_path
                if self._github_token:
                    opts["github_token"] = self._github_token

                self._client = CopilotClient(opts)  # type: ignore[arg-type]
                await self._client.start()
                self._started = True

                auth = await self._client.get_auth_status()
                if auth.isAuthenticated:
                    logger.info(
                        f"CopilotDelegateService: authenticated as {auth.login} via {auth.authType}"
                    )
                else:
                    logger.warning(
                        "CopilotDelegateService: not authenticated — "
                        "tasks will fail. Run: gh auth login"
                    )
            except ImportError:
                raise RuntimeError(
                    "github-copilot-sdk is not installed. Run: pip install github-copilot-sdk"
                )
        return self._client

    async def stop(self) -> None:
        # Cancel in-flight background tasks
        for ct in self._tasks.values():
            if ct.asyncio_task and not ct.asyncio_task.done():
                ct.asyncio_task.cancel()
                ct.status = TaskStatus.FAILED
                ct.error = "Cancelled: runtime shutting down"
        # Wait briefly for tasks to finish cancellation
        pending = [
            ct.asyncio_task
            for ct in self._tasks.values()
            if ct.asyncio_task and not ct.asyncio_task.done()
        ]
        if pending:
            await asyncio.gather(*pending, return_exceptions=True)

        if self._client and self._started:
            try:
                await self._client.stop()
                logger.info("CopilotDelegateService: CLI client stopped")
            except Exception as exc:
                logger.warning(f"CopilotDelegateService stop error: {exc}")
            finally:
                self._client = None
                self._started = False

    # ── Prompt builder ────────────────────────────────────────────────────────

    def _build_prompt(self, task: CopilotTask, files: list[str]) -> str:
        instruction = self._TASK_TYPE_PROMPTS.get(task.task_type, self._TASK_TYPE_PROMPTS["code"])
        parts = [f"[{task.task_type.upper()} TASK]\n{instruction}\n\nTask:\n{task.task}"]
        if files:
            file_list = "\n".join(f"  - {f}" for f in files)
            parts.append(f"\nFocus on these files/paths:\n{file_list}")
        return "\n".join(parts)

    # ── Model resolution ──────────────────────────────────────────────────────

    def _resolve_model(self, task_type: str, model_override: str | None) -> str:
        """
        Priority: explicit per-call model > model_policy[task_type] > default_model.
        """
        if model_override:
            return model_override
        policy = self._config.model_policy
        return getattr(policy, task_type, self._config.default_model)

    # ── Task submission ───────────────────────────────────────────────────────

    async def submit(
        self,
        task_desc: str,
        task_type: str,
        files: list[str],
        model_override: str | None,
        mode: str,
        notify_channel: ChannelType,
        notify_channel_id: str,
        notify_thread_id: str | None,
        resume_task_id: str | None = None,
    ) -> str:
        model = self._resolve_model(task_type, model_override)

        # ── Resume path ───────────────────────────────────────────────────────
        if resume_task_id:
            # Do NOT require the prior task to be in the in-memory registry —
            # Copilot session history lives on disk and survives PraestoClaw restarts.
            # Let the SDK raise if the session genuinely doesn't exist.
            task_id = uuid.uuid4().hex[:12]
            ct = CopilotTask(
                task_id=task_id,
                task=task_desc,
                task_type=task_type,
                notify_channel=notify_channel,
                notify_channel_id=notify_channel_id,
                notify_thread_id=notify_thread_id,
            )
            self._tasks[task_id] = ct
            prompt = self._build_prompt(ct, files)
            resume_session_id = f"wp-{resume_task_id}"

            if mode == "wait":
                await self._run_task(
                    ct, prompt, model, notify=False, resume_session_id=resume_session_id
                )
                return ct.result if ct.status == TaskStatus.DONE else f"Task failed: {ct.error}"

            ct.asyncio_task = asyncio.create_task(
                self._run_task(ct, prompt, model, notify=True, resume_session_id=resume_session_id),
                name=f"copilot-{task_id}",
            )
            return (
                f"Task resumed (id={task_id})\n"
                f"Continuing Copilot session wp-{resume_task_id}.\n"
                f"You will be notified on '{notify_channel}' when it completes.\n"
                f'Check status: github_copilot_status(task_id="{task_id}")'
            )

        # ── New task path ─────────────────────────────────────────────────────
        task_id = uuid.uuid4().hex[:12]
        ct = CopilotTask(
            task_id=task_id,
            task=task_desc,
            task_type=task_type,
            notify_channel=notify_channel,
            notify_channel_id=notify_channel_id,
            notify_thread_id=notify_thread_id,
        )
        self._tasks[task_id] = ct
        prompt = self._build_prompt(ct, files)

        if mode == "wait":
            await self._run_task(ct, prompt, model, notify=False)
            return ct.result if ct.status == TaskStatus.DONE else f"Task failed: {ct.error}"

        ct.asyncio_task = asyncio.create_task(
            self._run_task(ct, prompt, model, notify=True),
            name=f"copilot-{task_id}",
        )
        return (
            f"Task submitted (id={task_id})\n"
            f"Type: {task_type} | Model: {model}\n"
            f"You will be notified on '{notify_channel}' when it completes.\n"
            f'Check status: github_copilot_status(task_id="{task_id}")'
        )

    # ── Task execution ────────────────────────────────────────────────────────

    async def _run_task(
        self,
        ct: CopilotTask,
        prompt: str,
        model: str,
        *,
        notify: bool,
        resume_session_id: str | None = None,
    ) -> None:
        """Execute one Copilot session (new or resumed), with optional retry."""
        async with self._semaphore:
            attempt = 0
            max_attempts = (
                max(self._config.retry.max_attempts, 1) if self._config.retry.enabled else 1
            )
            session_id = f"wp-{ct.task_id}"

            while attempt < max_attempts:
                attempt += 1
                ct.status = TaskStatus.RUNNING
                logger.info(
                    f"CopilotDelegate [{ct.task_id}]: starting ({ct.task_type}) "
                    f"attempt {attempt}/{max_attempts}"
                )
                try:
                    await self._execute_session(ct, prompt, model, session_id, resume_session_id)
                    break  # success
                except Exception as exc:
                    ct.status = TaskStatus.FAILED
                    ct.error = str(exc)
                    logger.error(f"CopilotDelegate [{ct.task_id}]: failed — {exc}")
                    if attempt < max_attempts:
                        # Next attempt resumes from the failed session checkpoint
                        resume_session_id = session_id
                        logger.info(f"CopilotDelegate [{ct.task_id}]: retrying via resume_session")

        if notify:
            await self._notify(ct)

    async def _execute_session(
        self,
        ct: CopilotTask,
        prompt: str,
        model: str,
        session_id: str,
        resume_session_id: str | None,
    ) -> None:
        from copilot import PermissionHandler  # type: ignore[import,attr-defined]

        client = await self._get_client()

        session_config: dict[str, Any] = {
            "model": model,
            "on_permission_request": PermissionHandler.approve_all,
            "hooks": {
                "on_pre_tool_use": self._on_pre_tool_use,
                "on_post_tool_use": self._on_post_tool_use,
            },
        }

        if resume_session_id:
            session = await client.resume_session(resume_session_id, session_config)
        else:
            session_config["session_id"] = session_id
            session = await client.create_session(session_config)

        # SDK send_and_wait default is 60s when timeout=None — pass task_timeout
        # explicitly so long tasks don't time out. 0 in config means "no limit";
        # map to 3600s (1h) since the SDK has no true infinity mode.
        timeout = self._config.task_timeout if self._config.task_timeout > 0 else 3600
        try:
            reply = await session.send_and_wait({"prompt": prompt}, timeout=timeout)
            ct.result = reply.data.content if reply else "(no response)"
            ct.status = TaskStatus.DONE
            logger.info(f"CopilotDelegate [{ct.task_id}]: done ({len(ct.result)} chars)")
        finally:
            await session.destroy()

    # ── Notification ──────────────────────────────────────────────────────────

    async def _notify(self, ct: CopilotTask) -> None:
        from praestoclaw.security.leak import redact_credentials

        max_chars = self._config.notification_max_chars
        if ct.status == TaskStatus.DONE:
            body = (
                ct.result
                if len(ct.result) <= max_chars
                else ct.result[:max_chars] + "\n\n...(truncated)"
            )
            body = redact_credentials(body)
            content = (
                f"**Copilot task complete** (id=`{ct.task_id}`, type=`{ct.task_type}`)\n\n{body}"
            )
        else:
            content = (
                f"**Copilot task failed** (id=`{ct.task_id}`, type=`{ct.task_type}`)\n"
                f"Error: {ct.error}"
            )
        try:
            await self._bus.publish_outbound(
                OutboundMessage(
                    channel=ct.notify_channel,
                    channel_id=ct.notify_channel_id,
                    content=content,
                    thread_id=ct.notify_thread_id,
                    metadata={"source": "github_copilot", "task_id": ct.task_id},
                )
            )
        except Exception as exc:
            logger.warning(f"CopilotDelegate [{ct.task_id}]: notification failed — {exc}")

    # ── SDK hooks ─────────────────────────────────────────────────────────────

    async def _on_pre_tool_use(self, input: dict, invocation: dict) -> dict:
        tool_name = input.get("toolName", "unknown")
        logger.debug(f"CopilotDelegate: pre_tool_use tool={tool_name}")
        if tool_name in self._config.hooks.block_copilot_tools:
            logger.info(f"CopilotDelegate: blocking tool={tool_name} (block_copilot_tools)")
            return {"permissionDecision": "deny"}
        return {"permissionDecision": "allow"}

    async def _on_post_tool_use(self, input: dict, invocation: dict) -> dict:
        logger.debug(f"CopilotDelegate: post_tool_use tool={input.get('toolName', 'unknown')}")
        return {}

    # ── Status queries ────────────────────────────────────────────────────────

    def get_task(self, task_id: str) -> CopilotTask | None:
        return self._tasks.get(task_id)

    def list_tasks(self) -> list[CopilotTask]:
        return list(self._tasks.values())

    async def get_models(self) -> Any:
        client = await self._get_client()
        return await client.list_models()


# ── Tool: github_copilot ────────────────────────────────────────────────────


class CopilotDelegateTool(Tool):
    """Delegate a coding, review, test, or refactor task to GitHub Copilot CLI."""

    risk_range = (3, 7)

    def __init__(self, service: CopilotDelegateService) -> None:
        self._service = service

    @property
    def name(self) -> str:
        return "github_copilot"

    @property
    def description(self) -> str:
        return (
            "Delegate a coding task to GitHub Copilot. "
            "Copilot reads, edits, and tests autonomously. "
            "Returns a task_id; notifies on completion."
        )

    @property
    def metadata(self) -> ToolMetadata:
        return ToolMetadata(timeout=30, tier="standard")

    def assess_risk(self, args: dict[str, Any]) -> RiskAssessment:
        return _assess_delegate_risk("Copilot", args)

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "task": {
                    "type": "string",
                    "description": (
                        "Task description. Include file names, expected behaviour, "
                        "and acceptance criteria."
                    ),
                },
                "task_type": {
                    "type": "string",
                    "enum": ["code", "review", "test", "refactor"],
                    "description": (
                        "code = fix/implement; review = audit for bugs/security; "
                        "test = write tests; refactor = restructure without behaviour change."
                    ),
                },
                "files": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "File or directory paths for Copilot to focus on.",
                },
                "mode": {
                    "type": "string",
                    "enum": ["background", "wait"],
                    "description": (
                        "background (default) = async with notification; "
                        "wait = block until done (short tasks only)."
                    ),
                },
                "model": {
                    "type": "string",
                    "description": "Copilot model. Use github_copilot_models to list options.",
                },
                "resume_task_id": {
                    "type": "string",
                    "description": "Resume a prior task by ID. Continues from existing session.",
                },
            },
            "required": ["task"],
        }

    async def execute(self, **kwargs: Any) -> str:
        # Read channel context from kwargs (injected by ToolRegistry.execute)
        channel = kwargs.get("_channel", "")
        channel_id = kwargs.get("_channel_id", "")
        thread_id = kwargs.get("_thread_id")

        task: str = kwargs.get("task", "")
        task_type: str = kwargs.get("task_type", "code")
        files: list[str] = kwargs.get("files", [])
        mode: str = kwargs.get("mode", "background")
        model: str | None = kwargs.get("model") or None
        resume_task_id: str | None = kwargs.get("resume_task_id") or None

        if not task.strip():
            return "Error: task description cannot be empty."
        if task_type not in ("code", "review", "test", "refactor"):
            return f"Error: invalid task_type '{task_type}'. Use: code, review, test, refactor."
        if mode not in ("background", "wait"):
            return f"Error: invalid mode '{mode}'. Use: background or wait."

        return await self._service.submit(
            task_desc=task,
            task_type=task_type,
            files=files,
            model_override=model,
            mode=mode,
            notify_channel=ChannelType.of(channel),
            notify_channel_id=channel_id,
            notify_thread_id=thread_id,
            resume_task_id=resume_task_id,
        )


# ── Tool: github_copilot_status ──────────────────────────────────────────────────────


class CopilotStatusTool(Tool):
    """Query the status and result of a background Copilot task."""

    risk_range = (0, 0)

    def __init__(self, service: CopilotDelegateService) -> None:
        self._service = service

    @property
    def name(self) -> str:
        return "github_copilot_status"

    @property
    def description(self) -> str:
        return "Check Copilot task status or list all tasks."

    @property
    def metadata(self) -> ToolMetadata:
        return ToolMetadata(timeout=20, tier="standard")

    def assess_risk(self, args: dict[str, Any]) -> RiskAssessment:
        return RiskScore(0, reason="Read-only Copilot status query")

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "task_id": {
                    "type": "string",
                    "description": "Task ID from github_copilot. Omit to list all tasks.",
                },
            },
        }

    async def execute(self, **kwargs: Any) -> str:
        task_id: str | None = kwargs.get("task_id")

        if not task_id:
            tasks = self._service.list_tasks()
            if not tasks:
                return "No Copilot tasks found."
            lines = [f"{'ID':<14} {'TYPE':<10} {'STATUS'}"]
            lines.append("-" * 36)
            for t in tasks:
                lines.append(f"{t.task_id:<14} {t.task_type:<10} {t.status.value}")
            return "\n".join(lines)

        ct = self._service.get_task(task_id)
        if ct is None:
            return f"Error: no task with id '{task_id}'."

        lines = [
            f"Task ID:   {ct.task_id}",
            f"Type:      {ct.task_type}",
            f"Status:    {ct.status.value}",
        ]
        if ct.status == TaskStatus.RUNNING:
            lines.append("Result:    (in progress...)")
        elif ct.status == TaskStatus.DONE:
            preview = ct.result[:500] + ("..." if len(ct.result) > 500 else "")
            lines.append(f"Result:\n{preview}")
        elif ct.status == TaskStatus.FAILED:
            lines.append(f"Error:     {ct.error}")

        return "\n".join(lines)


# ── Tool: github_copilot_models ──────────────────────────────────────────────────────


class CopilotModelsTool(Tool):
    """List models available to the Copilot CLI, with context limits and billing."""

    risk_range = (0, 0)

    def __init__(self, service: CopilotDelegateService) -> None:
        self._service = service

    @property
    def name(self) -> str:
        return "github_copilot_models"

    @property
    def description(self) -> str:
        return "List available Copilot models with context limits and billing info."

    @property
    def metadata(self) -> ToolMetadata:
        return ToolMetadata(timeout=30, tier="standard")

    def assess_risk(self, args: dict[str, Any]) -> RiskAssessment:
        return RiskScore(0, reason="Read-only Copilot model listing")

    @property
    def parameters(self) -> dict[str, Any]:
        return {"type": "object", "properties": {}}

    async def execute(self, **kwargs: Any) -> str:
        try:
            models = await self._service.get_models()
        except Exception as exc:
            return f"Error fetching models: {exc}"

        if not models:
            return "No models returned."

        header = f"{'MODEL':<30} {'CTX':>7}  {'PROMPT':>7}  BILLING"
        sep = "-" * 58
        rows = [header, sep]
        for m in models:
            lim = m.capabilities.limits
            ctx = (
                f"{lim.max_context_window_tokens // 1000}K"
                if lim.max_context_window_tokens
                else "-"
            )
            prompt = f"{lim.max_prompt_tokens // 1000}K" if lim.max_prompt_tokens else "-"
            billing = f"x{m.billing.multiplier}" if m.billing else "-"
            rows.append(f"{m.id:<30} {ctx:>7}  {prompt:>7}  {billing}")
        return "\n".join(rows)
