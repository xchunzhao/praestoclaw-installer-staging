"""Skill management tool — create, patch, delete, and list skills at runtime.

Allows the agent to save reusable workflows discovered during conversations
and update outdated skills on the fly.

Actions:
  create — write a new SKILL.md with YAML frontmatter
  patch  — find-and-replace in an existing skill file
  delete — remove a skill directory
  list   — list all user-created skills
"""

from __future__ import annotations

import re
import shutil
from pathlib import Path
from typing import Any

from loguru import logger

from praestoclaw.agent.tools.base import Tool, ToolMetadata
from praestoclaw.security.risk import RiskAssessment, RiskScore

_MAX_SKILL_CHARS = 100_000  # 100K char limit per skill file
_SAFE_NAME_RE = re.compile(r"^[a-z0-9][a-z0-9_-]{0,62}$")


class SkillManageTool(Tool):
    """Create, update, and delete skills from experience."""

    risk_range = (1, 3)

    def __init__(self, skill_loader: Any) -> None:
        self._skill_loader = skill_loader

    @property
    def name(self) -> str:
        return "skill_manage"

    @property
    def description(self) -> str:
        return (
            "Manage reusable skills. Actions: "
            "create (save a new skill from experience), "
            "patch (update part of an existing skill), "
            "delete (remove a skill), "
            "list (show all user skills). "
            "Use after completing complex tasks, fixing tricky errors, or discovering "
            "non-trivial workflows. If a skill is outdated, patch it immediately."
        )

    @property
    def metadata(self) -> ToolMetadata:
        return ToolMetadata(timeout=10, tier="standard")

    def assess_risk(self, args: dict[str, Any]) -> RiskAssessment:
        action = args.get("action", "")
        if action == "list":
            return RiskScore(0, reason="Read-only listing")
        if action == "delete":
            return RiskScore(3, reason="Delete skill directory")
        return RiskScore(2, reason="Write to skills directory")

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "enum": ["create", "patch", "delete", "list"],
                    "description": "Action to perform.",
                },
                "name": {
                    "type": "string",
                    "description": (
                        "Skill name (lowercase, hyphens/underscores, max 63 chars). "
                        "Required for create, patch, delete."
                    ),
                },
                "content": {
                    "type": "string",
                    "description": "Full skill content in markdown (for 'create').",
                },
                "description": {
                    "type": "string",
                    "description": "Short description of the skill (for 'create').",
                },
                "category": {
                    "type": "string",
                    "description": "Optional category (e.g. 'workflow', 'debugging').",
                },
                "old_text": {
                    "type": "string",
                    "description": "Text to find in the skill (for 'patch').",
                },
                "new_text": {
                    "type": "string",
                    "description": "Replacement text (for 'patch').",
                },
            },
            "required": ["action"],
        }

    async def execute(self, **kwargs: Any) -> str:
        action = kwargs.get("action", "")
        if action == "create":
            return self._create(kwargs)
        elif action == "patch":
            return self._patch(kwargs)
        elif action == "delete":
            return self._delete(kwargs)
        elif action == "list":
            return self._list()
        else:
            return f"Error: unknown action '{action}'. Use create, patch, delete, or list."

    # ── Internal ─────────────────────────────────────────────────────────

    def _skills_dir(self) -> Path:
        from praestoclaw.utils.helpers import get_data_dir

        return get_data_dir() / "skills"

    def _validate_name(self, name: str | None) -> str | None:
        """Validate skill name. Returns error message or None if valid."""
        if not name:
            return "Error: 'name' is required."
        if not _SAFE_NAME_RE.match(name):
            return (
                f"Error: invalid skill name '{name}'. "
                "Use lowercase letters, digits, hyphens, underscores (max 63 chars)."
            )
        return None

    def _create(self, kwargs: dict[str, Any]) -> str:
        name = kwargs.get("name", "")
        err = self._validate_name(name)
        if err:
            return err

        content = kwargs.get("content", "")
        if not content or not content.strip():
            return "Error: 'content' is required."

        if len(content) > _MAX_SKILL_CHARS:
            return f"Error: content exceeds {_MAX_SKILL_CHARS // 1000}K char limit."

        description = kwargs.get("description", "") or ""
        category = kwargs.get("category", "") or ""

        # Security scan
        from praestoclaw.agent.prompt_builder import _scan_context_content

        scanned = _scan_context_content(content, f"skill:{name}")
        if scanned.startswith("[BLOCKED:"):
            return scanned

        # Check if already exists
        skill_dir = self._skills_dir() / name
        skill_file = skill_dir / "SKILL.md"
        if skill_file.is_file():
            return f"Error: skill '{name}' already exists. Use action='patch' to update it."

        # Build YAML frontmatter
        frontmatter_lines = [
            "---",
            f"name: {name}",
        ]
        if description:
            # Escape quotes in description for YAML
            safe_desc = description.replace('"', '\\"')
            frontmatter_lines.append(f'description: "{safe_desc}"')
        if category:
            frontmatter_lines.append(f"category: {category}")
        frontmatter_lines.append("mode: available")
        frontmatter_lines.append("---")

        full_content = "\n".join(frontmatter_lines) + "\n\n" + content.strip() + "\n"

        # Write
        skill_dir.mkdir(parents=True, exist_ok=True)
        skill_file.write_text(full_content, encoding="utf-8")

        # Refresh skill loader cache
        if self._skill_loader and hasattr(self._skill_loader, "load_all"):
            self._skill_loader.load_all()

        logger.info("Skill created: {}", name)
        return f"Skill '{name}' created successfully."

    def _patch(self, kwargs: dict[str, Any]) -> str:
        name = kwargs.get("name", "")
        err = self._validate_name(name)
        if err:
            return err

        old_text = kwargs.get("old_text", "")
        new_text = kwargs.get("new_text", "")
        if not old_text:
            return "Error: 'old_text' is required for patch."
        if not new_text:
            return "Error: 'new_text' is required for patch."

        skill_file = self._skills_dir() / name / "SKILL.md"
        if not skill_file.is_file():
            return f"Error: skill '{name}' not found."

        content = skill_file.read_text(encoding="utf-8")

        # Try exact match first
        if old_text in content:
            updated = content.replace(old_text, new_text, 1)
        else:
            # Whitespace-normalized match
            normalized_old = _normalize_ws(old_text)
            normalized_content = _normalize_ws(content)
            if normalized_old in normalized_content:
                # Find the position in normalized space, then do line-based replacement
                # Fallback: just report not found and let the agent retry with exact text
                return (
                    f"Error: exact text not found in skill '{name}'. "
                    "The text may differ in whitespace. Try copying the exact text from "
                    "the skill content."
                )
            else:
                return f"Error: '{old_text[:60]}...' not found in skill '{name}'."

        # Security scan the new content
        from praestoclaw.agent.prompt_builder import _scan_context_content

        scanned = _scan_context_content(new_text, f"skill:{name}:patch")
        if scanned.startswith("[BLOCKED:"):
            return scanned

        skill_file.write_text(updated, encoding="utf-8")

        if self._skill_loader and hasattr(self._skill_loader, "load_all"):
            self._skill_loader.load_all()

        logger.info("Skill patched: {}", name)
        return f"Skill '{name}' patched successfully."

    def _delete(self, kwargs: dict[str, Any]) -> str:
        name = kwargs.get("name", "")
        err = self._validate_name(name)
        if err:
            return err

        skill_dir = self._skills_dir() / name
        if not skill_dir.is_dir():
            return f"Error: skill '{name}' not found."

        shutil.rmtree(skill_dir)

        if self._skill_loader and hasattr(self._skill_loader, "load_all"):
            self._skill_loader.load_all()

        logger.info("Skill deleted: {}", name)
        return f"Skill '{name}' deleted."

    def _list(self) -> str:
        skills_dir = self._skills_dir()
        if not skills_dir.is_dir():
            return "No user skills found."

        entries: list[str] = []
        for skill_dir in sorted(skills_dir.iterdir()):
            if not skill_dir.is_dir():
                continue
            skill_file = skill_dir / "SKILL.md"
            if not skill_file.is_file():
                continue
            # Extract description from frontmatter
            desc = ""
            try:
                text = skill_file.read_text(encoding="utf-8")
                if text.startswith("---"):
                    end = text.find("---", 3)
                    if end > 0:
                        fm = text[3:end]
                        for line in fm.splitlines():
                            if line.strip().startswith("description:"):
                                desc = line.split(":", 1)[1].strip().strip('"')
                                break
            except Exception:
                pass
            entries.append(f"- {skill_dir.name}: {desc}" if desc else f"- {skill_dir.name}")

        if not entries:
            return "No user skills found."
        return "User skills:\n" + "\n".join(entries)


def _normalize_ws(text: str) -> str:
    """Normalize whitespace for fuzzy matching."""
    return " ".join(text.split())
