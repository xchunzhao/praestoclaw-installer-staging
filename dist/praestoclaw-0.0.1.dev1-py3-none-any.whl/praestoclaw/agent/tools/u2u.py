"""U2U tool — user-level routing through the Cloud Gateway."""

from __future__ import annotations

from collections.abc import Callable
from typing import Any

from praestoclaw.agent.tools.base import Tool, ToolMetadata
from praestoclaw.security.risk import RiskAssessment, RiskScore


class U2UTool(Tool):
    """Send user-to-user messages via the native Gateway U2U protocol."""

    risk_range = (4, 4)

    def __init__(self, cloud_channel_getter: Callable[[], Any]) -> None:
        self._cloud_channel_getter = cloud_channel_getter

    @property
    def name(self) -> str:
        return "u2u"

    @property
    def description(self) -> str:
        return (
            "通过 Gateway 的 U2U 协议按 user_id 与其他用户通信。"
            "Actions: send (fire-and-forget，不等待回复), ask (等待一次回复)。"
            "U2U 是用户级路由，不需要 agent_id；direct agent-to-agent 请使用 a2a。"
        )

    @property
    def metadata(self) -> ToolMetadata:
        return ToolMetadata(timeout=120, tier="core", category="builtin")

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "enum": ["send", "ask"],
                    "description": (
                        "'send': fire-and-forget user-to-user message. "
                        "'ask': send a user-to-user request and wait for one reply."
                    ),
                },
                "target": {
                    "type": "string",
                    "description": "Target user_id, for example 'dev-user-bob'.",
                },
                "message": {
                    "type": "string",
                    "description": "Message content to send.",
                },
                "timeout_s": {
                    "type": "number",
                    "description": "Optional timeout in seconds for ask. Defaults to 120.",
                    "default": 120,
                },
            },
            "required": ["action", "target", "message"],
        }

    def assess_risk(self, args: dict[str, Any]) -> RiskAssessment:
        action = args.get("action", "")
        return RiskScore(4, reason=f"U2U {action or 'message'} to another user")

    async def execute(self, **kwargs: Any) -> str:
        action = str(kwargs.get("action") or "").strip()
        target = str(kwargs.get("target") or "").strip()
        message = str(kwargs.get("message") or "").strip()

        if action not in {"send", "ask"}:
            return "Error: unknown action. Use 'send' or 'ask'."
        if not target:
            return "Error: 'target' parameter is required."
        if not message:
            return "Error: 'message' parameter is required."

        channel = self._cloud_channel_getter()
        if channel is None or not getattr(channel, "is_connected", False):
            return "Error: U2U requires an active Cloud Gateway connection."

        try:
            if action == "send":
                result = await channel.send_u2u(
                    target,
                    message,
                    channel=kwargs.get("_channel", ""),
                    channel_id=kwargs.get("_channel_id", ""),
                    session_id=kwargs.get("_session_id", "") or kwargs.get("_session_key", ""),
                )
                message_id = result.get("message_id", "")
                return (
                    f"已发出 u2u 消息给 {target}"
                    f"{f' (message_id={message_id})' if message_id else ''}。"
                    "这是 fire-and-forget 发送，不会等待回复。"
                )

            timeout_s = _timeout_s(kwargs.get("timeout_s"))
            result = await channel.ask_u2u(target, message, timeout_s=timeout_s)
            return _format_ask_result(target, result)
        except Exception as exc:
            return f"Error: U2U {action} failed — {exc}"


def _timeout_s(value: Any) -> float:
    if isinstance(value, bool):
        return 120.0
    if isinstance(value, (int, float)) and value > 0:
        return float(value)
    return 120.0


def _format_ask_result(target: str, result: dict[str, Any]) -> str:
    content = result.get("content")
    if isinstance(content, dict):
        text = str(content.get("text") or "")
        if text:
            return f"{target} 回复：{text}"
    text = str(result.get("text") or "")
    if text:
        return f"{target} 回复：{text}"
    return f"{target} 已回复。"
