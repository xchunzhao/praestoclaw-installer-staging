"""
Sub-agent spawning tool — create and manage child agent executions.

The tool delegates actual agent creation to a runtime-provided callback
(``spawn_fn``), keeping the tool itself decoupled from runtime internals.
Supports three execution modes:

- **serial**: await a single sub-agent and return its result.
- **parallel**: run multiple agents concurrently (prompt is a JSON array)
  and return all results.
- **background**: start a sub-agent in the background and return a task ID
  for later retrieval.
"""

from __future__ import annotations

import asyncio
import inspect
import json
import uuid
from collections.abc import Awaitable, Callable
from typing import Any

from loguru import logger

from praestoclaw.agent.tools.base import Tool, ToolMetadata
from praestoclaw.security.risk import RiskAssessment, RiskPrompt, RiskScore

# Type alias for the runtime-provided spawn callback.
# Signature: async spawn_fn(agent_name: str, prompt: str, *, metadata: dict | None) -> str
SpawnFn = Callable[..., Awaitable[str]]


class SpawnTool(Tool):
    """Spawn sub-agents in serial, parallel, or background mode."""

    risk_range = (2, 7)

    def __init__(self, spawn_fn: SpawnFn, available_agents: list[str] | None = None) -> None:
        self._spawn_fn = spawn_fn
        self._available_agents = available_agents or []
        # Track background tasks so callers can retrieve results later.
        self._background_tasks: dict[str, asyncio.Task[str]] = {}
        # Cache whether spawn_fn accepts a metadata kwarg (inspect once).
        try:
            sig = inspect.signature(spawn_fn)
            params = sig.parameters.values()
            self._spawn_accepts_metadata = any(
                p.name == "metadata" or p.kind is inspect.Parameter.VAR_KEYWORD for p in params
            )
        except (ValueError, TypeError):
            self._spawn_accepts_metadata = False

    def set_available_agents(self, agents: list[str]) -> None:
        """Update the available agent names (called after agents are merged)."""
        self._available_agents = agents

    # ── Tool ABC ────────────────────────────────────────────────────────

    @property
    def metadata(self) -> ToolMetadata:
        return ToolMetadata(timeout=600, tier="standard")

    def assess_risk(self, args: dict[str, Any]) -> RiskAssessment:
        agent = (args.get("agent", "") or "").strip()
        mode = (args.get("mode", "serial") or "serial").strip()
        if agent == "explorer":
            return RiskScore(2, reason="Read-only explorer sub-agent")
        if mode == "parallel":
            return RiskPrompt(
                context=f"Parallel sub-agent spawn (agent={agent})",
                range=(4, 7),
                factors=(
                    "4: Parallel read-only tasks (search, analysis)",
                    "5: Parallel tasks with local writes (file edits, git)",
                    "6: Parallel tasks with external side effects (API, push)",
                    "7: Parallel tasks with broad scope or unknown agents",
                ),
            )
        return RiskPrompt(
            context=f"Sub-agent spawn (agent={agent}, mode={mode})",
            range=(3, 6),
            factors=(
                "3: Known agent doing read-only or analysis task",
                "4: Agent with local write scope (file edits, git commit)",
                "5: Agent with external side effects or broad scope",
                "6: Unknown agent, background mode, or unrestricted prompt",
            ),
        )

    @property
    def name(self) -> str:
        return "spawn"

    @property
    def description(self) -> str:
        return "Delegate a task to a sub-agent."

    @property
    def parameters(self) -> dict[str, Any]:
        agent_desc = "Agent name. "
        if self._available_agents:
            agent_desc += f"Available: {', '.join(self._available_agents)}. "
        agent_desc += "Ignored in parallel mode."

        return {
            "type": "object",
            "properties": {
                "agent": {
                    "type": "string",
                    "description": agent_desc,
                },
                "prompt": {
                    "type": "string",
                    "description": (
                        "Task prompt. For parallel mode: JSON array of "
                        '[{"agent": "...", "prompt": "..."}] objects.'
                    ),
                },
                "mode": {
                    "type": "string",
                    "enum": ["serial", "parallel", "background"],
                    "description": (
                        "serial (default) = wait for result; "
                        "parallel = run multiple agents concurrently; "
                        "background = return task ID immediately."
                    ),
                },
            },
            "required": ["agent", "prompt"],
        }

    async def execute(self, **kwargs: Any) -> str:
        agent: str = kwargs["agent"]
        prompt: str = kwargs["prompt"]
        mode: str = kwargs.get("mode", "serial")
        # Metadata injected by registry via _metadata kwarg (same pattern as _channel).
        # Propagated to child agents so cron security restrictions carry through.
        metadata: dict[str, Any] | None = kwargs.get("_metadata")

        if mode == "serial":
            return await self._serial(agent, prompt, metadata=metadata)
        elif mode == "parallel":
            return await self._parallel(prompt, metadata=metadata)
        elif mode == "background":
            return await self._background(agent, prompt, metadata=metadata)
        else:
            return f"Error: unknown spawn mode '{mode}'. Use serial, parallel, or background."

    # ── Mode implementations ────────────────────────────────────────────

    async def _call_spawn(self, agent: str, prompt: str, metadata: dict[str, Any] | None) -> str:
        """Call spawn_fn, forwarding metadata if the callback accepts it."""
        if metadata is not None and self._spawn_accepts_metadata:
            return await self._spawn_fn(agent, prompt, metadata=metadata)
        return await self._spawn_fn(agent, prompt)

    async def _serial(
        self, agent: str, prompt: str, *, metadata: dict[str, Any] | None = None
    ) -> str:
        """Await a single sub-agent and return its result."""
        logger.info(f"Spawning agent '{agent}' in serial mode")
        try:
            result = await self._call_spawn(agent, prompt, metadata)
            return result
        except Exception as exc:
            logger.error(f"Serial spawn of '{agent}' failed: {exc}")
            return f"Error: sub-agent '{agent}' failed: {exc}"

    async def _parallel(self, prompt: str, *, metadata: dict[str, Any] | None = None) -> str:
        """Run multiple agents concurrently and return all results."""
        try:
            items = json.loads(prompt)
        except json.JSONDecodeError as exc:
            return (
                f"Error: parallel mode requires prompt to be a JSON array "
                f'of {{"agent": ..., "prompt": ...}} objects. Parse error: {exc}'
            )

        if not isinstance(items, list) or not items:
            return "Error: parallel mode requires a non-empty JSON array."

        # Validate each item has agent + prompt.
        for i, item in enumerate(items):
            if not isinstance(item, dict):
                return f"Error: item at index {i} is not an object."
            if "agent" not in item or "prompt" not in item:
                return f"Error: item at index {i} must have 'agent' and 'prompt' keys."

        logger.info(f"Spawning {len(items)} agents in parallel mode")

        async def _run(item: dict[str, str]) -> str:
            try:
                return await self._call_spawn(item["agent"], item["prompt"], metadata)
            except Exception as exc:
                return f"Error ({item['agent']}): {exc}"

        results = await asyncio.gather(*[_run(item) for item in items])

        # Format results with agent names.
        parts: list[str] = []
        for item, result in zip(items, results):
            parts.append(f"[{item['agent']}]\n{result}")

        return "\n\n---\n\n".join(parts)

    async def _background(
        self, agent: str, prompt: str, *, metadata: dict[str, Any] | None = None
    ) -> str:
        """Start a sub-agent in the background and return a task ID."""
        task_id = uuid.uuid4().hex[:12]
        logger.info(f"Spawning agent '{agent}' in background mode (task_id={task_id})")

        async def _run() -> str:
            try:
                return await self._call_spawn(agent, prompt, metadata)
            except Exception as exc:
                error_msg = f"Background agent '{agent}' failed: {exc}"
                logger.error(error_msg)
                return error_msg

        task = asyncio.create_task(_run(), name=f"spawn-{task_id}")
        self._background_tasks[task_id] = task

        return (
            f"Background task started: {task_id}\n"
            f"Agent: {agent}\n"
            f"Use the task ID to check status later."
        )

    # ── Background task management ──────────────────────────────────────

    def get_background_result(self, task_id: str) -> str | None:
        """
        Retrieve the result of a background task, or None if still running.

        This is a synchronous helper the runtime can expose via another
        mechanism (e.g., a ``task_status`` tool or direct API).
        """
        task = self._background_tasks.get(task_id)
        if task is None:
            return None
        if not task.done():
            return None
        return task.result()

    @property
    def pending_tasks(self) -> list[str]:
        """Return IDs of background tasks that are still running."""
        return [tid for tid, task in self._background_tasks.items() if not task.done()]
