"""
AgentMemory — unified memory facade.

MEMORY.md file I/O (read/write/backup/recompression) + consolidation
orchestration. Delegates HISTORY.md + SQLite FTS5 to HistoryStore
(in ``praestoclaw.agent.history``).

Backward-compatible re-exports: ``HistoryStore`` and ``apply_temporal_decay``
are importable from this module for existing callers.
"""

from __future__ import annotations

import asyncio
import json
import re
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from loguru import logger

# Re-export for backward compatibility — external code imports these from here
from praestoclaw.agent.history import HistoryStore, apply_temporal_decay

__all__ = ["AgentMemory", "HistoryStore", "apply_temporal_decay"]

# ── AgentMemory (unified facade) ─────────────────────────────────────────────


class AgentMemory:
    """Unified memory facade: MEMORY.md file I/O + HistoryStore + consolidation.

    MEMORY.md operations are inlined (just file I/O — no Store abstraction).
    HISTORY.md + SQLite FTS5 search is delegated to HistoryStore.

    Parameters
    ----------
    agent_name:
        If provided, memory files are placed in a per-agent subdirectory.
    data_dir:
        Root data directory (default ``~/.praestoclaw``).
    """

    # Consolidation locks, one per data_root (i.e. per data_dir). All AgentMemory
    # instances using the same data_root share the same asyncio.Lock. When
    # data_dir is omitted, data_root defaults to ``~/.praestoclaw``.
    _consolidation_locks: dict[str, asyncio.Lock] = {}

    _RECOMPRESS_THRESHOLD = 8500  # chars — trigger LLM re-compression
    _RECENT_MAX = 15
    _SECTION_BUDGETS = {"Facts": 3000, "Recent Activity": 2000}

    def __init__(
        self,
        *,
        agent_name: str | None = None,
        data_dir: Path | None = None,
    ) -> None:
        if data_dir is None:
            from praestoclaw.utils.helpers import get_data_dir

            data_root = get_data_dir()
        else:
            data_root = data_dir
        ws_key = str(data_root)
        if ws_key not in AgentMemory._consolidation_locks:
            AgentMemory._consolidation_locks[ws_key] = asyncio.Lock()
        self.consolidation_lock = AgentMemory._consolidation_locks[ws_key]

        if agent_name:
            base = data_root / "memory" / "agents" / agent_name
        else:
            base = data_root

        base.mkdir(parents=True, exist_ok=True)
        self._base = base
        self._memory_path = base / "MEMORY.md"
        self._fact_meta_path = base / "fact_meta.json"  # Fact lifecycle sidecar

        # Shared memory directory
        self._shared_dir = data_root / "memory" / "shared"
        self._shared_dir.mkdir(parents=True, exist_ok=True)

        # HistoryStore: HISTORY.md + SQLite FTS5
        self.history = HistoryStore(base)

        logger.debug(
            f"AgentMemory initialised: data_dir={data_root} agent={agent_name or 'default'}"
        )

    # ── MEMORY.md file I/O ────────────────────────────────────────────────

    def read_memory(self) -> str:
        if self._memory_path.is_file():
            return self._memory_path.read_text(encoding="utf-8")
        return ""

    def write_memory(self, content: str) -> None:
        """Write MEMORY.md with .bak backup."""
        if self._memory_path.is_file():
            existing = self._memory_path.read_text(encoding="utf-8")
            if existing.strip():
                try:
                    self._memory_path.with_suffix(".md.bak").write_text(existing, encoding="utf-8")
                except Exception:
                    pass
        self._memory_path.write_text(content, encoding="utf-8")

    def needs_recompression(self) -> bool:
        return len(self.read_memory()) > self._RECOMPRESS_THRESHOLD

    def diagnose_oversize(self) -> dict[str, Any]:
        """Analyze which section exceeds its char budget most."""
        content = self.read_memory()
        sections = {}
        for name in ("Facts", "Recent Activity"):
            lines = self._extract_section(content, name)
            sections[name] = "\n".join(lines)

        worst = ""
        worst_ratio = 0.0
        char_sizes: dict[str, int] = {}
        for name, text in sections.items():
            size = len(text)
            char_sizes[name] = size
            budget = self._SECTION_BUDGETS.get(name, 1500)
            ratio = size / budget if budget else 0
            if ratio > worst_ratio:
                worst_ratio = ratio
                worst = name

        return {
            "total_chars": len(content),
            "char_sizes": char_sizes,
            "budgets": self._SECTION_BUDGETS,
            "worst": worst,
            "worst_ratio": worst_ratio,
        }

    def add_doing_tag(self, topic: str) -> None:
        """Add a 'doing:' line to MEMORY.md, before ## Facts (not inside it)."""
        content = self.read_memory()
        # Remove any existing doing: line
        lines = content.splitlines()
        lines = [ln for ln in lines if not ln.strip().startswith("doing:")]
        content = "\n".join(lines)

        # Insert after "# Memory" header, before "## Facts"
        facts_pos = content.find("## Facts")
        if facts_pos > 0:
            content = content[:facts_pos].rstrip() + f"\n\ndoing: {topic}\n\n" + content[facts_pos:]
        else:
            # Fallback: prepend after title
            title_end = content.find("\n")
            if title_end > 0:
                content = (
                    content[: title_end + 1] + f"\ndoing: {topic}\n" + content[title_end + 1 :]
                )
            else:
                content = f"doing: {topic}\n" + content

        self.write_memory(content)

    # ── Shared memory ─────────────────────────────────────────────────────

    def read_shared(self, filename: str = "MEMORY.md") -> str:
        path = self._shared_dir / filename
        if path.is_file():
            return path.read_text(encoding="utf-8")
        return ""

    def write_shared(self, content: str, filename: str = "MEMORY.md") -> None:
        path = self._shared_dir / filename
        path.write_text(content, encoding="utf-8")

    # ── Consolidation orchestration ───────────────────────────────────────

    def build_consolidation_messages(
        self,
        messages: list[dict[str, Any]],
        *,
        task_context: str = "",
    ) -> list[dict[str, Any]]:
        """Build LLM messages for consolidation: system + conversation + closing user."""
        existing_memory = self.read_memory()

        from praestoclaw.utils.defaults import load_default

        template = load_default("_CONSOLIDATION.md")

        notable = HistoryStore.extract_notable_calls(messages)
        notable_text = "\n".join(notable) if notable else "(none)"

        usage_signals = self._compute_fact_usage_signals(existing_memory)

        system_content = template.format(
            existing_memory=existing_memory or "(empty)",
            notable_calls=notable_text,
            task_context=task_context or "Single-group consolidation.",
            usage_signals=usage_signals,
        )

        result: list[dict[str, Any]] = [
            {"role": "system", "content": system_content},
        ]

        from praestoclaw.agent.tool_sanitizer import sanitize_tool_messages

        _STRIP_KEYS = {"_ts", "is_error", "_compaction"}
        cleaned = []
        for m in messages:
            clean = {k: v for k, v in m.items() if k not in _STRIP_KEYS}
            if clean.get("role"):
                cleaned.append(clean)
        result.extend(sanitize_tool_messages(cleaned, stub_missing=True))

        result.append(
            {
                "role": "user",
                "content": "Now output the ```memory``` and ```history``` blocks.",
            }
        )
        return result

    @staticmethod
    def build_grouping_messages(messages: list[dict[str, Any]]) -> list[dict[str, Any]]:
        """Build LLM messages for task grouping (fast model, compressed tool outputs).

        Each message is compressed to ~80 chars with original index preserved.
        A 200-message session produces ~4K tokens — well within any fast model's
        context window (192K+). No truncation needed.
        """
        compressed_lines: list[str] = []
        for i, m in enumerate(messages):
            role = m.get("role", "")
            content = m.get("content", "") or ""

            if role == "tool":
                name = m.get("name", "tool")
                is_error = m.get("is_error", False)
                status = "error" if is_error else "ok"
                size = f"{len(content)} chars"
                compressed_lines.append(f"[{i}] tool: [result cleared: {name} | {status} | {size}]")
            elif role == "assistant" and m.get("tool_calls"):
                tc_names = [tc.get("function", {}).get("name", "?") for tc in m["tool_calls"]]
                text = content[:80] if content else ""
                compressed_lines.append(
                    f"[{i}] assistant: {text} [tool_calls: {', '.join(tc_names)}]"
                )
            else:
                preview = content[:120].replace("\n", " ")
                compressed_lines.append(f"[{i}] {role}: {preview}")

        compressed_text = "\n".join(compressed_lines)

        from praestoclaw.utils.defaults import load_default

        template = load_default("GROUPING.md")

        return [
            {"role": "system", "content": template},
            {"role": "user", "content": compressed_text},
        ]

    def apply_consolidation(
        self,
        llm_response: str,
        messages: list[dict[str, Any]] | None = None,
        session_id: str = "",
    ) -> str:
        """Parse and apply consolidation: write MEMORY.md + history.append().

        Returns the structured history entry text (empty if no history written).
        """
        memory_match = re.search(r"```memory\n(.*?)```", llm_response, re.DOTALL)
        history_match = re.search(r"```history\n(.*?)```", llm_response, re.DOTALL)

        if memory_match:
            new_content = memory_match.group(1).strip()
            existing = self.read_memory().strip()

            # Recovery guard: protect Facts entries (handles old "Core" during migration)
            if existing and new_content:
                old_facts = self._extract_section(existing, "Facts")
                if not old_facts:
                    old_facts = self._extract_section(existing, "Core")
                new_facts = self._extract_section(new_content, "Facts")
                if not new_facts:
                    new_facts = self._extract_section(new_content, "Core")
                new_keys = {self._entry_key(e) for e in new_facts}
                # Skip doing: entries — LLM legitimately removes them when task completes
                dropped = [
                    e
                    for e in old_facts
                    if self._entry_key(e) not in new_keys and not e.strip().startswith("doing:")
                ]
                if dropped:
                    logger.warning(
                        "Consolidation dropped {} of {} Facts entries; recovering",
                        len(dropped),
                        len(old_facts),
                    )
                    recovery_text = "\n".join(dropped)
                    facts_end = new_content.find("## Recent Activity")
                    if facts_end < 0:
                        facts_end = new_content.find("## Topics")
                    if facts_end > 0:
                        new_content = (
                            new_content[:facts_end].rstrip()
                            + "\n"
                            + recovery_text
                            + "\n\n"
                            + new_content[facts_end:]
                        )
                    else:
                        new_content = new_content + "\n" + recovery_text

                # Update fact lifecycle tracking
                self._update_fact_lifecycle(old_facts, new_facts, dropped)

            # Recent Activity FIFO — keep newest, evict oldest
            # Entries are newest-first (per CONSOLIDATION.md), so [:15] keeps newest
            recent_lines = self._extract_section(new_content, "Recent Activity")
            if len(recent_lines) > self._RECENT_MAX:
                keep = recent_lines[: self._RECENT_MAX]
                old_recent_text = "\n".join(recent_lines)
                new_recent_text = "\n".join(keep)
                new_content = new_content.replace(old_recent_text, new_recent_text)

            self.write_memory(new_content)

        entry_text = ""
        if history_match:
            summary = history_match.group(1).strip()
            if summary:
                entry_text = self.history.append(summary, messages or [], session_id)

        return entry_text

    # ── Fact lifecycle tracking ─────────────────────────────────────────

    def _read_fact_meta(self) -> dict[str, Any]:
        if self._fact_meta_path.is_file():
            try:
                data = json.loads(self._fact_meta_path.read_text(encoding="utf-8"))
                return data if isinstance(data, dict) else {}
            except (json.JSONDecodeError, OSError):
                pass
        return {}

    def _write_fact_meta(self, meta: dict[str, Any]) -> None:
        self._fact_meta_path.write_text(
            json.dumps(meta, default=str, ensure_ascii=False, indent=2), encoding="utf-8"
        )

    def _update_fact_lifecycle(
        self, old_facts: list[str], new_facts: list[str], dropped: list[str]
    ) -> None:
        """Update fact_meta.json after consolidation.

        Tracks per-fact: last_confirmed (date), zombie_count (recovery guard saves).
        - Facts in LLM output → last_confirmed = today, zombie_count = 0
        - Facts recovered by guard → zombie_count += 1
        - Facts no longer present → entry removed from meta
        """
        today = datetime.now(UTC).strftime("%Y-%m-%d")
        meta = self._read_fact_meta()
        facts_meta: dict[str, dict[str, Any]] = meta.get("facts", {})

        # All facts that appear in the LLM's new output → confirmed today
        new_keys = {self._entry_key(e) for e in new_facts}
        for key in new_keys:
            facts_meta[key] = {"last_confirmed": today, "zombie_count": 0}

        # Facts recovered by guard → zombie count increments
        for entry in dropped:
            key = self._entry_key(entry)
            existing = facts_meta.get(key, {})
            facts_meta[key] = {
                "last_confirmed": existing.get("last_confirmed", today),
                "zombie_count": existing.get("zombie_count", 0) + 1,
            }

        # Prune meta entries for facts no longer in memory
        all_current_keys = new_keys | {self._entry_key(e) for e in dropped}
        facts_meta = {k: v for k, v in facts_meta.items() if k in all_current_keys}

        meta["facts"] = facts_meta
        self._write_fact_meta(meta)

    def _compute_fact_usage_signals(self, existing_memory: str) -> str:
        """Compute usage signals from fact lifecycle metadata.

        Uses the LLM's own consolidation behavior as the ground truth:
        - last_confirmed: when the LLM last kept/updated this fact
        - zombie_count: how many times recovery guard had to save it
          (LLM tried to drop it but we prevented data loss)

        A fact with zombie_count >= 3 is one the LLM repeatedly considers
        irrelevant — strong candidate for eviction when space is needed.
        """
        facts = self._extract_section(existing_memory, "Facts")
        if not facts:
            return "(no facts to analyze)"

        meta = self._read_fact_meta()
        facts_meta: dict[str, dict[str, Any]] = meta.get("facts", {})
        if not facts_meta:
            return "(no lifecycle data yet — first consolidation)"

        today = datetime.now(UTC).strftime("%Y-%m-%d")

        stale: list[str] = []  # Not confirmed in 30+ days
        zombie: list[str] = []  # Recovered 3+ times

        for fact in facts:
            if fact.strip().startswith("doing:"):
                continue
            key = self._entry_key(fact)
            fm = facts_meta.get(key)
            if not fm:
                continue

            # Check staleness (not confirmed in 30+ days)
            last = fm.get("last_confirmed", "")
            if last and last < today[:8] + "01":  # Rough 30-day check
                try:
                    last_dt = datetime.fromisoformat(last)
                    age_days = (datetime.now(UTC) - last_dt.replace(tzinfo=UTC)).days
                    if age_days >= 30:
                        stale.append(f"{fact[:60]} (last confirmed {age_days}d ago)")
                except (ValueError, TypeError):
                    pass

            # Check zombie count
            zc = fm.get("zombie_count", 0)
            if zc >= 3:
                zombie.append(f"{fact[:60]} (dropped by LLM {zc}x, recovered each time)")

        lines: list[str] = []
        if zombie:
            lines.append("repeatedly dropped by LLM (strong eviction candidates):")
            for z in zombie[:5]:
                lines.append(f"  - {z}")
        if stale:
            lines.append("not confirmed in 30+ days (may be outdated):")
            for s in stale[:5]:
                lines.append(f"  - {s}")
        return "\n".join(lines) if lines else "(all facts appear active)"

    # ── Internal helpers ──────────────────────────────────────────────────

    @staticmethod
    def _entry_key(entry: str) -> str:
        """Extract a fingerprint for comparing Facts entries across consolidation.

        Uses the tag prefix (before colon) + first 3 alphanumeric tokens.
        This allows the LLM to update/expand an entry's details without
        triggering the recovery guard. E.g. "tech: Python 3.13" and
        "tech: Python 3.13, FastAPI, LiteLLM" share the same key.
        """
        line = entry.split("\n", 1)[0].strip().lower()
        if ":" not in line:
            return line
        tag, _, rest = line.partition(":")
        tokens = re.findall(r"[a-z0-9\u4e00-\u9fff]+", rest)[:3]
        return f"{tag}:{' '.join(tokens)}"

    @staticmethod
    def _extract_section(content: str, header: str) -> list[str]:
        # Use [ \t]*\n (not \s*\n) to avoid consuming blank lines that
        # separate this section from the next ## header. With \s*\n, an
        # empty section like "## Facts\n\n## Recent Activity" would leak
        # Recent Activity content into the Facts match.
        pattern = rf"## {header}[ \t]*\n(.*?)(?=\n## |\Z)"
        match = re.search(pattern, content, re.DOTALL)
        if not match:
            return []
        return [ln for ln in match.group(1).strip().splitlines() if ln.strip()]

    def close(self) -> None:
        """Release resources held by HistoryStore."""
        self.history.close()
