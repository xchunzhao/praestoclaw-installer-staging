"""
HistoryStore — HISTORY.md file + SQLite FTS5 search index.

Write once, two views: the file is for append/grep, the SQLite index
is for full-text search (auto-inject + search_history tool).

Also provides temporal decay scoring for search result re-ranking.

Split from memory.py for modularity — AgentMemory imports from here.
"""

from __future__ import annotations

import json
import math
import re
import sqlite3
from collections import OrderedDict
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from loguru import logger

# ── Temporal decay scoring ────────────────────────────────────────────────────

_DECAY_LAMBDA = math.log(2) / 30  # 30-day half-life: ln(2)/30 ≈ 0.0231


def apply_temporal_decay(results: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Re-score and re-sort search results with exponential temporal decay.

    Formula: ``decayed_score = bm25_norm × e^(-λ × age_days)``
    where λ = ln(2)/30 (30-day half-life).

    BM25 ``rank`` from FTS5 is negative (lower = better), so we normalise
    to [0, 1] before applying decay.  Results are returned sorted by
    ``decayed_score`` descending (higher = more relevant).
    """
    if not results:
        return results

    now = datetime.now(UTC)

    abs_ranks = [abs(r.get("rank", 0)) for r in results]
    max_rank = max(abs_ranks) if abs_ranks else 1.0
    max_rank = max_rank if max_rank > 0 else 1.0

    for r, ar in zip(results, abs_ranks):
        bm25_norm = ar / max_rank

        created = r.get("created_at", "")
        try:
            created_dt = datetime.fromisoformat(created)
            age_days = max((now - created_dt).total_seconds() / 86400, 0)
        except (ValueError, TypeError):
            age_days = 0

        r["decayed_score"] = bm25_norm * math.exp(-_DECAY_LAMBDA * age_days)

    results.sort(key=lambda r: r.get("decayed_score", 0), reverse=True)
    return results


# ── HistoryStore (HISTORY.md file + SQLite FTS5 index) ────────────────────────


class HistoryStore:
    """HISTORY.md file + SQLite FTS5 search index.

    Write once, two views: the file is for append/grep, the SQLite index
    is for full-text search (auto-inject + search_history tool).

    Parameters
    ----------
    base_dir:
        Directory for HISTORY.md and knowledge.db.
    """

    _DDL = [
        """
        CREATE TABLE IF NOT EXISTS knowledge (
            id         INTEGER PRIMARY KEY AUTOINCREMENT,
            content    TEXT    NOT NULL,
            category   TEXT    NOT NULL DEFAULT 'fact',
            source     TEXT    NOT NULL DEFAULT 'agent',
            created_at TEXT    NOT NULL,
            updated_at TEXT    NOT NULL
        )
        """,
        """
        CREATE VIRTUAL TABLE IF NOT EXISTS knowledge_fts
        USING fts5(content, tokenize='porter unicode61')
        """,
    ]

    _SPLIT_BYTES = 32 * 1024 * 1024  # 32 MB — split at day boundary
    _TOTAL_BYTES = 4 * 1024 * 1024 * 1024  # 4 GB — delete oldest archives

    # Notable calls extraction
    _WRITE_TOOLS = {"edit_file", "write_file", "shell", "git", "spawn", "notify"}
    _READ_ONLY_SKIP = {"read_file", "list_files", "search", "search_history"}

    # Old format detection: "## YYYY-MM-DD HH:MM" per-entry header
    _OLD_HISTORY_RE = re.compile(r"^## (\d{4}-\d{2}-\d{2})\s+(\d{2}:\d{2})$")

    def __init__(self, base_dir: Path) -> None:
        self._base_dir = base_dir
        self._path = base_dir / "HISTORY.md"

        # SQLite FTS5 index (filename kept as knowledge.db for backward compat)
        self._db_path = base_dir / "knowledge.db"
        base_dir.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(str(self._db_path))
        self._conn.row_factory = sqlite3.Row
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute("PRAGMA foreign_keys=ON")
        for stmt in self._DDL:
            self._conn.execute(stmt)
        self._conn.commit()

        self._maybe_migrate()

    @property
    def path(self) -> Path:
        """Return the HISTORY.md file path."""
        return self._path

    @property
    def base_dir(self) -> Path:
        """Return the base directory."""
        return self._base_dir

    # ── Write (file + index) ──────────────────────────────────────────────

    def append(
        self,
        summary: str,
        messages: list[dict[str, Any]],
        session_id: str,
    ) -> str:
        """Write a structured entry to HISTORY.md AND index in SQLite FTS5.

        Returns the full entry text (for logging/testing).
        """
        now = datetime.now(UTC)
        today = now.strftime("%Y-%m-%d")
        time_str = now.strftime("%H:%M")

        tools, files = self.extract_tools_and_files(messages)

        lines: list[str] = []
        if self._needs_day_header(today):
            lines.append(f"## {today}")
            lines.append("")  # blank line after header

        summary_lines = summary.strip().splitlines()
        lines.append(f"{time_str} {summary_lines[0]}")
        for sl in summary_lines[1:]:
            # LLM output already uses 2-space indent; don't double-indent
            if sl.startswith("  "):
                lines.append(sl)
            else:
                lines.append(f"  {sl}")
        if tools:
            lines.append(f"  tools: {' '.join(tools)}")
        if files:
            lines.append(f"  files: {' '.join(files)}")
        if session_id:
            lines.append(f"  session: {session_id}")

        entry_text = "\n".join(lines)

        # Write to file
        with self._path.open("a", encoding="utf-8") as f:
            f.write(f"\n{entry_text}\n")

        # Index in SQLite FTS5 (best-effort — file is source of truth)
        try:
            self._db_add(entry_text, category="history", source="consolidation")
        except Exception as exc:
            logger.error(
                "Failed to index history entry in FTS5 (file written, index diverged): {}", exc
            )

        # Check if split is needed
        self._maybe_split()

        return entry_text

    # ── Search ────────────────────────────────────────────────────────────

    def search(self, query: str, top_k: int = 10) -> list[dict[str, Any]]:
        """FTS5 BM25-ranked full-text search.

        Callers use ``fts5:`` prefix for raw FTS5 syntax, otherwise terms
        are auto-quoted for safe matching.
        """
        if not query.startswith("fts5:"):
            terms = query.split()
            safe_query = " ".join(f'"{t.replace(chr(34), "")}"' for t in terms if t)
        else:
            safe_query = query.removeprefix("fts5:")

        if not safe_query.strip():
            return []

        try:
            rows = self._conn.execute(
                """
                SELECT k.id, k.content, k.category, k.source,
                       k.created_at, k.updated_at,
                       knowledge_fts.rank AS rank
                FROM knowledge_fts
                JOIN knowledge k ON k.id = knowledge_fts.rowid
                WHERE knowledge_fts MATCH ?
                ORDER BY knowledge_fts.rank
                LIMIT ?
                """,
                (safe_query, top_k),
            ).fetchall()
        except sqlite3.OperationalError as exc:
            logger.warning(f"FTS5 query failed: {exc}")
            return []

        return [dict(r) for r in rows]

    def search_like(self, terms: list[str], top_k: int = 10) -> list[dict[str, Any]]:
        """SQL LIKE fallback for CJK terms (FTS5 unicode61 can't tokenize CJK).

        Strategy: AND first (all terms). If no results, OR with core terms
        (skip first/last bigrams which often span word boundaries).
        """
        if not terms:
            return []

        try:
            # Try AND first
            conditions = " AND ".join("content LIKE ?" for _ in terms)
            params: list[str | int] = [f"%{w}%" for w in terms]
            params.append(top_k)
            rows = self._conn.execute(
                f"""
                SELECT id, content, category, source, created_at, updated_at,
                       -1.0 AS rank
                FROM knowledge
                WHERE {conditions}
                ORDER BY created_at DESC
                LIMIT ?
                """,  # noqa: S608
                params,
            ).fetchall()

            if rows:
                return [dict(r) for r in rows]

            # Fallback: OR with core terms
            if len(terms) >= 2:
                core = terms[1:-1] if len(terms) > 2 else terms
                conditions = " OR ".join("content LIKE ?" for _ in core)
                params = [f"%{w}%" for w in core]
                params.append(top_k)
                rows = self._conn.execute(
                    f"""
                    SELECT id, content, category, source, created_at, updated_at,
                           -1.0 AS rank
                    FROM knowledge
                    WHERE {conditions}
                    ORDER BY created_at DESC
                    LIMIT ?
                    """,  # noqa: S608
                    params,
                ).fetchall()
                return [dict(r) for r in rows]

            return []
        except Exception:
            return []

    # ── Management ────────────────────────────────────────────────────────

    def count(self) -> int:
        """Return the total number of indexed entries."""
        row = self._conn.execute("SELECT COUNT(*) FROM knowledge").fetchone()
        return row[0] if row else 0

    def delete(self, id: int) -> None:
        """Delete an indexed entry by id."""
        self._conn.execute("DELETE FROM knowledge_fts WHERE rowid = ?", (id,))
        self._conn.execute("DELETE FROM knowledge WHERE id = ?", (id,))
        self._conn.commit()

    def clear_all(self) -> int:
        """Delete all indexed entries. Returns the number deleted."""
        n = self.count()
        self._conn.execute("DELETE FROM knowledge_fts")
        self._conn.execute("DELETE FROM knowledge")
        self._conn.commit()
        return n

    def list_recent(self, top_k: int = 50) -> list[dict[str, Any]]:
        """Return the most recent entries ordered by creation time (newest first)."""
        rows = self._conn.execute(
            """
            SELECT id, content, category, source, created_at, updated_at
            FROM knowledge
            ORDER BY created_at DESC
            LIMIT ?
            """,
            (top_k,),
        ).fetchall()
        return [dict(r) for r in rows]

    def read_tail(self, last_n_lines: int = 200) -> str:
        """Read the tail of the HISTORY.md file."""
        if not self._path.is_file():
            return ""
        lines = self._path.read_text(encoding="utf-8").splitlines()
        return "\n".join(lines[-last_n_lines:])

    def close(self) -> None:
        """Close the SQLite connection."""
        self._conn.close()

    # ── Notable calls extraction (static helpers) ─────────────────────────

    @staticmethod
    def _parse_tool_args(raw: str | dict[str, Any]) -> dict[str, Any]:
        if isinstance(raw, dict):
            return raw
        try:
            result: dict[str, Any] = json.loads(raw)
            return result
        except Exception:
            return {}

    @staticmethod
    def _summarize_args(name: str, args: dict[str, Any]) -> str:
        if name == "shell":
            return str(args.get("command", ""))[:100]
        if name in ("edit_file", "write_file", "read_file"):
            path = args.get("path", args.get("file_path", args.get("file", "")))
            return str(path)
        if name == "git":
            sub = args.get("subcommand", args.get("command", ""))
            return str(sub)[:80]
        for v in args.values():
            if isinstance(v, str) and len(v) > 2:
                return v[:80]
        return ""

    @classmethod
    def _find_tool_result(cls, messages: list[dict[str, Any]], tool_call_id: str) -> dict[str, Any]:
        for m in messages:
            if m.get("role") == "tool" and m.get("tool_call_id") == tool_call_id:
                return m
        return {}

    @classmethod
    def _is_notable(cls, name: str, result: dict[str, Any]) -> bool:
        if result.get("is_error"):
            return True
        if name in cls._READ_ONLY_SKIP:
            return False
        if name in cls._WRITE_TOOLS:
            return True
        if name.startswith("MCP_") or name.startswith("mcp_"):
            return True
        return False

    @classmethod
    def extract_notable_calls(cls, messages: list[dict[str, Any]]) -> list[str]:
        """Extract notable tool call summaries from messages.

        Returns one-line summaries for tool calls that are writes, MCP
        queries, or failures. Used as LLM input for consolidation.
        """
        notable: list[str] = []
        seen: set[str] = set()

        for m in messages:
            for tc in m.get("tool_calls", []):
                fn = tc.get("function", {})
                name = fn.get("name", "")
                if not name:
                    continue
                tc_id = tc.get("id", "")
                args = cls._parse_tool_args(fn.get("arguments", "{}"))
                result = cls._find_tool_result(messages, tc_id) if tc_id else {}

                if not cls._is_notable(name, result):
                    continue

                args_summary = cls._summarize_args(name, args)
                dedup_key = f"{name}:{args_summary}"
                if dedup_key in seen:
                    continue
                seen.add(dedup_key)

                result_content = result.get("content", "")
                is_error = result.get("is_error", False)
                preview = result_content[:80].replace("\n", " ").strip()

                if is_error:
                    line = f"ERROR {name}({args_summary})"
                    if preview:
                        line += f" → {preview}"
                else:
                    line = f"{name}({args_summary})"
                    if preview:
                        line += f" → {preview}"

                notable.append(line)

        return notable

    @classmethod
    def extract_tools_and_files(cls, messages: list[dict[str, Any]]) -> tuple[list[str], list[str]]:
        """Extract tool names and file paths from notable tool calls only."""
        tools: set[str] = set()
        files: set[str] = set()
        for m in messages:
            for tc in m.get("tool_calls", []):
                fn = tc.get("function", {})
                name = fn.get("name", "")
                if not name:
                    continue
                tc_id = tc.get("id", "")
                args = cls._parse_tool_args(fn.get("arguments", "{}"))
                result = cls._find_tool_result(messages, tc_id) if tc_id else {}

                if not cls._is_notable(name, result):
                    continue

                tools.add(name)
                for key in ("path", "file", "file_path", "filename"):
                    val = args.get(key, "")
                    if val and isinstance(val, str):
                        files.add(val)
        return sorted(tools), sorted(files)

    # ── Internal: SQLite helpers ──────────────────────────────────────────

    def _db_add(self, content: str, category: str = "fact", source: str = "agent") -> int:
        now = datetime.now(UTC).isoformat()
        cur = self._conn.execute(
            "INSERT INTO knowledge (content, category, source, created_at, updated_at) VALUES (?, ?, ?, ?, ?)",
            (content, category, source, now, now),
        )
        row_id = cur.lastrowid
        assert row_id is not None
        self._conn.execute(
            "INSERT INTO knowledge_fts(rowid, content) VALUES (?, ?)",
            (row_id, content),
        )
        self._conn.commit()
        return row_id

    # ── Internal: File helpers ────────────────────────────────────────────

    def _needs_day_header(self, today: str) -> bool:
        """Check whether today's ``## YYYY-MM-DD`` header already exists."""
        if not self._path.is_file():
            return True
        try:
            content = self._path.read_text(encoding="utf-8")
            tail = content[-4096:]
            return f"## {today}" not in tail
        except Exception:
            return True

    def _maybe_split(self) -> None:
        """Split HISTORY.md at a day boundary when it exceeds 32 MB."""
        if not self._path.is_file():
            return
        if self._path.stat().st_size <= self._SPLIT_BYTES:
            return

        content = self._path.read_text(encoding="utf-8")
        day_pattern = re.compile(r"^## (\d{4}-\d{2}-\d{2})", re.MULTILINE)
        headers = list(day_pattern.finditer(content))
        if len(headers) < 2:
            return

        split_pos = headers[-1].start()
        archive_content = content[:split_pos]
        remaining_content = content[split_pos:]

        last_archive_day = headers[-2].group(1)
        archive_dir = self._base_dir / "HISTORY"
        archive_dir.mkdir(parents=True, exist_ok=True)
        archive_name = f"{last_archive_day}.md"
        archive_path = archive_dir / archive_name

        if archive_path.is_file():
            with archive_path.open("a", encoding="utf-8") as f:
                f.write(archive_content)
        else:
            archive_path.write_text(archive_content, encoding="utf-8")

        self._path.write_text(remaining_content, encoding="utf-8")
        logger.info(f"History split: {archive_name} ({len(archive_content)} chars)")

        self._enforce_total_cap()

    def _enforce_total_cap(self) -> None:
        """Delete oldest archives if total exceeds 4 GB."""
        archive_dir = self._base_dir / "HISTORY"
        if not archive_dir.is_dir():
            return
        history_files = sorted(archive_dir.glob("*.md"))
        if not history_files:
            return

        total = self._path.stat().st_size if self._path.is_file() else 0
        total += sum(f.stat().st_size for f in history_files)

        if total <= self._TOTAL_BYTES:
            return

        for archive in history_files:
            if total <= self._TOTAL_BYTES:
                break
            size = archive.stat().st_size
            archive.unlink()
            total -= size
            logger.info(f"History cap: deleted {archive.name} ({size} bytes)")

    # ── Internal: Migration ───────────────────────────────────────────────

    def _maybe_migrate(self) -> None:
        """Auto-migrate old HISTORY.md format (## YYYY-MM-DD HH:MM per entry)."""
        if not self._path.is_file():
            return
        try:
            content = self._path.read_text(encoding="utf-8")
        except Exception:
            return

        for line in content.splitlines():
            if line.startswith("## "):
                if self._OLD_HISTORY_RE.match(line):
                    break
                return

        lines = content.splitlines()
        days: OrderedDict[str, list[tuple[str, list[str]]]] = OrderedDict()
        cur_day: str | None = None
        cur_time: str | None = None
        cur_lines: list[str] = []

        def flush() -> None:
            nonlocal cur_day, cur_time, cur_lines
            if cur_day and cur_time and cur_lines:
                text = [ln for ln in cur_lines if ln.strip()]
                if text:
                    days.setdefault(cur_day, []).append((cur_time, text))
            cur_lines = []

        for line in lines:
            m = self._OLD_HISTORY_RE.match(line)
            if m:
                flush()
                cur_day = m.group(1)
                cur_time = m.group(2)
            elif line.startswith("## "):
                flush()
                day_m = re.match(r"^## (\d{4}-\d{2}-\d{2})$", line)
                if day_m:
                    cur_day = day_m.group(1)
                    cur_time = None
            elif line.strip():
                if cur_day and cur_time is None:
                    time_m = re.match(r"^(\d{2}:\d{2})\s+(.*)$", line)
                    if time_m:
                        flush()
                        cur_time = time_m.group(1)
                        cur_lines.append(time_m.group(2))
                    else:
                        cur_lines.append(line)
                else:
                    cur_lines.append(line)

        flush()

        if not days:
            return

        for day in days:
            seen: set[str] = set()
            deduped: list[tuple[str, list[str]]] = []
            for t, text in days[day]:
                key = f"{t}:{text[0].strip().lower()}"
                if key not in seen:
                    seen.add(key)
                    deduped.append((t, text))
            days[day] = deduped

        out: list[str] = []
        for day, entries in days.items():
            out.append(f"\n## {day}\n")
            for t, text in entries:
                out.append(f"{t} {text[0]}")
                for el in text[1:]:
                    out.append(f"  {el}")
                out.append("")

        new_content = "\n".join(out).strip() + "\n"

        try:
            bak = self._path.with_suffix(".md.bak")
            if not bak.exists():
                self._path.rename(bak)
            else:
                self._path.rename(self._path.with_suffix(".md.old"))
            self._path.write_text(new_content, encoding="utf-8")
            logger.info(
                "Migrated HISTORY.md: {} entries across {} days",
                sum(len(v) for v in days.values()),
                len(days),
            )
        except Exception as exc:
            logger.warning("HISTORY.md migration failed: {}", exc)
