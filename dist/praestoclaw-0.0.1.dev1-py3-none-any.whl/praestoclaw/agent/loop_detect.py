"""
Loop detection — prevents the LLM from getting stuck in repetitive patterns.

Three detectors:
- RepeatDetector: same tool + same args called 3+ times consecutively
- PollDetector: tool called, result checked, same tool called again
- PingPongDetector: two tools alternating back and forth 4+ times
"""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass

from loguru import logger


@dataclass
class ToolCall:
    """Record of a single tool invocation for pattern matching."""

    name: str
    args_hash: str


def _hash_args(args: dict) -> str:
    """Deterministic hash of tool arguments for comparison."""
    return hashlib.md5(json.dumps(args, sort_keys=True).encode()).hexdigest()[:12]


class RepeatDetector:
    """Detect same tool+args called N+ times consecutively."""

    def __init__(self, threshold: int = 3) -> None:
        self._threshold = threshold
        self._history: list[ToolCall] = []

    def check(self, name: str, args_hash: str) -> str | None:
        tc = ToolCall(name=name, args_hash=args_hash)
        self._history.append(tc)

        if len(self._history) < self._threshold:
            return None

        recent = self._history[-self._threshold :]
        if all(c.name == tc.name and c.args_hash == tc.args_hash for c in recent):
            return (
                f"IMPORTANT: You are repeating the same action ({name}) with identical "
                f"arguments {self._threshold} times. The result is unlikely to change. "
                "You MUST try a different approach: "
                "(1) use different arguments, "
                "(2) try a different tool, or "
                "(3) explain why the task cannot be completed."
            )
        return None


class PollDetector:
    """Detect polling pattern: tool A called, then called again with same args."""

    def __init__(self) -> None:
        self._last_two: list[ToolCall] = []

    def check(self, name: str, args_hash: str) -> str | None:
        tc = ToolCall(name=name, args_hash=args_hash)
        self._last_two.append(tc)
        if len(self._last_two) > 3:
            self._last_two = self._last_two[-3:]

        if len(self._last_two) >= 3:
            a, _b, c = self._last_two[-3], self._last_two[-2], self._last_two[-1]
            if a.name == c.name and a.args_hash == c.args_hash and a.name != _b.name:
                return (
                    f"IMPORTANT: You appear to be polling ({name}). "
                    "The result is unlikely to change between checks. "
                    "Try a different approach or increase wait time."
                )
        return None


class PingPongDetector:
    """Detect two tools alternating: A-B-A-B pattern 4+ times."""

    def __init__(self, threshold: int = 4) -> None:
        self._threshold = threshold
        self._history: list[str] = []

    def check(self, name: str, args_hash: str) -> str | None:
        self._history.append(name)

        needed = self._threshold * 2
        if len(self._history) < needed:
            return None

        recent = self._history[-needed:]
        tool_a = recent[0]
        tool_b = recent[1]
        if tool_a == tool_b:
            return None

        is_pingpong = all(recent[i] == (tool_a if i % 2 == 0 else tool_b) for i in range(needed))
        if is_pingpong:
            return (
                f"IMPORTANT: You are alternating between {tool_a} and {tool_b} "
                "without progress. Step back, analyze what you have, "
                "and try a completely different approach."
            )
        return None


class LoopDetector:
    """Aggregate detector — runs all three detectors and tracks warning state.

    After injecting a warning, if the same pattern is detected again on the
    next tool call, returns a termination signal.
    """

    def __init__(
        self,
        *,
        repeat_threshold: int = 3,
        pingpong_threshold: int = 4,
    ) -> None:
        self._repeat = RepeatDetector(threshold=repeat_threshold)
        self._poll = PollDetector()
        self._pingpong = PingPongDetector(threshold=pingpong_threshold)
        self._warned = False

    def check(self, name: str, args: dict) -> tuple[str | None, bool]:
        """Check for loop patterns.

        Returns:
            (warning_message, should_terminate)
            - (None, False): no loop detected
            - ("...", False): first detection — inject warning message
            - ("...", True): persistent loop — terminate the agent loop
        """
        args_hash = _hash_args(args)

        for detector in (self._repeat, self._poll, self._pingpong):
            msg = detector.check(name, args_hash)
            if msg:
                if self._warned:
                    logger.warning("Loop persists after warning — terminating: {}", msg)
                    return msg, True
                else:
                    logger.warning("Loop detected: {}", msg)
                    self._warned = True
                    return msg, False

        # No loop detected — reset warned state
        self._warned = False
        return None, False
