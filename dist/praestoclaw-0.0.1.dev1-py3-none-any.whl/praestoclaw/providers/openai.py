"""OpenAI provider backend — Chat Completions + Responses API."""

from __future__ import annotations

import json
import re
import time
from collections.abc import AsyncIterator
from typing import Any

from openai import AsyncOpenAI

from praestoclaw.providers.base import LLMChunk, LLMProvider, LLMResponse, ToolCallRequest

_RESPONSES_MODEL_RE = re.compile(r"^(o[1-9]|o\d+-)")


class OpenAIProvider(LLMProvider):
    """OpenAI provider with Chat Completions + Responses API support."""

    def __init__(
        self,
        api_key: str,
        base_url: str | None = None,
        *,
        api_mode: str = "chat_completions",
        organization: str | None = None,
    ) -> None:
        self._api_key = api_key
        self._base_url = base_url
        self._api_mode_setting = api_mode
        self._organization = organization
        self._client: AsyncOpenAI | None = None

    # -- Properties ----------------------------------------------------------

    @property
    def api_mode(self) -> str:
        return self._api_mode_setting if self._api_mode_setting != "auto" else "chat_completions"

    # -- Client --------------------------------------------------------------

    def _get_client(self) -> AsyncOpenAI:
        if self._client is None:
            self._client = AsyncOpenAI(
                api_key=self._api_key,
                base_url=self._base_url,
                organization=self._organization,
            )
        return self._client

    # -- Mode resolution -----------------------------------------------------

    def _resolve_api_mode(self, model: str) -> str:
        if self._api_mode_setting != "auto":
            return self._api_mode_setting
        if _RESPONSES_MODEL_RE.match(model):
            return "responses"
        return "chat_completions"

    # -- Complete ------------------------------------------------------------

    async def complete(
        self,
        *,
        model: str,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
        temperature: float | None = None,
        max_tokens: int | None = None,
        reasoning_effort: str | None = None,
    ) -> LLMResponse:
        mode = self._resolve_api_mode(model)
        if mode == "responses":
            return await self._complete_responses(
                model=model,
                messages=messages,
                tools=tools,
                temperature=temperature,
                max_tokens=max_tokens,
                reasoning_effort=reasoning_effort,
            )
        return await self._complete_chat(
            model=model,
            messages=messages,
            tools=tools,
            temperature=temperature,
            max_tokens=max_tokens,
            reasoning_effort=reasoning_effort,
        )

    async def _complete_chat(
        self,
        *,
        model: str,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
        temperature: float | None = None,
        max_tokens: int | None = None,
        reasoning_effort: str | None = None,
    ) -> LLMResponse:
        client = self._get_client()
        kwargs: dict[str, Any] = {"model": model, "messages": messages}
        if tools:
            kwargs["tools"] = tools
        if temperature is not None:
            kwargs["temperature"] = temperature
        if max_tokens is not None:
            kwargs["max_tokens"] = max_tokens
        if reasoning_effort is not None:
            kwargs["reasoning_effort"] = reasoning_effort

        t0 = time.monotonic()
        resp = await client.chat.completions.create(**kwargs)
        duration_ms = (time.monotonic() - t0) * 1000

        choice = resp.choices[0]
        msg = choice.message

        tool_calls = _parse_tool_calls(msg.tool_calls) if msg.tool_calls else []

        return LLMResponse(
            content=msg.content or "",
            tool_calls=tool_calls,
            finish_reason=choice.finish_reason or "stop",
            model=resp.model,
            prompt_tokens=resp.usage.prompt_tokens if resp.usage else 0,
            completion_tokens=resp.usage.completion_tokens if resp.usage else 0,
            duration_ms=duration_ms,
        )

    async def _complete_responses(
        self,
        *,
        model: str,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
        temperature: float | None = None,
        max_tokens: int | None = None,
        reasoning_effort: str | None = None,
    ) -> LLMResponse:
        client = self._get_client()
        kwargs: dict[str, Any] = {"model": model, "input": messages}
        if tools:
            kwargs["tools"] = tools
        if temperature is not None:
            kwargs["temperature"] = temperature
        if max_tokens is not None:
            kwargs["max_output_tokens"] = max_tokens
        if reasoning_effort is not None:
            kwargs["reasoning"] = {"effort": reasoning_effort}

        t0 = time.monotonic()
        resp = await client.responses.create(**kwargs)
        duration_ms = (time.monotonic() - t0) * 1000

        content = ""
        tool_calls: list[ToolCallRequest] = []
        reasoning_content: str | None = None

        for item in resp.output:
            if getattr(item, "type", None) == "message":
                for part in item.content:
                    if getattr(part, "type", None) == "output_text":
                        content += part.text
            elif getattr(item, "type", None) == "function_call":
                args = _safe_json_loads(item.arguments)
                tool_calls.append(ToolCallRequest(id=item.call_id, name=item.name, arguments=args))
            elif getattr(item, "type", None) == "reasoning":
                for part in getattr(item, "summary", []):
                    if getattr(part, "type", None) == "summary_text":
                        reasoning_content = (reasoning_content or "") + part.text

        usage = getattr(resp, "usage", None)
        return LLMResponse(
            content=content,
            tool_calls=tool_calls,
            finish_reason="tool_calls" if tool_calls else "stop",
            model=resp.model if hasattr(resp, "model") else model,
            prompt_tokens=usage.input_tokens if usage else 0,
            completion_tokens=usage.output_tokens if usage else 0,
            duration_ms=duration_ms,
            reasoning_content=reasoning_content,
        )

    # -- Stream --------------------------------------------------------------

    async def stream(
        self,
        *,
        model: str,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
        temperature: float | None = None,
        max_tokens: int | None = None,
        reasoning_effort: str | None = None,
    ) -> AsyncIterator[LLMChunk]:
        mode = self._resolve_api_mode(model)
        if mode == "responses":
            # Responses API: complete then yield one chunk
            response = await self.complete(
                model=model,
                messages=messages,
                tools=tools,
                temperature=temperature,
                max_tokens=max_tokens,
                reasoning_effort=reasoning_effort,
            )
            yield LLMChunk(
                content=response.content,
                tool_calls=response.tool_calls,
                finish_reason=response.finish_reason,
                model=response.model,
            )
            return

        # Chat completions: real SSE streaming
        client = self._get_client()
        kwargs: dict[str, Any] = {"model": model, "messages": messages, "stream": True}
        if tools:
            kwargs["tools"] = tools
        if temperature is not None:
            kwargs["temperature"] = temperature
        if max_tokens is not None:
            kwargs["max_tokens"] = max_tokens

        accumulated_tool_calls: dict[int, dict[str, Any]] = {}

        async for event in await client.chat.completions.create(**kwargs):
            delta = event.choices[0].delta if event.choices else None
            finish = event.choices[0].finish_reason if event.choices else None

            content = ""
            if delta and delta.content:
                content = delta.content

            # Accumulate tool calls
            if delta and delta.tool_calls:
                for tc in delta.tool_calls:
                    idx = tc.index
                    if idx not in accumulated_tool_calls:
                        accumulated_tool_calls[idx] = {
                            "id": tc.id or "",
                            "name": getattr(tc.function, "name", "") or "",
                            "arguments": "",
                        }
                    else:
                        if tc.id:
                            accumulated_tool_calls[idx]["id"] = tc.id
                        if getattr(tc.function, "name", None):
                            accumulated_tool_calls[idx]["name"] = tc.function.name
                    if getattr(tc.function, "arguments", None):
                        accumulated_tool_calls[idx]["arguments"] += tc.function.arguments

            # Emit tool calls on finish
            final_tool_calls: list[ToolCallRequest] = []
            if finish:
                for _idx in sorted(accumulated_tool_calls):
                    tc_data = accumulated_tool_calls[_idx]
                    args = _safe_json_loads(tc_data["arguments"])
                    final_tool_calls.append(
                        ToolCallRequest(id=tc_data["id"], name=tc_data["name"], arguments=args)
                    )

            if content or finish or final_tool_calls:
                yield LLMChunk(
                    content=content,
                    tool_calls=final_tool_calls,
                    finish_reason=finish,
                    model=event.model or model,
                )


# -- Helpers -----------------------------------------------------------------


def _parse_tool_calls(raw_tool_calls: list[Any]) -> list[ToolCallRequest]:
    result: list[ToolCallRequest] = []
    for tc in raw_tool_calls:
        args = _safe_json_loads(tc.function.arguments)
        result.append(ToolCallRequest(id=tc.id, name=tc.function.name, arguments=args))
    return result


def _safe_json_loads(s: str) -> dict[str, Any]:
    try:
        return json.loads(s)  # type: ignore[no-any-return]
    except (json.JSONDecodeError, TypeError):
        return {"raw": s}
