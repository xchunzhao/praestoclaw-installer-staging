"""
Instance ID persistence helper for stable A2A registration.
"""

from __future__ import annotations

import secrets
from pathlib import Path

from loguru import logger


def _generate_instance_id() -> str:
    """Generate a new instance ID using base32 encoding (URL-safe)."""
    # Generate 10 random bytes -> ~16 chars base32
    return f"wp_{secrets.token_urlsafe(10)[:16].replace('-', '').replace('_', '')}"


def get_or_create_instance_id(data_dir: Path) -> str:
    """Read or create stable instance ID for A2A registration.

    Instance ID persists across restarts in <data_dir>/instance_id.txt.
    """
    instance_file = data_dir / "instance_id.txt"

    # Try to read existing ID
    if instance_file.exists():
        try:
            instance_id = instance_file.read_text(encoding="utf-8").strip()
            if instance_id:
                logger.debug("Loaded existing instance_id from {}", instance_file)
                return instance_id
        except Exception as exc:
            logger.warning("Failed to read instance_id from {}: {}", instance_file, exc)

    # Generate new ID
    instance_id = _generate_instance_id()
    try:
        instance_file.parent.mkdir(parents=True, exist_ok=True)
        instance_file.write_text(instance_id, encoding="utf-8")
        logger.info("Generated new instance_id: {} (persisted to {})", instance_id, instance_file)
    except Exception as exc:
        logger.warning("Failed to persist instance_id to {}: {}", instance_file, exc)

    return instance_id
