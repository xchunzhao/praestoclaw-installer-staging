"""
Agent Card seed generation for A2A Phase 1 registration.
"""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, Field

from praestoclaw import __version__


class CardCapabilities(BaseModel):
    """Agent capabilities advertised in card seed."""

    streaming: bool = True
    pushNotifications: bool = False  # noqa: N815 — A2A protocol wire-format field
    extendedAgentCard: bool = False  # noqa: N815 — A2A protocol wire-format field


class CardProvider(BaseModel):
    """Provider info for agent card."""

    organization: str = "PraestoClaw"


class CardSeed(BaseModel):
    """Agent Card seed content — PraestoClaw provides this, Gateway adds URLs."""

    name: str = "PraestoClaw"
    description: str = "Local enterprise coding and office agent"
    version: str = __version__
    provider: CardProvider = Field(default_factory=CardProvider)
    capabilities: CardCapabilities = Field(default_factory=CardCapabilities)
    skills: list[str] = Field(default_factory=list)


def generate_card_seed(
    *,
    name: str | None = None,
    description: str | None = None,
    skills: list[str] | None = None,
) -> dict[str, Any]:
    """Generate Agent Card seed content for registration.

    Phase 1: minimal card with camelCase keys for Gateway consumption.
    """
    seed = CardSeed(
        name=name or "PraestoClaw",
        description=description or "Local enterprise coding and office agent",
        skills=skills or [],
    )
    return seed.model_dump(by_alias=True, mode="json")
