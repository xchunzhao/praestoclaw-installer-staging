"""
MCP transport layer — abstractions for stdio and HTTP/SSE communication.

Provides pluggable transports for the Model Context Protocol (MCP) using
JSON-RPC 2.0 message framing over stdin/stdout or HTTP.
"""

from __future__ import annotations

import asyncio
import json
from abc import ABC, abstractmethod
from typing import Any

import httpx
from loguru import logger


class MCPTransport(ABC):
    """Abstract transport for MCP JSON-RPC communication."""

    @abstractmethod
    async def start(self) -> None:
        """Open the transport connection."""

    @abstractmethod
    async def send(self, data: dict[str, Any]) -> None:
        """Send a JSON-RPC message."""

    @abstractmethod
    async def receive(self) -> dict[str, Any]:
        """Receive the next JSON-RPC message (blocks until available)."""

    @abstractmethod
    async def close(self) -> None:
        """Close the transport and release resources."""


class StdioTransport(MCPTransport):
    """
    Communicate with an MCP server via subprocess stdin/stdout.

    Each message is a single JSON line terminated by newline.
    """

    def __init__(
        self,
        command: str,
        args: list[str] | None = None,
        env: dict[str, str] | None = None,
    ) -> None:
        self._command = command
        self._args = args or []
        self._env = env
        self._process: asyncio.subprocess.Process | None = None
        self._read_lock = asyncio.Lock()

    async def start(self) -> None:
        """Spawn the subprocess and prepare stdin/stdout streams."""
        import os

        # Merge extra env vars with current environment
        proc_env = {**os.environ, **self._env} if self._env else None
        logger.debug(f"StdioTransport: spawning {self._command} {self._args}")
        self._process = await asyncio.create_subprocess_exec(
            self._command,
            *self._args,
            stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            limit=1024 * 1024,  # 1MB line limit (large tool lists from MCP servers)
            env=proc_env,
        )
        logger.debug(f"StdioTransport: process started (pid={self._process.pid})")

    async def send(self, data: dict[str, Any]) -> None:
        """Write a JSON-RPC message to the subprocess stdin."""
        if self._process is None or self._process.stdin is None:
            raise RuntimeError("StdioTransport: not connected — call start() first")

        line = json.dumps(data) + "\n"
        self._process.stdin.write(line.encode("utf-8"))
        await self._process.stdin.drain()
        logger.debug(f"StdioTransport: sent message id={data.get('id')}")

    async def _drain_stderr_tail(self, max_bytes: int = 2048) -> str:
        """Best-effort read of any pending stderr content (non-blocking).

        Used to enrich ConnectionError messages when a subprocess exits before
        completing the MCP handshake. Returns "" if stderr is unavailable or
        no data is buffered.
        """
        if self._process is None or self._process.stderr is None:
            return ""
        try:
            # Wait briefly so the OS pipe gets the child's final stderr lines
            # after the stdout EOF we just observed. 200 ms is enough in practice.
            data = await asyncio.wait_for(self._process.stderr.read(max_bytes), timeout=0.2)
        except (TimeoutError, Exception):
            return ""
        if not data:
            return ""
        text = data.decode("utf-8", errors="replace").strip()
        # Keep only the last ~6 lines so we don't dump a screenful into the log.
        lines = [ln for ln in text.splitlines() if ln.strip()]
        return " | ".join(lines[-6:])

    async def receive(self) -> dict[str, Any]:
        """Read the next JSON-RPC message from subprocess stdout."""
        if self._process is None or self._process.stdout is None:
            raise RuntimeError("StdioTransport: not connected — call start() first")

        async with self._read_lock:
            raw = await self._process.stdout.readline()
            if not raw:
                tail = await self._drain_stderr_tail()
                rc = self._process.returncode if self._process is not None else None
                detail = f" (exit={rc}; stderr: {tail})" if tail else f" (exit={rc})"
                raise ConnectionError(f"StdioTransport: subprocess stdout closed{detail}")

        line = raw.decode("utf-8").strip()
        if not line:
            raise ConnectionError("StdioTransport: received empty line")

        try:
            return json.loads(line)  # type: ignore[no-any-return]
        except json.JSONDecodeError as exc:
            raise ConnectionError(f"StdioTransport: invalid JSON from subprocess: {exc}") from exc

    async def close(self) -> None:
        """Terminate the subprocess gracefully."""
        if self._process is None:
            return

        logger.debug("StdioTransport: closing subprocess")
        if self._process.stdin is not None:
            self._process.stdin.close()

        try:
            await asyncio.wait_for(self._process.wait(), timeout=5.0)
        except TimeoutError:
            logger.warning("StdioTransport: subprocess did not exit, killing")
            self._process.kill()
            await self._process.wait()

        self._process = None
        logger.debug("StdioTransport: subprocess closed")

    @property
    def is_running(self) -> bool:
        """Check if the subprocess is still alive."""
        return self._process is not None and self._process.returncode is None


class HttpTransport(MCPTransport):
    """
    Communicate with an MCP server via HTTP POST / Server-Sent Events (SSE).

    - send(): POST JSON-RPC messages to the server endpoint.
    - receive(): Read SSE events from the server's event stream.
    """

    def __init__(
        self,
        url: str,
        *,
        headers: dict[str, str] | None = None,
        auth: httpx.Auth | None = None,
        skip_sse: bool = False,
    ) -> None:
        self._url = url.rstrip("/")
        self._headers = headers or {}
        self._auth = auth
        self._skip_sse = skip_sse
        self._client: httpx.AsyncClient | None = None
        self._sse_response: httpx.Response | None = None
        self._sse_iter: Any = None
        self._message_queue: asyncio.Queue[dict[str, Any]] = asyncio.Queue()
        self._sse_task: asyncio.Task[None] | None = None

    async def start(self) -> None:
        """Initialize the HTTP client and optionally start the SSE listener."""
        logger.debug(f"HttpTransport: connecting to {self._url}")
        self._client = httpx.AsyncClient(
            timeout=60.0,
            headers={
                "Content-Type": "application/json",
                **self._headers,
            },
            auth=self._auth,
            follow_redirects=True,
        )
        if not self._skip_sse:
            self._sse_task = asyncio.create_task(self._listen_sse())
        logger.debug(f"HttpTransport: connected to {self._url}")

    async def send(self, data: dict[str, Any]) -> None:
        """POST a JSON-RPC message to the MCP server.

        Handles two HTTP transport variants:
        - HTTP+SSE (legacy): server returns 202/empty; responses arrive on GET /sse.
        - HTTP Streamable (MCP 2025-03-26): server streams SSE events directly from
          the POST response body (Accept: application/json, text/event-stream).
        """
        if self._client is None:
            raise RuntimeError("HttpTransport: not connected — call start() first")

        logger.debug(f"HttpTransport: sending message id={data.get('id')}")
        async with self._client.stream(
            "POST",
            self._url,
            json=data,
            headers={"Accept": "application/json, text/event-stream"},
        ) as response:
            if not response.is_success:
                # Use httpx error (preserves request/response context)
                # but strip MDN link by customizing the message.
                raise httpx.HTTPStatusError(
                    f"{response.status_code} {response.reason_phrase} for {self._url}",
                    request=response.request,
                    response=response,
                )
            content_type = response.headers.get("content-type", "")

            if "text/event-stream" in content_type:
                # HTTP Streamable: read SSE events directly from POST response.
                buffer = ""
                async for chunk in response.aiter_text():
                    # Normalize CRLF → LF so "\n\n" reliably marks event boundaries.
                    buffer += chunk.replace("\r\n", "\n")
                    while "\n\n" in buffer:
                        event_block, buffer = buffer.split("\n\n", 1)
                        message = self._parse_sse_event(event_block)
                        if message is not None:
                            await self._message_queue.put(message)
            elif "application/json" in content_type:
                # Direct JSON response (single-message mode).
                try:
                    body = json.loads(await response.aread())
                    if isinstance(body, dict) and "jsonrpc" in body:
                        await self._message_queue.put(body)
                except (json.JSONDecodeError, ValueError):
                    pass

    async def receive(self) -> dict[str, Any]:
        """Get the next JSON-RPC message (from SSE stream or direct response)."""
        return await self._message_queue.get()

    async def _listen_sse(self) -> None:
        """Background task for legacy HTTP+SSE transport (GET /sse endpoint).

        Silently skips if the server does not expose a /sse endpoint — HTTP
        Streamable servers (MCP 2025-03-26) deliver responses via POST instead.
        """
        if self._client is None:
            return

        sse_url = self._url.rstrip("/") + "/sse"
        try:
            async with self._client.stream("GET", sse_url) as response:
                if response.status_code in (400, 404, 405, 410):
                    logger.debug(
                        f"HttpTransport: no /sse endpoint ({response.status_code})"
                        " — using HTTP Streamable POST responses"
                    )
                    return
                # Raise for any other non-2xx status so failures surface clearly.
                if not response.is_success:
                    raise httpx.HTTPStatusError(
                        f"{response.status_code} {response.reason_phrase} for {sse_url}",
                        request=response.request,
                        response=response,
                    )
                self._sse_response = response
                buffer = ""
                async for chunk in response.aiter_text():
                    buffer += chunk.replace("\r\n", "\n")
                    while "\n\n" in buffer:
                        event_block, buffer = buffer.split("\n\n", 1)
                        message = self._parse_sse_event(event_block)
                        if message is not None:
                            await self._message_queue.put(message)
        except httpx.HTTPError as exc:
            logger.warning(f"HttpTransport: SSE connection error: {exc}")
        except asyncio.CancelledError:
            logger.debug("HttpTransport: SSE listener cancelled")

    @staticmethod
    def _parse_sse_event(block: str) -> dict[str, Any] | None:
        """Parse a single SSE event block into a JSON-RPC message."""
        data_lines: list[str] = []
        for line in block.split("\n"):
            if line.startswith("data:"):
                data_lines.append(line[5:].strip())
        if not data_lines:
            return None
        raw = "\n".join(data_lines)
        try:
            return json.loads(raw)  # type: ignore[no-any-return]
        except json.JSONDecodeError:
            logger.debug(f"HttpTransport: non-JSON SSE data: {raw[:100]}")
            return None

    async def close(self) -> None:
        """Close the HTTP client and cancel the SSE listener."""
        if self._sse_task is not None:
            self._sse_task.cancel()
            try:
                await self._sse_task
            except asyncio.CancelledError:
                pass
            self._sse_task = None

        if self._client is not None:
            await self._client.aclose()
            self._client = None

        logger.debug("HttpTransport: closed")
