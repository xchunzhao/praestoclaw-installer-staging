"""MCP types — connection state, capabilities, server info."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Literal


class ConnectionState(Enum):
    """MCP server connection state machine states."""

    IDLE = "idle"
    CONNECTING = "connecting"
    CONNECTED = "connected"
    RECONNECTING = "reconnecting"
    DISCONNECTED = "disconnected"
    SKIPPED = "skipped"  # enabled: auto but no cached token — never attempted
    FAILED = "failed"


@dataclass
class MCPCapabilities:
    """Capabilities reported by an MCP server after initialization."""

    tools: bool = False
    resources: bool = False
    prompts: bool = False
    streaming: bool = False
    logging: bool = False
    list_changed: bool = False

    @classmethod
    def from_server_response(cls, caps: dict) -> MCPCapabilities:
        """Parse capabilities from the initialize response."""
        return cls(
            tools="tools" in caps,
            resources="resources" in caps,
            prompts="prompts" in caps,
            streaming=caps.get("tools", {}).get("streaming", False),
            logging="logging" in caps,
            list_changed=caps.get("tools", {}).get("listChanged", False),
        )


@dataclass
class ServerInfo:
    """Summary info for an MCP server."""

    name: str
    state: ConnectionState
    is_agency: bool
    enabled: bool | Literal["auto"] = True
    description: str | None = None
    tool_count: int = 0
    protocol_version: str | None = None
    capabilities: MCPCapabilities = field(default_factory=MCPCapabilities)
    error: str | None = None
