"""Megaphone — intelligent monitoring and proactive notification for PraestoClaw."""
