"""
Megaphone configuration — Pydantic v2 models for the monitoring & notification subsystem.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Literal

from pydantic import BaseModel, Field

logger = logging.getLogger(__name__)

# ── Quiet Hours ───────────────────────────────────────────────────────────────


class WorkingHours(BaseModel):
    """Working hours window. Monitoring and alerts only run within this window (in display_timezone)."""

    start: str = Field(
        default="09:00", description="Start of working hours (HH:MM, in display_timezone)."
    )
    end: str = Field(
        default="18:00", description="End of working hours (HH:MM, in display_timezone)."
    )


# ── Teams ─────────────────────────────────────────────────────────────────────


class TeamsChatWatch(BaseModel):
    """A single Teams group chat or meeting chat to monitor."""

    name: str = Field(description="Display name of the group chat or meeting chat.")
    keywords: list[str] = Field(default_factory=list, description="Keywords to match in messages.")
    instructions: list[str] = Field(
        default_factory=list,
        description="User-defined monitoring or summary instructions for this chat.",
    )


class TeamsConfig(BaseModel):
    """Teams monitoring configuration."""

    enabled: bool = Field(default=False, description="Enable Teams chat monitoring.")
    schedule: str | None = Field(
        default=None, description="Cron schedule override for Teams polling."
    )
    chats: list[TeamsChatWatch] = Field(
        default_factory=list, description="Group/meeting chats to watch."
    )
    instructions: list[str] = Field(
        default_factory=list,
        description="User-defined monitoring or summary instructions for all Teams chats.",
    )


# ── Email ─────────────────────────────────────────────────────────────────────


class EmailRule(BaseModel):
    """A single email monitoring rule."""

    name: str = Field(description="Human-readable label for this rule.")
    type: Literal["meeting", "search"] = Field(
        description="Rule type: meeting invites or search queries."
    )
    query: str | None = Field(default=None, description="Optional Graph $filter / $search query.")
    from_: list[str] = Field(
        default_factory=list, alias="from", description="Sender addresses to match."
    )
    keywords: list[str] = Field(
        default_factory=list, description="Keywords to match in subject/body."
    )
    instructions: list[str] = Field(
        default_factory=list,
        description="User-defined monitoring or summary instructions for this email rule.",
    )
    direct_only: bool = Field(
        default=False,
        description="If true, only keep emails where the user is in toRecipients (not just CC/BCC).",
    )

    model_config = {"populate_by_name": True}


class EmailConfig(BaseModel):
    """Email monitoring configuration."""

    enabled: bool = Field(default=False, description="Enable email monitoring.")
    schedule: str | None = Field(
        default=None, description="Cron schedule override for email polling."
    )
    rules: list[EmailRule] = Field(default_factory=list, description="Email monitoring rules.")
    instructions: list[str] = Field(
        default_factory=list,
        description="User-defined monitoring or summary instructions for all email rules.",
    )


# ── Calendar ──────────────────────────────────────────────────────────────────


class CalendarConfig(BaseModel):
    """Calendar monitoring configuration — daily meeting summary + next-day preview."""

    enabled: bool = Field(default=False, description="Enable calendar monitoring.")
    schedule_today: str = Field(
        default="0 9 * * *",
        description=(
            "Cron schedule for today's meeting summary. "
            "Default: 09:00 daily. No meetings on a given day = silent run."
        ),
    )
    schedule_tomorrow: str = Field(
        default="0 19 * * *",
        description=(
            "Cron schedule for tomorrow's meeting preview. "
            "Default: 19:00 daily. No meetings on a given day = silent run."
        ),
    )
    instructions: list[str] = Field(
        default_factory=list,
        description="User-defined instructions applied to all calendar scans.",
    )


# ── GitHub ────────────────────────────────────────────────────────────────────


class GitHubRepoWatch(BaseModel):
    """A single GitHub repository to monitor."""

    owner: str = Field(description="Repository owner (user or org).")
    repo: str = Field(description="Repository name.")
    watch: Literal["completed", "opened", "all"] = Field(
        default="all", description="Which events to watch."
    )
    importance: dict[str, list[str]] = Field(
        default_factory=dict,
        description="Importance filter, e.g. {'include': [...], 'exclude': [...]}.",
    )


class GitHubConfig(BaseModel):
    """GitHub monitoring configuration."""

    enabled: bool = Field(default=False, description="Enable GitHub monitoring.")
    schedule: str | None = Field(
        default=None, description="Cron schedule override for GitHub polling."
    )
    repos: list[GitHubRepoWatch] = Field(default_factory=list, description="Repositories to watch.")


# ── Top-level ─────────────────────────────────────────────────────────────


class MegaphoneConfig(BaseModel):
    """Top-level Megaphone configuration."""

    enabled: bool = Field(default=False, description="Master switch for Megaphone.")
    language: str = Field(default="zh-CN", description="Language for generated summaries.")
    display_timezone: str = Field(
        default="Asia/Shanghai",
        description=(
            "IANA timezone used to render all timestamps in notifications "
            "(message received-time, PR closed-time, etc.). All upstream timestamps "
            "are aware datetimes (usually UTC) and converted to this zone at format time."
        ),
    )
    schedule: str = Field(default="0 * * * *", description="Default cron schedule for all sources.")
    auto_enable: bool = Field(
        default=True,
        description=(
            "If true (default), registered megaphone jobs run on schedule immediately. "
            "Set to false to register jobs in a disabled state — useful for debugging "
            "(trigger manually via the agent's cron tool: action='run', job_id='megaphone-teams')."
        ),
    )
    notify_channels: list[str] = Field(
        default_factory=lambda: ["cloud"],
        description="Channels to deliver notifications to.",
    )
    working_hours: WorkingHours = Field(
        default_factory=WorkingHours,
        description="Working hours window (in display_timezone). Monitoring only runs within this window.",
    )
    max_items_per_run: int = Field(default=10, description="Max digest items per scheduled run.")
    lookback_hours: int = Field(
        default=24,
        description="Max lookback window in hours. On first run or when last check was longer ago than this, only look back this many hours.",
    )
    instructions: list[str] = Field(
        default_factory=list,
        description="User-defined monitoring or summary instructions applied to every source.",
    )
    teams: TeamsConfig = Field(default_factory=TeamsConfig, description="Teams monitoring config.")
    email: EmailConfig = Field(default_factory=EmailConfig, description="Email monitoring config.")
    calendar: CalendarConfig = Field(
        default_factory=CalendarConfig, description="Calendar monitoring config."
    )


# ── Helpers ───────────────────────────────────────────────────────────────────


def _megaphone_dir() -> Path:
    """Return the megaphone skill data directory (~/.praestoclaw/skills/megaphone/)."""
    from praestoclaw.utils.helpers import get_data_dir

    return get_data_dir() / "skills" / "megaphone"


def config_path() -> Path:
    """Return the default Megaphone config file path (``praestoclaw/megaphone/megaphone.yaml``)."""
    return _megaphone_dir() / "megaphone.yaml"


def example_config_path() -> Path:
    """Return the path to the bundled example config shipped with PraestoClaw."""
    return Path(__file__).resolve().parent.parent / "defaults" / "megaphone.example.yaml"


def load_config(path: Path | None = None) -> MegaphoneConfig:
    """Load MegaphoneConfig from a YAML file.

    If *path* is ``None`` the default ``config_path()`` is used
    (``praestoclaw/megaphone/megaphone.yaml``).
    Returns a disabled ``MegaphoneConfig()`` when the file does not exist.
    """
    target = path or config_path()

    if not target.exists():
        logger.debug("Megaphone config not found at %s — returning disabled defaults.", target)
        return MegaphoneConfig()

    logger.info("Loading Megaphone config from %s", target)

    try:
        import yaml

        raw = yaml.safe_load(target.read_text(encoding="utf-8")) or {}
        # Support both top-level keys and a nested 'megaphone' key.
        if "megaphone" in raw and isinstance(raw["megaphone"], dict):
            raw = raw["megaphone"]
        return MegaphoneConfig.model_validate(raw)
    except Exception:
        logger.exception(
            "Failed to parse Megaphone config at %s — returning disabled defaults.", target
        )
        return MegaphoneConfig()
