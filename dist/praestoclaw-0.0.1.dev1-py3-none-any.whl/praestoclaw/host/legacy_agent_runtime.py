"""Adapter from the new runtime contract to the existing AgentLoopV2.

This is a cutover aid for the TUI direct path and the local webchat
WebSocket path. It synthesizes a ``(channel, channel_id)`` pair from the
turn provenance so tools that gate on a real user-originated channel
context (e.g. the a2a tool) work correctly. Without this synthesis the
a2a tool falsely reports "background/cron" because both kwargs default
to empty strings.
"""

from __future__ import annotations

from typing import Any

from praestoclaw.agent.loop_v2 import AgentLoopV2
from praestoclaw.config.schema import ChannelType
from praestoclaw.host.runtime_contracts import AgentRuntimeRequest, AgentRuntimeResult

# Map turn-provenance ``logical_channel`` strings (LocalInteractiveSurface
# values + agent-link) onto the legacy ChannelType enum that the agent loop
# and tools expect. Anything we don't recognise falls back to CLI — this is
# strictly better than the previous None/empty which broke the a2a guard.
_LOGICAL_CHANNEL_MAP: dict[str, ChannelType] = {
    "local_tui": ChannelType.CLI,
    "local_webchat": ChannelType.WEB,
    "agent_link": ChannelType.CLOUD,
}


class AgentLoopRuntimeAdapter:
    def __init__(self, agent_loop: AgentLoopV2) -> None:
        self._agent_loop = agent_loop

    async def run_once(self, request: AgentRuntimeRequest) -> AgentRuntimeResult:
        metadata: dict[str, Any] = {}
        channel: ChannelType = ChannelType.CLI
        if request.turn_provenance is not None:
            logical = request.turn_provenance.logical_channel
            metadata["turn_provenance"] = {
                "initiated_by": request.turn_provenance.initiated_by.value,
                "human_initiated": request.turn_provenance.human_initiated,
                "logical_channel": logical,
                "trust_boundary": request.turn_provenance.trust_boundary,
                "supervision_required": request.turn_provenance.supervision_required,
            }
            channel = _LOGICAL_CHANNEL_MAP.get(logical, ChannelType.CLI)

        route_identity = str(request.runtime_policy.get("route_identity") or "").strip()
        # Keep persistence/session identity stable (request.session_id), but
        # route runtime/tool side-effects back to the originating connection.
        # Fallback to session_id for callers that don't provide route_identity.
        channel_id = route_identity or request.session_id

        response = await self._agent_loop.run_once(
            request.user_content,
            request.session_id,
            channel=channel,
            channel_id=channel_id,
            metadata=metadata,
        )
        return AgentRuntimeResult(content=response)
