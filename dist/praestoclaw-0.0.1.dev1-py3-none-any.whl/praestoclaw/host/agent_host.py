"""Agent Host composition skeleton.

The production cutover will replace the legacy ``praestoclaw.runtime`` module.
Until that cutover, this object only describes the new composition boundary and
is not imported by existing CLI or web entry points.
"""

from __future__ import annotations

from dataclasses import dataclass

from praestoclaw.channels.turn.kernel import ChannelTurnKernel


@dataclass(slots=True)
class AgentHost:
    channel_turn_kernel: ChannelTurnKernel

    async def start(self) -> None:
        """Start Agent Host managed services.

        The skeleton has no managed services yet. Future stages will attach the
        local web portal, scheduler_local adapter, and Agent Link client here.
        """

    async def stop(self) -> None:
        """Stop Agent Host managed services."""
