from __future__ import annotations

import asyncio
import contextlib
import json
from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, Protocol
from urllib.parse import urlsplit, urlunsplit
from uuid import uuid4

import httpx

from praestoclaw.channels.local_interactive import (
    LocalInteractiveAdapter,
    LocalInteractiveInbound,
    LocalInteractiveSurface,
)
from praestoclaw.channels.turn.kernel import ChannelTurnKernel, DefaultSessionResolver

if TYPE_CHECKING:
    from praestoclaw.channels.cloud import CloudChannel


@dataclass(frozen=True, slots=True)
class TuiChatResult:
    content: str
    session_key: str


class TuiBackend(Protocol):
    @property
    def connection_label(self) -> str: ...

    async def start(self) -> None: ...

    async def stop(self) -> None: ...

    async def send_chat(self, *, conversation_id: str, content: str) -> TuiChatResult: ...


class HostBackedTuiBackend:
    """Local TUI backend that enters through Agent Host channel dispatch."""

    def __init__(
        self,
        *,
        kernel: ChannelTurnKernel,
        ensure_session: Callable[[str, str, str], Awaitable[None]] | None = None,
        sender_id: str = "local",
        connection_id: str | None = None,
    ) -> None:
        self._kernel = kernel
        self._ensure_session = ensure_session
        self._sender_id = sender_id
        self._connection_id = connection_id or f"local-tui-{uuid4().hex[:12]}"
        self._adapter = LocalInteractiveAdapter(LocalInteractiveSurface.TUI)
        self._session_resolver = DefaultSessionResolver()

    @property
    def connection_label(self) -> str:
        return "local agent host"

    async def start(self) -> None:
        return None

    async def stop(self) -> None:
        return None

    async def send_chat(self, *, conversation_id: str, content: str) -> TuiChatResult:
        envelope = await self._adapter.ingest(
            LocalInteractiveInbound(
                connection_id=self._connection_id,
                conversation_id=conversation_id,
                message_id=uuid4().hex,
                sender_id=self._sender_id,
                content=content,
                surface=LocalInteractiveSurface.TUI.value,
            )
        )
        session_key = self._session_resolver.resolve_session_key(envelope)
        if self._ensure_session is not None:
            await self._ensure_session(session_key, envelope.logical_channel, envelope.sender_id)

        result = await self._kernel.process(envelope)
        if result.runtime_result is not None:
            return TuiChatResult(result.runtime_result.content, session_key)
        if result.admission.synthetic_reply is not None:
            return TuiChatResult(str(result.admission.synthetic_reply), session_key)
        return TuiChatResult("", session_key)


class CloudTuiBackend:
    """Cloud Gateway-backed TUI backend using the c.* channel protocol."""

    def __init__(
        self,
        *,
        url: str,
        token_provider: _CloudTuiTokenProvider,
        protocol: str,
        negotiate_url: str = "",
        negotiate_timeout_s: float = 15.0,
        client_url_refresh_skew_s: float = 300.0,
        client_version: str = "",
        target_agent_id: str | None = None,
    ) -> None:
        self._url = url
        self._token_provider = token_provider
        self._protocol = protocol
        self._negotiate_url = negotiate_url
        self._negotiate_timeout_s = negotiate_timeout_s
        self._client_url_refresh_skew_s = client_url_refresh_skew_s
        self._client_version = client_version
        self._target_agent_id = target_agent_id
        self._token: str | None = None
        self._ws: Any = None
        self._channel_session_id = ""
        self._conversation_id = ""
        self._awps_url = ""
        self._awps_expires_at = 0.0

    @classmethod
    def from_cloud_config(
        cls,
        cloud_cfg: object,
        *,
        client_version: str,
        target_agent_id: str | None = None,
    ) -> CloudTuiBackend:
        transport_mode = str(getattr(cloud_cfg, "transport_mode", "awps") or "awps")
        return cls(
            url=str(getattr(cloud_cfg, "url", "") or ""),
            token_provider=_CloudTuiTokenProvider(cloud_cfg),
            protocol="v2" if transport_mode == "awps" else "v1",
            negotiate_url=str(getattr(cloud_cfg, "negotiate_url", "") or ""),
            negotiate_timeout_s=float(getattr(cloud_cfg, "negotiate_timeout_s", 15.0)),
            client_url_refresh_skew_s=float(getattr(cloud_cfg, "client_url_refresh_skew_s", 300.0)),
            client_version=client_version,
            target_agent_id=target_agent_id,
        )

    @property
    def connection_label(self) -> str:
        return f"Cloud Gateway ({self._protocol})"

    async def start(self) -> None:
        if self._ws is not None:
            return
        self._token = await asyncio.to_thread(self._token_provider.acquire_token_sync)
        connect_url, headers = await self._connect_target()

        import websockets

        self._ws = await websockets.connect(
            connect_url,
            additional_headers=headers,
            open_timeout=15,
            close_timeout=5,
            ping_interval=20,
            ping_timeout=20,
        )
        await self._send(
            {
                "type": "c.hello",
                "protocol_version": 1,
                "min_protocol_version": 1,
                "client": {
                    "name": "praestoclaw-tui",
                    "version": self._client_version,
                },
                "features": ["streaming", "new_conversation", "cancel"],
                **({"target_agent_id": self._target_agent_id} if self._target_agent_id else {}),
            }
        )
        welcome = await self._recv()
        if welcome.get("type") == "c.error":
            raise RuntimeError(str(welcome.get("message") or "cloud TUI handshake failed"))
        if welcome.get("type") != "c.welcome":
            raise RuntimeError("cloud TUI handshake did not receive c.welcome")
        self._channel_session_id = str(welcome.get("channel_session_id") or "")
        self._conversation_id = str(welcome.get("conversation_id") or "")
        if not self._channel_session_id or not self._conversation_id:
            raise RuntimeError("cloud TUI welcome omitted session identifiers")

    async def stop(self) -> None:
        ws = self._ws
        self._ws = None
        if ws is not None:
            close = getattr(ws, "close", None)
            if callable(close):
                with contextlib.suppress(Exception):
                    await close()

    async def current_conversation_id(self) -> str:
        if not self._conversation_id:
            await self.start()
        return self._conversation_id

    async def new_conversation(self) -> str:
        await self.start()
        request_id = f"new-{uuid4().hex}"
        await self._send({"type": "c.new_conversation", "request_id": request_id})
        while True:
            frame = await self._recv()
            frame_type = frame.get("type")
            if frame_type == "c.conversation" and frame.get("request_id") == request_id:
                self._conversation_id = str(frame.get("conversation_id") or "")
                return self._conversation_id
            if frame_type == "c.error":
                raise RuntimeError(str(frame.get("message") or "new conversation failed"))

    async def send_chat(self, *, conversation_id: str, content: str) -> TuiChatResult:
        await self.start()
        turn_id = f"turn-{uuid4().hex}"
        conversation_id = conversation_id or self._conversation_id
        await self._send(
            {
                "type": "c.message",
                "turn_id": turn_id,
                "conversation_id": conversation_id,
                "response_mode": "stream",
                "content": {
                    "content_type": "text",
                    "text": content,
                    "format": "text",
                },
                "timeout_ms": 600_000,
            }
        )
        chunks: list[str] = []
        while True:
            frame = await self._recv()
            frame_type = frame.get("type")
            if frame.get("turn_id") not in {None, turn_id}:
                continue
            if frame_type == "c.accepted":
                continue
            if frame_type == "c.stream_item":
                text = _frame_text_content(frame)
                if text:
                    chunks.append(text)
                continue
            if frame_type == "c.response":
                text = _frame_text_content(frame)
                return TuiChatResult(text or "".join(chunks), conversation_id)
            if frame_type == "c.error":
                code = str(frame.get("code") or "error")
                message = str(frame.get("message") or "Cloud TUI request failed")
                return TuiChatResult(f"[{code}] {message}", conversation_id)
            if frame_type == "c.cancelled":
                return TuiChatResult("[cancelled] turn cancelled", conversation_id)

    async def _connect_target(self) -> tuple[str, dict[str, str]]:
        assert self._token is not None
        if self._protocol == "v2":
            return await self._negotiate_awps_url(), {}
        return _cloud_tui_v1_url(self._url), {"Authorization": f"Bearer {self._token}"}

    async def _negotiate_awps_url(self) -> str:
        import time

        now = time.time()
        if self._awps_url and now < self._awps_expires_at - self._client_url_refresh_skew_s:
            return self._awps_url
        assert self._token is not None
        negotiate_url = self._negotiate_url or _negotiate_url_from_connect_url(self._url)
        async with httpx.AsyncClient(timeout=self._negotiate_timeout_s) as client:
            response = await client.post(
                negotiate_url,
                headers={"Authorization": f"Bearer {self._token}"},
                json={
                    "protocol": "channel.v1",
                    "transport": "awps",
                    "role": "channel",
                    "channel": "cloud_tui",
                },
            )
            response.raise_for_status()
            body = response.json()
        if body.get("protocol") != "channel.v1" or body.get("transport") != "awps":
            raise RuntimeError("Gateway negotiate response did not confirm channel.v1/awps")
        if body.get("role") != "channel" or body.get("channel") != "cloud_tui":
            raise RuntimeError("Gateway negotiate response did not confirm cloud_tui role")
        url = body.get("url")
        if not isinstance(url, str) or not url:
            raise RuntimeError("Gateway negotiate response did not include url")
        self._awps_url = url
        self._awps_expires_at = _parse_epoch_seconds(body.get("expires_at")) or now + 300
        return url

    async def _send(self, frame: dict[str, object]) -> None:
        if self._ws is None:
            raise RuntimeError("cloud TUI is not connected")
        await self._ws.send(json.dumps(frame, ensure_ascii=False, separators=(",", ":")))

    async def _recv(self) -> dict[str, Any]:
        if self._ws is None:
            raise RuntimeError("cloud TUI is not connected")
        payload = json.loads(await self._ws.recv())
        if not isinstance(payload, dict):
            raise RuntimeError("cloud TUI received a non-object frame")
        return payload


class _CloudTuiTokenProvider:
    def __init__(self, cloud_cfg: object) -> None:
        self._cloud_cfg = cloud_cfg

    def acquire_token_sync(self) -> str:
        bypass_token = getattr(self._cloud_cfg, "bypass_token", None)
        if bypass_token:
            return str(bypass_token)

        from praestoclaw.auth.factory import build_auth_provider

        try:
            provider = build_auth_provider(self._cloud_cfg)
        except ValueError as exc:
            if "requires a CloudChannel reference" not in str(exc):
                raise
            provider = build_auth_provider(
                self._cloud_cfg,
                channel=self._build_auth_channel(),
            )

        token = provider.try_silent()
        if token:
            return str(token)
        if not provider.supports_interactive:
            raise RuntimeError(
                f"{provider.name} silent acquisition failed and provider does not "
                "support in-process interactive login. Re-establish the session "
                "manually and retry."
            )
        return provider.interactive_login().token

    def _build_auth_channel(self) -> CloudChannel:
        from praestoclaw.bus.queue import MessageBus
        from praestoclaw.channels.cloud import CloudChannel

        cloud_cfg = self._cloud_cfg
        return CloudChannel(
            MessageBus(),
            url=str(getattr(cloud_cfg, "url", "") or ""),
            tenant_id=str(getattr(cloud_cfg, "tenant_id", "") or ""),
            client_id=str(getattr(cloud_cfg, "client_id", "") or ""),
            scope=str(getattr(cloud_cfg, "scope", "") or ""),
            transport_mode=getattr(cloud_cfg, "transport_mode", "awps"),
            negotiate_url=str(getattr(cloud_cfg, "negotiate_url", "") or ""),
            negotiate_timeout_s=float(getattr(cloud_cfg, "negotiate_timeout_s", 15.0)),
            client_url_refresh_skew_s=float(getattr(cloud_cfg, "client_url_refresh_skew_s", 300.0)),
            login_method=getattr(cloud_cfg, "login_method", "auto"),
            login_port=int(getattr(cloud_cfg, "login_port", 49216)),
            allow_from=getattr(cloud_cfg, "allow_from", None) or None,
            auto_reconnect=False,
            reconnect_max=int(getattr(cloud_cfg, "reconnect_max", 60)),
        )


def _cloud_tui_v1_url(connect_url: str) -> str:
    parts = urlsplit(connect_url)
    scheme = {"http": "ws", "https": "wss"}.get(parts.scheme, parts.scheme)
    return urlunsplit((scheme, parts.netloc, "/channels/v1/tui/connect", "", ""))


def _negotiate_url_from_connect_url(connect_url: str) -> str:
    from praestoclaw.gateway_protocol.v2.awps import negotiate_url_from_connect_url

    return negotiate_url_from_connect_url(connect_url)


def _parse_epoch_seconds(value: object) -> float | None:
    from datetime import datetime

    if not isinstance(value, str) or not value:
        return None
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return None
    return parsed.timestamp()


def _frame_text_content(frame: dict[str, Any]) -> str:
    content = frame.get("content")
    if isinstance(content, dict):
        return str(content.get("text") or "")
    return ""
