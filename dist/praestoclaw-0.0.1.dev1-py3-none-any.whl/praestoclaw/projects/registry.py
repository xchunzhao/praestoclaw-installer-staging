"""Built-in project definitions.

Each :class:`Project` is a recommendation profile: a label, a set of
detection heuristics, and pointers to assets (marketplaces, future
workflows, knowledge bases, etc.) that members typically want.

Projects are deliberately defined in code rather than YAML — short term
we only need a handful, and pinning them to a Python module keeps the
type contracts honest. We can promote to user-editable config later if
external groups ask for it.
"""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(frozen=True)
class ProjectDetector:
    """Heuristics that suggest a user belongs to a project.

    Pattern fields are case-insensitive substrings evaluated against the
    corresponding signal in :class:`DetectionEnv`; org fields are exact
    case-insensitive matches. A project is considered *detected* if **any** of
    its detector entries match — but only "strong" signals (git remotes, ADO
    orgs, GitHub org/repo signals, repo-name patterns) count toward
    auto-subscription. Entra group claims are advisory.

    Empty detectors (the default) means the project is never auto-detected
    and must be subscribed manually. The ``default`` project uses this.
    """

    # Substrings matched against ``DetectionEnv.git_remotes`` (case-insensitive).
    # Examples: ``edge-microsoft/``, ``microsoft/edge``.
    git_remote_patterns: tuple[str, ...] = ()

    # Lowercased ADO organization names (e.g. ``"o365exchange"``). Compared
    # against ``DetectionEnv.ado_orgs_seen`` after lowercasing both sides.
    ado_orgs: tuple[str, ...] = ()

    # Lowercased GitHub organization names (e.g. ``"infinity-microsoft"``).
    # Compared against ``DetectionEnv.github_orgs_seen``. Unlike ADO orgs,
    # these are only populated from local remotes or targeted recent-activity
    # discovery, not from a broad organization membership list.
    github_orgs: tuple[str, ...] = ()

    # Substrings matched against lowercased GitHub repo slugs
    # (``owner/name``) discovered from local remotes or recent activity.
    github_repo_patterns: tuple[str, ...] = ()

    # Substrings matched against the *basename* of recently-used cwds and
    # cloned repo directory names.
    repo_name_patterns: tuple[str, ...] = ()

    # Entra ID group object IDs (advisory only — not enough on its own).
    entra_groups: tuple[str, ...] = ()


@dataclass(frozen=True)
class Project:
    """A built-in project profile.

    ``marketplaces`` references :class:`praestoclaw.skills.marketplace.BuiltinMarketplace`
    ids. Other asset lists are placeholders for future expansion — the
    detector and FRE flow already understand them so we can grow into
    workflows / knowledge bases without a second migration.
    """

    id: str
    label: str
    description: str
    detect: ProjectDetector = field(default_factory=ProjectDetector)

    # Asset references — ids into the respective registries.
    marketplaces: tuple[str, ...] = ()
    workflows: tuple[str, ...] = ()
    knowledge_bases: tuple[str, ...] = ()
    mcp_bundles: tuple[str, ...] = ()

    # Parameters that project-aware skills can pull via ``{{project.<key>}}``
    # at render time. Free-form string map; projects that share a key with
    # different values lose to the project that comes later in
    # ``subscribed`` (last-write-wins, documented).
    skill_defaults: dict[str, str] = field(default_factory=dict)

    # Marker for the implicit baseline project. Kept as a flag rather than
    # a magic id so callers can ``project.is_default`` without string
    # compares.
    is_default: bool = False


# ---------------------------------------------------------------------------
# Built-in projects. Order matters: ``resolve_assets`` preserves it when
# deduplicating asset lists, so earlier projects' picks come first in the UI.
# ---------------------------------------------------------------------------

BUILTIN_PROJECTS: tuple[Project, ...] = (
    Project(
        id="default",
        label="General",
        description="Baseline skills for everyone — Office docs, Git, Copilot helpers.",
        marketplaces=("microsoft-skills", "opc"),
        is_default=True,
    ),
    Project(
        id="edge",
        label="Edge",
        description="Edge / Chromium development, ADO workflows, PR & CR automation.",
        detect=ProjectDetector(
            git_remote_patterns=(
                "edge-microsoft/",
                "microsoft/edge",
                "/edge-agents",
                "/chromium",
            ),
            repo_name_patterns=("edge-agents", "chromium"),
        ),
        marketplaces=("edge-skills", "microsoft-skills", "edge-societas-ml-skills"),
    ),
    Project(
        id="societas",
        label="Societas",
        description="Societas (Office Agent) development, testing, and bug triage.",
        detect=ProjectDetector(
            git_remote_patterns=("/societas",),
            ado_orgs=("o365exchange",),
            repo_name_patterns=("societas",),
        ),
        marketplaces=("societas-skills", "microsoft-skills", "edge-societas-ml-skills"),
        skill_defaults={
            "societas_org": "o365exchange",
            "societas_collection": "O365Exchange",
            "societas_project": "O365 Core",
            "societas_area_root": r"O365 Core\Societas",
        },
    ),
    Project(
        id="sapphire",
        label="Sapphire",
        description="Microsoft Search / Sapphire development on the msasg ADO org.",
        # Detection: exact remote-URL fragment plus repo-name fallback.
        # ``ado_orgs=("msasg",)`` alone would over-trigger because msasg
        # hosts many unrelated projects (Bing, Search, etc.), so we anchor
        # on the Sapphire repo specifically.
        detect=ProjectDetector(
            git_remote_patterns=(
                # Raw remote URLs are lowercased but NOT URL-decoded by the
                # detector, so the pattern must match the encoded form.
                "msasg.visualstudio.com/san%20sa/_git/sapphire",
            ),
            repo_name_patterns=("sapphire",),
        ),
        marketplaces=("microsoft-skills", "opc"),
        skill_defaults={
            "sapphire_ado_org": "msasg",
            "sapphire_ado_project": "SAN SA",
            "sapphire_ado_repo": "Sapphire",
        },
    ),
    Project(
        id="copilot",
        label="Copilot",
        description=(
            "Microsoft 365 Copilot development — Sydney (BizChat) backend, "
            "1JS (Office Add-ins JavaScript runtime), and Infinity GitHub repos."
        ),
        # Detection: exact ADO remote URLs for Sydney / 1JS plus Infinity's
        # GitHub org. We deliberately skip ``ado_orgs=("office",)`` — that
        # org is huge and would mis-attribute every Office team to Copilot.
        # We also skip ``sydney`` as a repo-name pattern because it's a
        # common word.
        detect=ProjectDetector(
            git_remote_patterns=(
                "office.visualstudio.com/_git/sydney",
                "office.visualstudio.com/office/_git/1js",
            ),
            github_orgs=("infinity-microsoft",),
            repo_name_patterns=("1js",),
        ),
        marketplaces=("microsoft-skills", "opc"),
        skill_defaults={
            "copilot_ado_org": "office",
            # Sydney lives in the collection-default project (no name);
            # 1JS lives in the ``Office`` project. Skills that need a
            # specific project should branch on the active repo.
            "copilot_sydney_project": "",
            "copilot_sydney_repo": "Sydney",
            "copilot_1js_project": "Office",
            "copilot_1js_repo": "1JS",
            "infinity_github_org": "infinity-microsoft",
        },
    ),
)


_PROJECT_BY_ID: dict[str, Project] = {p.id: p for p in BUILTIN_PROJECTS}


def get_project(project_id: str) -> Project | None:
    """Return the :class:`Project` with ``project_id`` or ``None`` if unknown."""
    return _PROJECT_BY_ID.get(project_id)


def default_project() -> Project:
    """Return the project flagged ``is_default``. Falls back to ``BUILTIN_PROJECTS[0]``."""
    for p in BUILTIN_PROJECTS:
        if p.is_default:
            return p
    return BUILTIN_PROJECTS[0]


__all__ = [
    "BUILTIN_PROJECTS",
    "Project",
    "ProjectDetector",
    "default_project",
    "get_project",
]
