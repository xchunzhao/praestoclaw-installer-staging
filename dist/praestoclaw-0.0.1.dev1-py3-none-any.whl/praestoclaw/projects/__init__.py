"""Project registry — lightweight user-affinity grouping.

A *project* in PraestoClaw is **not** a tenant or permission boundary; it is
a recommendation profile. Subscribing to a project affects:

* which skill marketplaces are pre-installed during ``pc init``
* which assets the Web Portal highlights / sorts first
* (future) default parameters injected into project-aware skills

A user may subscribe to multiple projects simultaneously. The skill loader,
runtime, and Cloud Gateway are deliberately project-agnostic — project
membership never restricts what a user can do, it only shapes defaults.

(This module was previously called ``teams``; renamed to ``projects`` so it
doesn't clash with the unrelated Microsoft Teams chat-app integration.)
"""

from __future__ import annotations

from praestoclaw.projects.detector import (
    DetectionEnv,
    collect_env,
    detect_projects,
    get_detection_env,
)
from praestoclaw.projects.registry import (
    BUILTIN_PROJECTS,
    Project,
    ProjectDetector,
    get_project,
)
from praestoclaw.projects.resolver import (
    RecommendedAssets,
    resolve_assets,
)

__all__ = [
    "BUILTIN_PROJECTS",
    "DetectionEnv",
    "Project",
    "ProjectDetector",
    "RecommendedAssets",
    "collect_env",
    "detect_projects",
    "get_detection_env",
    "get_project",
    "resolve_assets",
]
