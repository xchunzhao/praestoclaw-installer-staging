"""
Async message bus — decouples channels from the agent loop via queues.
Inspired by HKUDS/nanobot's MessageBus pattern with IronClaw typed events.
"""

from __future__ import annotations

import asyncio
from collections import defaultdict
from collections.abc import Awaitable, Callable
from typing import Any

from loguru import logger

from praestoclaw.bus.events import EventType, InboundMessage, OutboundMessage, StreamingChunk

InboundHandler = Callable[[InboundMessage], Awaitable[None]]
OutboundHandler = Callable[[OutboundMessage | StreamingChunk], Awaitable[None]]
EventHandler = Callable[[EventType, dict[str, Any]], Awaitable[None]]


# ── Event Bus ────────────────────────────────────────────────────────────────


class EventBus:
    """Typed async pub/sub for cross-subsystem coordination.

    Handlers run as separate asyncio tasks (fire-and-forget).
    One slow/failing handler does not block others.
    """

    def __init__(self) -> None:
        self._handlers: dict[EventType, list[EventHandler]] = defaultdict(list)

    def on(self, event_type: EventType, handler: EventHandler) -> None:
        """Subscribe to an event type."""
        self._handlers[event_type].append(handler)

    def off(self, event_type: EventType, handler: EventHandler) -> None:
        """Unsubscribe from an event type."""
        handlers = self._handlers.get(event_type, [])
        if handler in handlers:
            handlers.remove(handler)

    def emit(self, event_type: EventType, payload: dict[str, Any] | None = None) -> None:
        """Publish an event (fire-and-forget). Handlers run as background tasks."""
        data = payload or {}
        # High-frequency events (typing indicators) logged at TRACE to reduce noise
        _noisy = {"typing.started", "typing.stopped"}
        if event_type.value in _noisy:
            logger.trace(
                "Event: {} {}", event_type.value, {k: str(v)[:80] for k, v in data.items()}
            )
        else:
            logger.debug(
                "Event: {} {}", event_type.value, {k: str(v)[:80] for k, v in data.items()}
            )
        for handler in self._handlers.get(event_type, []):
            try:
                loop = asyncio.get_running_loop()
                loop.create_task(self._safe_call(handler, event_type, data))
            except RuntimeError:
                # No running event loop (sync context) — log and skip
                logger.debug(
                    "EventBus.emit: no event loop, skipping handler for {}", event_type.value
                )

    async def _safe_call(
        self, handler: EventHandler, event_type: EventType, payload: dict[str, Any]
    ) -> None:
        """Call handler in isolation — exceptions logged, never propagated."""
        try:
            await handler(event_type, payload)
        except Exception:
            logger.exception("Event handler failed for {}", event_type.value)


# ── Message Bus ──────────────────────────────────────────────────────────────


class MessageBus:
    """Async message bus connecting channels ↔ agent with typed event pub/sub."""

    def __init__(self, max_queue_size: int = 200) -> None:
        self._inbound: asyncio.Queue[InboundMessage] = asyncio.Queue(maxsize=max_queue_size)
        self._outbound: asyncio.Queue[OutboundMessage | StreamingChunk] = asyncio.Queue(
            maxsize=max_queue_size
        )
        self._outbound_handlers: list[OutboundHandler] = []
        self.events: EventBus = EventBus()

    async def publish_inbound(self, msg: InboundMessage) -> None:
        """Channels call this to send a message to the agent."""
        await self._inbound.put(msg)

    async def get_inbound(self) -> InboundMessage:
        """Agent loop calls this to consume the next inbound message."""
        return await self._inbound.get()

    # Design-spec alias
    consume_inbound = get_inbound

    def on_outbound(self, handler: OutboundHandler) -> None:
        """Register a handler for outbound messages (channel dispatching)."""
        self._outbound_handlers.append(handler)

    async def publish_outbound(self, msg: OutboundMessage | StreamingChunk) -> None:
        """Agent loop calls this to send a response to channels.

        Messages go through the bounded outbound queue first, then are
        dispatched to handlers. Direct handler dispatch is also supported
        for backward compatibility.
        """
        # Dispatch to handlers directly (backward-compatible)
        for handler in self._outbound_handlers:
            try:
                await handler(msg)
            except Exception:
                logger.exception(
                    "Outbound handler {}.{} failed for channel={} channel_id={}",
                    getattr(handler, "__module__", "?"),
                    getattr(handler, "__qualname__", repr(handler)),
                    getattr(msg, "channel", "?"),
                    getattr(msg, "channel_id", "?"),
                )
        # Also enqueue for consumers (if any)
        try:
            self._outbound.put_nowait(msg)
        except asyncio.QueueFull:
            logger.warning("Outbound queue full — applying backpressure")
            await self._outbound.put(msg)

    async def dispatch_outbound(self, msg: OutboundMessage | StreamingChunk) -> None:
        """Dispatch to outbound handlers only — no queue enqueue.

        Use this for high-frequency messages like StreamingChunks that should
        not consume bounded queue capacity (no consumer drains chunks from the
        queue, so enqueuing would cause backpressure and block).
        """
        for handler in self._outbound_handlers:
            try:
                await handler(msg)
            except Exception:
                logger.exception(
                    "Outbound dispatch {}.{} failed for channel={} channel_id={}",
                    getattr(handler, "__module__", "?"),
                    getattr(handler, "__qualname__", repr(handler)),
                    getattr(msg, "channel", "?"),
                    getattr(msg, "channel_id", "?"),
                )

    async def get_outbound(self) -> OutboundMessage | StreamingChunk:
        """Consume next outbound message from the bounded queue."""
        return await self._outbound.get()

    # Design-spec alias
    consume_outbound = get_outbound

    @property
    def inbound_qsize(self) -> int:
        return self._inbound.qsize()

    @property
    def outbound_qsize(self) -> int:
        return self._outbound.qsize()
