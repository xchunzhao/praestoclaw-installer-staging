"""
ID token utilities — decode JWT payload and extract user claims.

Promoted from a private helper in ``channels/cloud.py`` so init flow,
web portal, and Teams channel can all share the same identity-extraction
logic. The JWT signature is *not* verified — callers must only pass
tokens that come from a trusted source (e.g. MSAL cache, fresh acquire).
"""

from __future__ import annotations

import base64
import binascii
import json
from typing import Any

from loguru import logger


def decode_jwt_payload(token: str) -> dict[str, Any]:
    """Decode a JWT's payload (claims) without verifying the signature.

    Used when MSAL returns a cached token without ``id_token_claims``,
    or when reading a token previously persisted by another component.
    Returns an empty dict on any parse error.

    Parameters
    ----------
    token:
        The raw JWT string (header.payload.signature).

    Returns
    -------
    dict
        Decoded claims, or ``{}`` if the token is malformed.
    """
    if not token or not isinstance(token, str):
        return {}
    try:
        parts = token.split(".")
        if len(parts) < 2:
            return {}
        payload = parts[1]
        # JWT uses URL-safe base64 without padding — re-pad to multiple of 4.
        payload += "=" * (-len(payload) % 4)
        decoded = base64.urlsafe_b64decode(payload.encode("ascii"))
        result = json.loads(decoded)
        return result if isinstance(result, dict) else {}
    except (ValueError, binascii.Error, json.JSONDecodeError, UnicodeDecodeError) as exc:
        logger.debug("decode_jwt_payload failed: {}", exc)
        return {}


def extract_user_claims(claims: dict[str, Any]) -> dict[str, str]:
    """Project Entra ID token claims into a stable canonical shape.

    PraestoClaw stores user identity in several places (USER.md, the
    FRE state file, audit logs). This helper centralises the extraction
    so all consumers agree on field names.

    Parameters
    ----------
    claims:
        Raw claims dict (e.g. from ``decode_jwt_payload`` or MSAL's
        ``id_token_claims``).

    Returns
    -------
    dict
        Always contains the keys ``oid``, ``upn``, ``display_name``,
        ``first_name``, ``tenant_id``, ``tenant_domain``. Values are
        empty strings when the corresponding claim is missing.
    """
    if not isinstance(claims, dict):
        return _empty_user_claims()

    upn = str(claims.get("preferred_username") or claims.get("upn") or "").strip()
    display_name = str(claims.get("name") or "").strip()
    oid = str(claims.get("oid") or "").strip()
    tid = str(claims.get("tid") or "").strip()

    # Tenant domain: prefer explicit claim, else derive from UPN suffix.
    tenant_domain = str(claims.get("tenant_domain") or "").strip()
    if not tenant_domain and "@" in upn:
        tenant_domain = upn.rsplit("@", 1)[1].lower()

    # First name: prefer the "given_name" claim, else first whitespace
    # token of display_name, else local-part of UPN. We do this so the
    # Teams welcome card can greet the user naturally in Chinese.
    first_name = str(claims.get("given_name") or "").strip()
    if not first_name and display_name:
        first_name = display_name.split()[0]
    if not first_name and "@" in upn:
        first_name = upn.split("@", 1)[0]

    return {
        "oid": oid,
        "upn": upn,
        "display_name": display_name,
        "first_name": first_name,
        "tenant_id": tid,
        "tenant_domain": tenant_domain,
    }


def _empty_user_claims() -> dict[str, str]:
    return {
        "oid": "",
        "upn": "",
        "display_name": "",
        "first_name": "",
        "tenant_id": "",
        "tenant_domain": "",
    }


__all__ = ["decode_jwt_payload", "extract_user_claims"]
