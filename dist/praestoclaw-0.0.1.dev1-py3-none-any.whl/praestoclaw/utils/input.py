"""Unified terminal input — cross-platform key reading for interactive UIs.

Replaces duplicate implementations in init.py, mcp_setup.py, and auth.py.
Supports Windows (msvcrt) and Unix/macOS (termios).
"""

from __future__ import annotations

import sys
from typing import Any, cast

# ── Termios safety net ──────────────────────────────────────────────────────
# If the process exits while termios is in raw/cbreak mode (e.g. Ctrl+C
# during _unix_read), the terminal would be left with OPOST/ICANON disabled
# — every subsequent shell command would render with broken \n handling.
# Snapshot the original termios on first key read and unconditionally
# restore it via atexit + signal handlers.
_termios_snapshot: tuple[int, Any] | None = None


def _restore_termios() -> None:
    """Restore the saved termios state (no-op if no snapshot)."""
    global _termios_snapshot
    if _termios_snapshot is None:
        return
    fd, old = _termios_snapshot
    try:
        import termios

        cast(Any, termios).tcsetattr(fd, cast(Any, termios).TCSADRAIN, old)
    except Exception:
        pass
    _termios_snapshot = None


def _install_termios_safety_net() -> None:
    """Install atexit + signal handlers that always restore termios."""
    import atexit
    import signal

    atexit.register(_restore_termios)

    # Capture any previously-installed handlers so we can delegate to them
    # after restoring termios. For SIGINT we explicitly fall back to
    # ``signal.default_int_handler`` (raises KeyboardInterrupt) rather than
    # SIG_DFL (which hard-terminates the process and would contradict
    # ``read_key_blocking``'s docstring).
    previous: dict[int, Any] = {}

    def _make_handler(sig: int) -> Any:
        def _handler(signum: int, frame: Any) -> None:
            _restore_termios()
            prev = previous.get(signum)
            if callable(prev):
                prev(signum, frame)
                return
            if prev == signal.SIG_IGN:
                # Caller explicitly wanted this signal ignored — honour that
                # instead of escalating to a terminating default disposition.
                return
            if signum == signal.SIGINT:
                signal.default_int_handler(signum, frame)
                return
            # SIG_DFL or unknown — fall back to default disposition.
            signal.signal(signum, signal.SIG_DFL)
            try:
                signal.raise_signal(signum)  # type: ignore[attr-defined]
            except AttributeError:
                import os

                os.kill(os.getpid(), signum)

        return _handler

    for sig in (signal.SIGINT, signal.SIGTERM, signal.SIGHUP):
        try:
            previous[sig] = signal.getsignal(sig)
            signal.signal(sig, _make_handler(sig))
        except (ValueError, OSError):
            # Signal not settable in this context (e.g. non-main thread)
            pass


_safety_net_installed = False


def is_tty() -> bool:
    """Return True if both stdin and stdout are real terminals."""
    try:
        return sys.stdin.isatty() and sys.stdout.isatty()
    except Exception:
        return False


def stdin_is_tty() -> bool:
    """Return True if stdin is a real terminal (can read keys)."""
    try:
        return sys.stdin.isatty()
    except Exception:
        return False


def flush_stdin() -> None:
    """Discard any buffered keystrokes on stdin.

    Call this before showing a new interactive menu so stray Enters typed
    while the previous step was running (e.g. while waiting for ``az login``
    to finish) don't auto-confirm the new menu.
    """
    if not stdin_is_tty():
        return
    if sys.platform == "win32":
        try:
            import msvcrt  # type: ignore[import-not-found]

            while msvcrt.kbhit():  # type: ignore[attr-defined]
                msvcrt.getwch()  # type: ignore[attr-defined]
        except Exception:
            pass
        return
    try:
        import termios

        cast(Any, termios).tcflush(sys.stdin.fileno(), cast(Any, termios).TCIFLUSH)
    except Exception:
        pass


# ── Key names returned by read_key_* ────────────────────────────────────────
# "up", "down", "left", "right", "enter", "esc", "space", "tab",
# or the literal character (e.g. "a", "q", "1").


def read_key_blocking() -> str:
    """Read a single keypress (blocks until a key is pressed).

    Returns a named key string: ``"up"``, ``"down"``, ``"enter"``,
    ``"esc"``, ``"space"``, or the literal character.
    Raises ``KeyboardInterrupt`` on Ctrl+C.
    Raises ``EOFError`` if stdin is not a TTY.
    """
    if not stdin_is_tty():
        raise EOFError("stdin is not a TTY")
    if sys.platform == "win32":
        return _win32_read(blocking=True)  # type: ignore[return-value]
    return _unix_read(blocking=True)  # type: ignore[return-value]


def read_key_nonblocking() -> str | None:
    """Check for a keypress without blocking.

    Returns ``None`` if no input is ready or stdin is not a TTY;
    otherwise same as ``read_key_blocking()``.
    """
    if not stdin_is_tty():
        return None
    if sys.platform == "win32":
        return _win32_read(blocking=False)
    return _unix_read(blocking=False)


# ── Platform implementations ────────────────────────────────────────────────


def _win32_read(*, blocking: bool) -> str | None:  # type: ignore[return-value]
    """Windows key reading via msvcrt."""
    import msvcrt  # type: ignore[import-not-found]  # Windows-only

    if not blocking and not msvcrt.kbhit():  # type: ignore[attr-defined]
        return None

    ch: str = msvcrt.getwch()  # type: ignore[attr-defined]
    if ch == "\x03":
        raise KeyboardInterrupt
    if ch in ("\x00", "\xe0"):
        # Arrow / function key prefix
        ch2: str = msvcrt.getwch()  # type: ignore[attr-defined]
        return {"H": "up", "P": "down", "K": "left", "M": "right"}.get(ch2, "")
    if ch == "\r":
        return "enter"
    if ch == "\x1b":
        return "esc"
    if ch == " ":
        return "space"
    if ch == "\t":
        return "tab"
    return ch


def _unix_read(*, blocking: bool) -> str | None:
    """Unix/macOS key reading via termios."""
    import os
    import termios
    import tty

    global _termios_snapshot, _safety_net_installed

    termios_mod = cast(Any, termios)
    tty_mod = cast(Any, tty)
    fd = sys.stdin.fileno()
    old = termios_mod.tcgetattr(fd)

    # Take a snapshot so the atexit/signal handler can restore it even if
    # this function is interrupted before its `finally` runs.
    _termios_snapshot = (fd, old)
    if not _safety_net_installed:
        _install_termios_safety_net()
        _safety_net_installed = True

    try:
        # Use cbreak (not raw) so OPOST stays enabled — otherwise \n is sent
        # without an automatic carriage return and subsequent renders end up
        # at the wrong column, garbling the menu UI.
        tty_mod.setcbreak(fd)

        if not blocking:
            import select

            if not select.select([sys.stdin], [], [], 0)[0]:
                return None

        ch = os.read(fd, 1).decode("utf-8", errors="replace")
        if ch == "\x03":
            raise KeyboardInterrupt
        if ch in ("\r", "\n"):
            return "enter"
        if ch == " ":
            return "space"
        if ch == "\t":
            return "tab"
        if ch == "\x1b":
            # ESC: could be bare ESC or start of an arrow sequence. We
            # accept both CSI (``\x1b [ A``) and SS3 (``\x1b O A``)
            # encodings because some terminals — notably VS Code's
            # integrated terminal under zsh — enable the DECCKM
            # "application cursor key" mode where Up/Down arrive as
            # ``\x1b O A`` / ``\x1b O B``. Without the SS3 branch the
            # menu silently swallows arrow keys.
            import select

            if select.select([fd], [], [], 0.05)[0]:
                ch2 = os.read(fd, 1).decode("utf-8", errors="replace")
                if ch2 in ("[", "O") and select.select([fd], [], [], 0.05)[0]:
                    ch3 = os.read(fd, 1).decode("utf-8", errors="replace")
                    return {
                        "A": "up",
                        "B": "down",
                        "C": "right",
                        "D": "left",
                    }.get(ch3, "")
                return ""
            return "esc"
        return ch
    finally:
        termios_mod.tcsetattr(fd, termios_mod.TCSADRAIN, old)
        _termios_snapshot = None
