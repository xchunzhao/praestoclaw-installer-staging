"""
First Run Experience (FRE) shared state — ``~/.praestoclaw/.fre-state.json``.

This file is the hand-off layer between the three FRE entry points:

* **A** (CLI ``init``) — writes ``user`` (from id_token), records ``pending``
  background tasks (Teams sideload, MCP silent acquire, marketplace install,
  external import), marks ``completed.init`` when the wizard finishes.
* **B** (Web Portal) — read-only consumer for the status bar; calls a
  ``POST /api/fre/retry/<key>`` endpoint that flips a ``pending`` entry
  back from ``failed`` to ``pending`` and re-fires the work.
* **C** (Teams Bot) — reads ``user.first_name`` for the welcome greeting,
  reads/writes ``teams_seeds_shown`` to suppress duplicate cards, honours
  ``teams_fre_disabled`` when the user opts out.

Concurrency: the file is read/written atomically (tempfile + ``os.replace``)
because three different processes (init, gateway/web, runtime) may touch it.
A corrupt file is logged once and treated as empty so a partial write
never blocks the user.

Schema is versioned (``schema_version`` — currently ``2``). When we evolve
the schema, ``load_fre_state`` up-converts older files in place; consumers
always see the current version.

Schema history:

* **v1** — initial: ``user``, ``pending``, ``completed``, ``teams_seeds_shown``,
  ``teams_fre_disabled``.
* **v2** — added ``projects`` block (``detected``, ``subscribed``,
  ``detection_signals``, ``last_detected_at``) for the project-detection
  feature. Up-converts in place by adding an empty projects block.
  (The ``teams_seeds_shown`` / ``teams_fre_disabled`` fields are unrelated
  and refer to the Microsoft Teams chat-app integration.)
"""

from __future__ import annotations

import json
import os
import tempfile
import threading
import time
from pathlib import Path
from typing import Any, Literal

from loguru import logger

from praestoclaw.utils.helpers import get_data_dir

SCHEMA_VERSION = 2
_FRE_STATE_FILENAME = ".fre-state.json"

# Process-wide lock for ``save_fre_state``. The init wizard fans out
# several background threads (marketplace install, MCP silent-acquire,
# Teams sideload, identity capture) and **all** of them write back
# pending-status updates to the same JSON file. On Windows two
# concurrent ``os.replace`` calls against the same destination race and
# one side raises ``WinError 5: Access is denied``; on POSIX the same
# pattern is technically safe but still produces ``last-write-wins``
# data loss as each thread reads-modifies-writes a stale snapshot. The
# lock guarantees a single read-modify-write critical section across
# threads in this process.
_WRITE_LOCK = threading.RLock()

PendingStatus = Literal["pending", "running", "done", "failed"]

# Known pending-task keys. Not enforced (extras are preserved) — listed
# here so callers have a single place to discover them.
PENDING_TEAMS_SIDELOAD = "teams_sideload"
PENDING_MCP_SILENT = "mcp_silent_acquire"
PENDING_MARKETPLACE = "marketplace_install"
PENDING_EXTERNAL_IMPORT = "external_import"

KNOWN_PENDING_KEYS = (
    PENDING_TEAMS_SIDELOAD,
    PENDING_MCP_SILENT,
    PENDING_MARKETPLACE,
    PENDING_EXTERNAL_IMPORT,
)


def _state_path() -> Path:
    return get_data_dir() / _FRE_STATE_FILENAME


def _empty_projects_block() -> dict[str, Any]:
    """Default shape for the ``projects`` sub-document (schema v2).

    * ``detected`` — project ids the auto-detector matched on the most
      recent run; refreshed every time the user runs ``pc init``.
    * ``subscribed`` — project ids the user actually opted into; this is
      what every consumer (FRE, Portal, resolver) reads.
    * ``detection_signals`` — ``{project_id: [reason_strings]}`` so the
      UI can answer "why did you suggest Edge?".
    * ``last_detected_at`` — ISO timestamp; absent until the first run.
    """
    return {
        "detected": [],
        "subscribed": [],
        "detection_signals": {},
        "last_detected_at": "",
    }


def _empty_state() -> dict[str, Any]:
    return {
        "schema_version": SCHEMA_VERSION,
        "user": {},
        "pending": {},
        "completed": {},
        "teams_seeds_shown": [],
        "teams_fre_disabled": False,
        "projects": _empty_projects_block(),
    }


def load_fre_state() -> dict[str, Any]:
    """Read the FRE state file, returning ``_empty_state()`` on any error.

    Missing file, empty file, malformed JSON, or unexpected top-level
    type all produce an empty (but well-formed) state. Schema is
    upgraded transparently for older versions.
    """
    path = _state_path()
    try:
        if not path.exists():
            return _empty_state()
        raw = path.read_text(encoding="utf-8")
        if not raw.strip():
            return _empty_state()
        data = json.loads(raw)
    except (OSError, json.JSONDecodeError) as exc:
        logger.warning("FRE state file unreadable ({}): {} — treating as empty", path, exc)
        return _empty_state()

    if not isinstance(data, dict):
        logger.warning("FRE state at {} is not a dict — treating as empty", path)
        return _empty_state()

    # Fill in any missing top-level keys so callers can index freely.
    base = _empty_state()
    base.update({k: v for k, v in data.items() if v is not None})
    # Force the well-known sub-shapes to their expected types.
    if not isinstance(base.get("user"), dict):
        base["user"] = {}
    if not isinstance(base.get("pending"), dict):
        base["pending"] = {}
    if not isinstance(base.get("completed"), dict):
        base["completed"] = {}
    if not isinstance(base.get("teams_seeds_shown"), list):
        base["teams_seeds_shown"] = []
    if not isinstance(base.get("teams_fre_disabled"), bool):
        base["teams_fre_disabled"] = bool(base.get("teams_fre_disabled"))

    # ── v1 → v2: ensure the ``projects`` block exists and is well-shaped. ──
    # ``base`` already has an empty ``projects`` from _empty_state(); if
    # the on-disk file was v1 it won't have one, so the empty default
    # carries through. Strip any stray ``teams`` key from pre-release
    # local builds — that intermediate shape never shipped.
    base.pop("teams", None)
    projects = base.get("projects")
    if not isinstance(projects, dict):
        projects = _empty_projects_block()

    # Type-fill any missing keys against the canonical shape.
    defaults = _empty_projects_block()
    for key, default in defaults.items():
        cur = projects.get(key)
        if not isinstance(cur, type(default)):
            projects[key] = default
    base["projects"] = projects

    base["schema_version"] = SCHEMA_VERSION
    return base


def save_fre_state(state: dict[str, Any]) -> None:
    """Atomically persist ``state`` to ``~/.praestoclaw/.fre-state.json``.

    Writes via a tempfile in the same directory then ``os.replace`` so a
    crash mid-write never leaves a half-written JSON document. Errors
    are logged and swallowed — FRE state is best-effort.

    Concurrency:

    * A process-wide :data:`_WRITE_LOCK` serializes writes from background
      threads (marketplace install, MCP silent-acquire, Teams sideload).
    * On Windows ``os.replace`` can transiently fail with
      ``WinError 5 (ACCESS_DENIED)`` when antivirus / Defender opens
      the just-created tempfile for real-time scanning. We retry a few
      times with short backoff before giving up.
    """
    state = dict(state) if isinstance(state, dict) else _empty_state()
    state["schema_version"] = SCHEMA_VERSION
    path = _state_path()
    with _WRITE_LOCK:
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            # Same-directory tempfile guarantees ``os.replace`` is atomic on
            # all supported platforms (Windows + POSIX).
            fd, tmp_path = tempfile.mkstemp(
                prefix=".fre-state.", suffix=".tmp", dir=str(path.parent)
            )
            try:
                with os.fdopen(fd, "w", encoding="utf-8") as fp:
                    json.dump(state, fp, ensure_ascii=False, indent=2, sort_keys=True)
                _replace_with_retry(tmp_path, str(path))
            except OSError:
                # Best-effort cleanup of the temp file if replace failed.
                try:
                    os.unlink(tmp_path)
                except OSError:
                    pass
                raise
        except OSError as exc:
            logger.warning("Failed to persist FRE state to {}: {}", path, exc)


# Up to ~1.5 s total (50ms, 100, 200, 400, 800). Defender scans of a
# fresh tempfile typically finish in <500ms; six attempts gives us
# plenty of headroom while still bounding the worst case.
_REPLACE_RETRY_DELAYS = (0.05, 0.10, 0.20, 0.40, 0.80)


def _replace_with_retry(src: str, dst: str) -> None:
    """``os.replace`` with retry on Windows ACCESS_DENIED.

    Antivirus / indexers can briefly hold an open handle on either the
    just-written tempfile or the destination, causing ``os.replace`` to
    raise ``PermissionError`` (errno 13 / WinError 5). The retry is
    safe: ``os.replace`` is idempotent and the source is still ours.
    """
    last_exc: OSError | None = None
    for delay in (0.0, *_REPLACE_RETRY_DELAYS):
        if delay:
            time.sleep(delay)
        try:
            os.replace(src, dst)
            return
        except PermissionError as exc:
            # WinError 5 manifests as PermissionError on Python 3.
            last_exc = exc
            continue
        except OSError:
            # Anything else (e.g. cross-device, name too long) won't be
            # fixed by retrying — surface immediately.
            raise
    if last_exc is not None:
        raise last_exc


# ---------------------------------------------------------------------------
# Convenience helpers — all read-modify-write under the same atomic save.
# ---------------------------------------------------------------------------


def update_user_from_idtoken(claims: dict[str, Any]) -> dict[str, str]:
    """Extract user claims and persist them into the FRE state.

    Returns the canonical user dict that was written (also see
    :func:`praestoclaw.utils.idtoken.extract_user_claims`).

    Role-related keys (``role``, ``role_source``, ``job_title``,
    ``department``) are *preserved* across calls: identity capture
    happens on every login but role detection is a separate, slower
    Graph call — we don't want a re-login to wipe a previously
    detected role.
    """
    from praestoclaw.utils.idtoken import extract_user_claims

    user = extract_user_claims(claims)
    with _WRITE_LOCK:
        state = load_fre_state()
        existing_raw = state.get("user")
        existing: dict[str, Any] = existing_raw if isinstance(existing_raw, dict) else {}
        for key in ("role", "role_source", "job_title", "department"):
            if existing.get(key):
                user[key] = existing[key]
        state["user"] = user
        save_fre_state(state)
    return user


def get_user_role() -> str:
    """Return the user's inferred role, or ``"unknown"`` when not set.

    See :mod:`praestoclaw.utils.role_detector` for the taxonomy and
    inference rules. Marketplace consumers should treat unrecognised
    values as ``"unknown"``.
    """
    user = load_fre_state().get("user") or {}
    if not isinstance(user, dict):
        return "unknown"
    role = str(user.get("role") or "").strip().lower()
    return role or "unknown"


def set_user_role(
    role: str,
    *,
    source: str | None = None,
    job_title: str | None = None,
    department: str | None = None,
) -> None:
    """Persist a detected role plus the signals it was derived from.

    Parameters
    ----------
    role:
        One of :data:`praestoclaw.utils.role_detector.KNOWN_ROLES`. We
        don't validate against the tuple here so future role taxonomies
        can roll out without a coordinated release of fre_state.
    source:
        Free-form provenance (e.g. ``"graph"``, ``"manual"``,
        ``"prompt"``). Persisted under ``user.role_source`` so the UI
        can show how we got the value.
    job_title:
        Raw ``jobTitle`` from Graph — stored so users can audit what
        we matched on ("why did you guess *pm*?").
    department:
        Raw ``department`` — same rationale.
    """
    role = (role or "").strip().lower()
    if not role:
        return
    with _WRITE_LOCK:
        state = load_fre_state()
        user = state.get("user") if isinstance(state.get("user"), dict) else {}
        if not isinstance(user, dict):
            user = {}
        user["role"] = role
        if source is not None:
            user["role_source"] = source
        if job_title is not None:
            user["job_title"] = job_title
        if department is not None:
            user["department"] = department
        state["user"] = user
        save_fre_state(state)


def update_pending(
    key: str,
    *,
    status: PendingStatus,
    error: str | None = None,
    extra: dict[str, Any] | None = None,
) -> None:
    """Set or update one entry in ``pending``.

    Timestamps (``started_at``/``finished_at``) are filled in
    automatically based on the status transition.
    """
    with _WRITE_LOCK:
        state = load_fre_state()
        pending = state.setdefault("pending", {})
        entry = pending.get(key) or {}
        entry["status"] = status
        if status == "running" and not entry.get("started_at"):
            entry["started_at"] = _now_iso()
        if status in ("done", "failed"):
            entry["finished_at"] = _now_iso()
            entry.setdefault("started_at", entry["finished_at"])
        if error is not None:
            entry["error"] = error
        elif status == "done":
            entry.pop("error", None)
        if extra:
            entry.update(extra)
        pending[key] = entry
        save_fre_state(state)


def mark_completed(key: str, value: Any = True) -> None:
    """Flag ``completed[key] = value`` and stamp ``<key>_finished_at``."""
    with _WRITE_LOCK:
        state = load_fre_state()
        completed = state.setdefault("completed", {})
        completed[key] = value
        completed[f"{key}_finished_at"] = _now_iso()
        save_fre_state(state)


def is_seed_shown(seed_id: str) -> bool:
    state = load_fre_state()
    return seed_id in state.get("teams_seeds_shown", [])


def mark_seed_shown(seed_id: str) -> None:
    with _WRITE_LOCK:
        state = load_fre_state()
        shown = state.setdefault("teams_seeds_shown", [])
        if seed_id not in shown:
            shown.append(seed_id)
            save_fre_state(state)


def is_teams_fre_disabled() -> bool:
    return bool(load_fre_state().get("teams_fre_disabled"))


def disable_teams_fre() -> None:
    with _WRITE_LOCK:
        state = load_fre_state()
        state["teams_fre_disabled"] = True
        save_fre_state(state)


# ---------------------------------------------------------------------------
# Per-user activity tracking \u2014 used by the progressive-seed loop to decide
# when to send delayed FRE cards (e.g. memory-promo after 24 h, capability
# tip after 7 d). Keys are typically the Teams user's UPN; the value is the
# wall-clock timestamp of the last user-originated message.
# ---------------------------------------------------------------------------


def record_user_activity(sender_id: str) -> None:
    """Stamp ``user_activity[sender_id] = now`` and persist."""
    if not sender_id:
        return
    with _WRITE_LOCK:
        state = load_fre_state()
        activity = state.setdefault("user_activity", {})
        if not isinstance(activity, dict):
            activity = {}
            state["user_activity"] = activity
        activity[sender_id] = _now_iso()
        save_fre_state(state)


def get_user_activity() -> dict[str, str]:
    """Return a copy of the per-user last-activity map."""
    activity = load_fre_state().get("user_activity") or {}
    return dict(activity) if isinstance(activity, dict) else {}


# ---------------------------------------------------------------------------
# Project subscription helpers (schema v2).
#
# Reads are cheap; writes go through the same atomic save_fre_state path so
# concurrent ``pc init`` + Portal updates can't corrupt the file.
# ---------------------------------------------------------------------------


def get_subscribed_projects() -> list[str]:
    """Return the list of project ids the user is currently subscribed to.

    Empty list means "never run project detection" — callers should fall
    back to the default project rather than treating this as opt-out.
    """
    projects = load_fre_state().get("projects") or {}
    subs = projects.get("subscribed") if isinstance(projects, dict) else None
    return [str(p) for p in subs] if isinstance(subs, list) else []


def set_subscribed_projects(project_ids: list[str]) -> None:
    """Replace the subscribed-projects list (deduped, order preserved)."""
    seen: set[str] = set()
    cleaned: list[str] = []
    for pid in project_ids:
        if not isinstance(pid, str) or not pid:
            continue
        if pid in seen:
            continue
        seen.add(pid)
        cleaned.append(pid)
    with _WRITE_LOCK:
        state = load_fre_state()
        projects = state.setdefault("projects", _empty_projects_block())
        projects["subscribed"] = cleaned
        save_fre_state(state)


def record_project_detection(
    detected: list[str],
    signals: dict[str, list[str]] | None = None,
) -> None:
    """Persist the most recent detection run.

    ``subscribed`` is left untouched — this function only writes the
    machine's view of the user's environment. The FRE wizard / Portal
    is responsible for prompting the user and then calling
    :func:`set_subscribed_projects`.
    """
    cleaned_detected = [str(p) for p in (detected or []) if isinstance(p, str) and p]
    cleaned_signals: dict[str, list[str]] = {}
    for k, v in (signals or {}).items():
        if not isinstance(k, str) or not isinstance(v, list):
            continue
        cleaned_signals[k] = [str(s) for s in v]
    with _WRITE_LOCK:
        state = load_fre_state()
        projects = state.setdefault("projects", _empty_projects_block())
        projects["detected"] = cleaned_detected
        projects["detection_signals"] = cleaned_signals
        projects["last_detected_at"] = _now_iso()
        save_fre_state(state)


def mark_stale_pending_as_failed(*, max_age_seconds: float = 600.0) -> int:
    """Convert any ``running``/``pending`` entry older than ``max_age_seconds`` to ``failed``.

    Background workers in :mod:`praestoclaw.cli.init_async` are daemon
    threads — when ``pc init`` exits before they finish, the thread dies
    mid-write and the FRE state file is left with ``status == "running"``
    forever. The Portal status bar then spins indefinitely with no Retry
    button (Retry only shows on ``failed``).

    Call this from any long-lived consumer (the web server's
    ``/api/fre/state`` handler, ``pc doctor``) to garbage-collect those
    orphans. Default budget is 10 minutes — well above any healthy clone
    or Graph round-trip but short enough that a forgotten task is
    surfaced before the user gives up.

    Returns the number of entries that were transitioned.
    """
    cutoff = time.time() - max(0.0, max_age_seconds)
    converted = 0
    with _WRITE_LOCK:
        state = load_fre_state()
        pending = state.get("pending") or {}
        if not isinstance(pending, dict):
            return 0
        for _key, entry in list(pending.items()):
            if not isinstance(entry, dict):
                continue
            status = entry.get("status")
            if status not in ("pending", "running"):
                continue
            started_at = entry.get("started_at")
            started_ts = _parse_iso_timestamp(started_at) if started_at else None
            # No started_at means the worker never even reached the
            # "running" branch — treat that as immediately stale so we
            # don't leave a permanent "pending" ghost.
            if started_ts is not None and started_ts > cutoff:
                continue
            entry["status"] = "failed"
            entry["finished_at"] = _now_iso()
            entry.setdefault("started_at", entry["finished_at"])
            entry["error"] = (
                "worker did not finish before the wizard exited "
                "(stale entry — click Retry to run it again)"
            )
            converted += 1
        if converted:
            state["pending"] = pending
            save_fre_state(state)
    return converted


def _parse_iso_timestamp(value: str) -> float | None:
    """Best-effort parse of the timestamps written by :func:`_now_iso`.

    Returns Unix seconds, or ``None`` if the input is unparseable
    (older state files / hand-edits) — callers treat ``None`` as
    "definitely stale".
    """
    try:
        # Python 3.11+ accepts the ``%z`` offset in ``fromisoformat``.
        from datetime import datetime

        return datetime.fromisoformat(value).timestamp()
    except (TypeError, ValueError):
        return None


def _now_iso() -> str:
    # Local time with a UTC offset is fine for FRE telemetry — we only
    # use it for the "started 12s ago" status bar text in the web portal.
    return time.strftime("%Y-%m-%dT%H:%M:%S%z", time.localtime())


__all__ = [
    "SCHEMA_VERSION",
    "PENDING_TEAMS_SIDELOAD",
    "PENDING_MCP_SILENT",
    "PENDING_MARKETPLACE",
    "PENDING_EXTERNAL_IMPORT",
    "KNOWN_PENDING_KEYS",
    "load_fre_state",
    "save_fre_state",
    "update_user_from_idtoken",
    "get_user_role",
    "set_user_role",
    "update_pending",
    "mark_completed",
    "mark_stale_pending_as_failed",
    "is_seed_shown",
    "mark_seed_shown",
    "is_teams_fre_disabled",
    "disable_teams_fre",
    "record_user_activity",
    "get_user_activity",
    "get_subscribed_projects",
    "set_subscribed_projects",
    "record_project_detection",
]
