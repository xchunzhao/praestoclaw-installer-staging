"""PraestoClaw — Enterprise AI assistant with Microsoft ecosystem integration."""

from importlib.metadata import PackageNotFoundError, version

try:
    __version__ = version("praestoclaw")
except PackageNotFoundError:
    __version__ = "0.0.0-dev"
