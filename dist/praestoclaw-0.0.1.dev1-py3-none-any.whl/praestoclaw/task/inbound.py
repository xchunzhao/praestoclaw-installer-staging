"""Inbound dispatchers for ``task.progress`` events and ``task.control`` requests.

Phase 1 client semantics:

* ``task.progress`` events are surfaced to the user via the existing
  push-notification path (the same one the legacy A2A runtime uses for
  ACK / ERROR replies). The notification is a multi-line markdown
  "card" that includes the relevant action hint:

  - **Receiver, waiting_approval** → "Run ``/task approve <id>`` or
    ``/task deny <id>``" so the human can resolve the gate from chat.
  - **Receiver, executing** → "Run ``/task interrupt <id>``" so the
    human who approved the task can still pull the brake mid-flight
    (docs/07 §10: ``interrupt`` is bilateral; ``cancel`` is sender-only).
  - **Sender, non-terminal** → "Run ``/task cancel <id>``" so the
    initiator can pull the task back at any point.
  - **Terminal stages** → read-only summary, no action prompt.

  We rate-limit ``executing`` heartbeats so a long-running task
  doesn't spam the user every 30s; only stage transitions push.

* ``task.control`` requests forwarded by the Gateway have action
  ``undo`` (per spec §7 and ``task_protocol_smoke.py`` scenario 6).
  The client has no real undo capability in Phase 1 — it replies with
  ``error{code:"task.undo_unsupported"}`` per spec §9, raised as a
  ``BusinessError`` so the dispatcher turns it into a wire-level
  ``error`` envelope on the original correlation id.

These handlers are intentionally tiny / pure-ish so they unit-test
without booting a Gateway or a real CloudChannel.
"""

from __future__ import annotations

import json
import re
import time
from collections.abc import Callable
from typing import Any

from agent_gateway_protocol.gateway_protocol.v1.task import (
    TASK_CONTROL_TOPIC,
    TASK_PROGRESS_TOPIC,
    TERMINAL_STAGES,
    format_a2a_task_request_id,
)
from loguru import logger

from praestoclaw.bus.events import OutboundMessage
from praestoclaw.bus.queue import MessageBus
from praestoclaw.config.schema import ChannelType
from praestoclaw.gateway_protocol.business.dispatcher import Dispatcher
from praestoclaw.gateway_protocol.business.envelope import BusinessError

# Escape the CommonMark inline-formatting metacharacters so untrusted
# strings (peer-supplied ``summary`` / ``recipient`` from the remote
# task body) can't inject bold / headers / links / lists into the
# attribution header the sender sees in chat.
_MD_ESCAPE_RE = re.compile(r"([\\`*_{}\[\]()#+\-.!|>~])")


def _escape_md(text: str) -> str:
    return _MD_ESCAPE_RE.sub(r"\\\1", text)


_STAGE_BADGE = {
    "queued": "⏳",
    "gating": "🔎",
    "waiting_approval": "🛂",
    "executing": "⚙️",
    "done": "✅",
    "declined": "🚫",
    "interrupted": "✋",
    "failed": "❌",
    "timed_out": "⌛",
}

# Human-friendly stage labels used as the card's prominent headline.
# Uppercased + spaced so the status reads at a glance instead of being
# buried inside a parenthesised metadata blob.
_STAGE_LABEL = {
    "queued": "QUEUED",
    "gating": "GATING",
    "waiting_approval": "WAITING APPROVAL",
    "executing": "EXECUTING",
    "done": "DONE",
    "declined": "DECLINED",
    "interrupted": "INTERRUPTED",
    "failed": "FAILED",
    "timed_out": "TIMED OUT",
}


# Rate-limit per-task notification pushes: we always push stage
# transitions, but suppress repeat ``executing`` heartbeats from the
# same task within this window so the user's chat doesn't get spammed.
_HEARTBEAT_THROTTLE_S = 60.0
_LAST_PUSH: dict[tuple[str, str], float] = {}

# Per-task stage transition timeline: list of (stage, wall_clock_epoch_s)
# in arrival order, deduped on consecutive same-stage repeats. Used to
# render a one-line status flow under the card so the user can see how
# long each phase took.
_TIMELINE: dict[str, list[tuple[str, float]]] = {}
_TIMELINE_MAX = 8


def _role_for(body: dict[str, Any], local_user_id: str | None) -> str:
    """Return ``"sender" | "recipient" | "observer"`` from the local
    perspective. ``observer`` covers the rare case where neither side
    matches our identity (e.g. mis-routed event)."""

    if not local_user_id:
        return "observer"
    if body.get("sender_user_id") == local_user_id:
        return "sender"
    if body.get("recipient_user_id") == local_user_id:
        return "recipient"
    return "observer"


# Machine reason codes emitted by the gateway coordinator (see
# apps/cloud_gateway/.../task_v1/coordinator.py). Mapped here to a
# human-friendly verb phrase. ``{actor}`` is filled in when the code
# represents a user-initiated action; the no-actor codes leave it
# blank.
_REASON_TEMPLATES: dict[str, str] = {
    "approval_denied": "Denied by {actor}",
    "sender_cancel": "Cancelled by {actor}",
    "interrupt": "Interrupted by {actor}",
    "approval_timeout": "No response — approval timed out",
    "executing_deadline": "Execution deadline exceeded",
    "max_lifetime": "Task exceeded its maximum lifetime",
    "deliver_failed": "Delivery to the recipient failed",
    "executor_error": "Executor reported an error",
}


def _actor_label(actor_uid: str, role: str, sender: str, recipient: str) -> str:
    """Return ``"you"`` / ``"sender (<id>)"`` / ``"recipient (<id>)"``
    so the user can tell at a glance who triggered a terminal stage."""

    if not actor_uid:
        return "the other party"
    if role == "sender" and actor_uid == sender:
        return "you"
    if role == "recipient" and actor_uid == recipient:
        return "you"
    if actor_uid == sender:
        return f"sender ({sender})"
    if actor_uid == recipient:
        return f"recipient ({recipient})"
    return actor_uid


def _humanize_terminal_reason(
    details: dict[str, Any],
    role: str,
    sender: str,
    recipient: str,
) -> str:
    """Build a human-readable failure-reason sentence for non-``done``
    terminal stages. Returns ``""`` when nothing useful is available
    (caller falls back to existing behaviour).

    Combines the machine ``reason`` code with the ``by`` actor and
    any free-text ``note`` the initiator supplied.
    """

    code = str(details.get("reason") or "").strip()
    by = str(details.get("by") or "").strip()
    note = str(details.get("note") or "").strip()
    message = str(details.get("message") or "").strip()
    err_code = str(details.get("code") or "").strip()

    template = _REASON_TEMPLATES.get(code)
    if template is not None:
        base = template.format(actor=_actor_label(by, role, sender, recipient))
    elif code:
        # Unknown machine code — surface it verbatim rather than
        # silently dropping the only signal we have.
        base = code
    else:
        base = ""

    # Append concrete details so executor / binding error text isn't
    # hidden behind a generic humanized reason (e.g. ``executor_error``
    # → "Executor reported an error" alone is not debuggable).
    suffix_parts: list[str] = []
    if note:
        suffix_parts.append(note)
    if message and message != note:
        suffix_parts.append(message)
    if err_code:
        suffix_parts.append(f"[{err_code}]")
    suffix = " — ".join(suffix_parts)

    if base and suffix:
        return f"{base} — {suffix}"
    return base or suffix


def format_progress_notification(body: dict[str, Any]) -> str:
    """Render a ``task.progress`` body as a short status line (legacy)."""

    task_id = str(body.get("task_id") or "(unknown)")
    stage = str(body.get("stage") or "unknown")
    summary = str(body.get("summary") or "").strip()
    tier = body.get("tier")
    elapsed_ms = body.get("elapsed_ms")
    badge = _STAGE_BADGE.get(stage, "•")

    pieces: list[str] = [f"{badge} [task {task_id}] stage={stage}"]
    if tier:
        pieces.append(f"tier={tier}")
    if isinstance(elapsed_ms, int) and elapsed_ms >= 0:
        pieces.append(f"elapsed={elapsed_ms}ms")
    head = " ".join(pieces)

    if summary:
        return f"{head} — {summary}"
    return head


def render_progress_card(body: dict[str, Any], role: str) -> str:
    """Render a multi-line markdown notification for the user.

    The format is intentionally simple so it works in plain-text
    surfaces (CLI / Teams text fallback) and renders sensibly under
    the web chat's markdown renderer.
    """

    task_id = str(body.get("task_id") or "(unknown)")
    stage = str(body.get("stage") or "unknown")
    tier = str(body.get("tier") or "?")
    summary = str(body.get("summary") or "").strip() or "(no summary)"
    sender = str(body.get("sender_user_id") or "?")
    recipient = str(body.get("recipient_user_id") or "?")
    badge = _STAGE_BADGE.get(stage, "•")
    stage_label = _STAGE_LABEL.get(stage, stage.upper().replace("_", " "))
    is_a2a = sender != recipient and sender != "?" and recipient != "?"
    label = "A2A Task" if is_a2a else "Task"

    if role == "sender":
        peer_label = f"→ {recipient}"
    elif role == "recipient":
        peer_label = f"← {sender}"
    else:
        peer_label = f"{sender} → {recipient}"

    terminal = stage in TERMINAL_STAGES
    details = body.get("details")

    # Layout: in-flight stages keep status inline (compact). Terminal
    # stages promote the status to an H3 heading so the final outcome
    # is unmistakable at a glance — declined / timed_out / interrupted
    # in particular were too easy to miss when scanning a long chat.
    meta_line = f"{label} {peer_label} · `{task_id}` · tier {tier}"
    if terminal:
        lines = [
            f"### {badge} {stage_label}",
            meta_line,
            f"> {summary}",
        ]
    else:
        lines = [
            f"**{badge} {stage_label}** · {meta_line}",
            f"> {summary}",
        ]
    timeline_md = _format_timeline_markdown(task_id)
    if timeline_md:
        lines.append(timeline_md)

    # Task cards are status surfaces. On *failure* terminals
    # (declined / timed_out / interrupted / failed) we surface the
    # reason inline so the "why" line carries the same visual weight
    # as the heading, and we humanize the machine code + actor (e.g.
    # ``sender_cancel`` by Alice → ``Cancelled by you`` / ``Cancelled
    # by sender (alice)``).
    #
    # On stage=done we deliberately do NOT inline ``result_text`` —
    # the card stays compact and the actual result is published as a
    # separate chat message by ``publish_progress_notification`` so it
    # renders as a normal agent reply (a fresh bubble in the web UI /
    # a normal Teams message rather than buried inside the card).
    if terminal and stage != "done" and isinstance(details, dict):
        extra = ""
        result_text = details.get("result_text")
        if isinstance(result_text, str) and result_text.strip():
            extra = result_text.strip()
        else:
            humanized = _humanize_terminal_reason(details, role, sender, recipient)
            if humanized:
                extra = humanized
            else:
                # Last-resort fallback: any free-text message attached
                # by the binding (e.g. carrier error text).
                msg = details.get("message")
                if isinstance(msg, str) and msg.strip():
                    extra = msg.strip()
        if extra:
            lines.append("")
            lines.append(f"**Reason:** {extra}")

    if not terminal:
        action_hints = _action_hints_for(stage, role, task_id)
        if action_hints:
            lines.append("")
            lines.extend(action_hints)
    return "\n".join(lines)


def _action_hints_for(stage: str, role: str, task_id: str) -> list[str]:
    """Surface CLI / chat slash commands the user can run right now."""

    if role == "recipient" and stage == "waiting_approval":
        return [
            f"Reply `/task approve {task_id}` to allow, or `/task deny {task_id}` to refuse.",
        ]
    if role == "recipient" and stage == "executing":
        # docs/07 §10: ``interrupt`` is bilateral. Receiver uses it to
        # stop a task they previously approved (sender uses ``cancel``).
        return [f"Reply `/task interrupt {task_id}` to stop."]
    if role == "sender" and stage in {
        "queued",
        "gating",
        "waiting_approval",
        "executing",
    }:
        return [f"Reply `/task cancel {task_id}` to abort."]
    return []


def _should_throttle(task_id: str, stage: str) -> bool:
    """Drop repeat ``executing`` heartbeats within the throttle window."""

    if stage != "executing":
        return False
    key = (task_id, stage)
    now = time.monotonic()
    last = _LAST_PUSH.get(key)
    if last is not None and (now - last) < _HEARTBEAT_THROTTLE_S:
        return True
    _LAST_PUSH[key] = now
    return False


def _channel_id_for_task(task_id: str) -> str:
    return f"task:notify:{task_id or 'unknown'}"


def _record_timeline(task_id: str, stage: str) -> None:
    """Append a (stage, wall_clock) entry, deduping consecutive repeats.

    Uses ``time.time()`` (not monotonic) so we can show a wall-clock
    timestamp on the first stage. Capped at ``_TIMELINE_MAX`` to avoid
    unbounded growth on long-lived tasks.
    """
    if not task_id:
        return
    history = _TIMELINE.setdefault(task_id, [])
    if history and history[-1][0] == stage:
        return
    history.append((stage, time.time()))
    if len(history) > _TIMELINE_MAX:
        del history[: len(history) - _TIMELINE_MAX]


def _format_elapsed(seconds: float) -> str:
    """Render an elapsed duration in a compact human form."""
    if seconds < 0:
        seconds = 0.0
    if seconds < 1:
        return f"{int(seconds * 1000)}ms"
    if seconds < 60:
        return f"{seconds:.1f}s"
    minutes, secs = divmod(int(seconds), 60)
    if minutes < 60:
        return f"{minutes}m{secs:02d}s"
    hours, mins = divmod(minutes, 60)
    return f"{hours}h{mins:02d}m"


def _format_timeline_markdown(task_id: str) -> str:
    """Build a one-line timeline like ``⏳ 12:34:01 → 🛂 +1.2s → ✅ +4s``.

    Returns an empty string when the task has fewer than two recorded
    stages — a single-stage card doesn't benefit from a timeline.
    """
    history = _TIMELINE.get(task_id) or []
    if len(history) < 2:
        return ""
    parts: list[str] = []
    first_stage, first_ts = history[0]
    first_clock = time.strftime("%H:%M:%S", time.localtime(first_ts))
    parts.append(f"{_STAGE_BADGE.get(first_stage, '•')} {first_clock}")
    prev_ts = first_ts
    for stage, ts in history[1:]:
        delta = _format_elapsed(ts - prev_ts)
        parts.append(f"{_STAGE_BADGE.get(stage, '•')} +{delta}")
        prev_ts = ts
    return "⏱ " + " → ".join(parts)


# Adaptive Card colour mapping per stage. Adaptive Cards only ships
# six well-known semantic colours, so we group neutral / warning /
# action / success / failure stages onto the closest match.
_STAGE_AC_COLOR = {
    "queued": "default",
    "gating": "accent",
    "waiting_approval": "warning",
    "executing": "accent",
    "done": "good",
    "declined": "attention",
    "interrupted": "attention",
    "failed": "attention",
    "timed_out": "attention",
}

_ADAPTIVE_CARD_CONTENT_TYPE = "application/vnd.microsoft.card.adaptive"


def render_progress_adaptive_card(body: dict[str, Any], role: str) -> dict[str, Any]:
    """Build a Bot Framework Activity wrapping an Adaptive Card.

    The cloud channel's ``_extract_card_from_activity_json`` recognises
    this exact shape and promotes the inner card into ``content.card``
    on the gateway notify body, so Teams renders an actual card instead
    of a JSON blob. The fallback ``text`` is the same markdown the web
    surface uses, so non-Teams downstreams still get something readable.
    """

    task_id = str(body.get("task_id") or "(unknown)")
    stage = str(body.get("stage") or "unknown")
    tier = str(body.get("tier") or "?")
    summary = str(body.get("summary") or "").strip() or "(no summary)"
    sender = str(body.get("sender_user_id") or "?")
    recipient = str(body.get("recipient_user_id") or "?")
    badge = _STAGE_BADGE.get(stage, "•")
    stage_label = _STAGE_LABEL.get(stage, stage.upper().replace("_", " "))
    color = _STAGE_AC_COLOR.get(stage, "default")
    is_a2a = sender != recipient and sender != "?" and recipient != "?"
    label = "A2A Task" if is_a2a else "Task"
    terminal = stage in TERMINAL_STAGES

    facts: list[dict[str, str]] = []
    if is_a2a:
        facts.append({"title": "From", "value": sender})
        facts.append({"title": "To", "value": recipient})
    facts.append({"title": "Tier", "value": tier})
    facts.append({"title": "Task ID", "value": task_id})

    # Terminal stages get the most prominent typography (ExtraLarge)
    # so the final outcome — especially DECLINED / TIMED OUT /
    # INTERRUPTED — reads loud in Teams. In-flight stages stay Large
    # to avoid screaming on every executing heartbeat.
    head_size = "ExtraLarge" if terminal else "Large"
    body_blocks: list[dict[str, Any]] = [
        {
            "type": "TextBlock",
            "text": f"{badge} {stage_label}",
            "weight": "Bolder",
            "size": head_size,
            "color": color,
            "wrap": True,
        },
        {
            "type": "TextBlock",
            "text": f"{label} \u00b7 {summary}",
            "wrap": True,
            "spacing": "Small",
        },
        {"type": "FactSet", "facts": facts, "spacing": "Small"},
    ]

    # Inline reason on *failure* terminal stages only — same content
    # as the markdown card's tail block. ``done`` deliberately does
    # NOT inline ``result_text`` here; the result rides on a separate
    # normal chat message (see ``publish_progress_notification``).
    details = body.get("details")
    if terminal and stage != "done" and isinstance(details, dict):
        extra = ""
        result_text = details.get("result_text")
        if isinstance(result_text, str) and result_text.strip():
            extra = result_text.strip()
        else:
            humanized = _humanize_terminal_reason(details, role, sender, recipient)
            if humanized:
                extra = humanized
            else:
                msg_text = details.get("message")
                if isinstance(msg_text, str) and msg_text.strip():
                    extra = msg_text.strip()
        if extra:
            body_blocks.append(
                {
                    "type": "TextBlock",
                    "text": f"**Reason:** {extra}",
                    "wrap": True,
                    "spacing": "Medium",
                    "weight": "Bolder",
                    "color": "attention",
                }
            )

    timeline_md = _format_timeline_markdown(task_id)
    if timeline_md:
        body_blocks.append(
            {
                "type": "TextBlock",
                "text": timeline_md,
                "wrap": True,
                "spacing": "Medium",
                "isSubtle": True,
                "size": "Small",
            }
        )

    # Action.Submit ``data`` uses the ``approval_action`` /
    # ``approval_request_id`` shape that the Teams bridge's
    # BridgeRequest model already understands (see
    # cloud_gateway/src/gateway/models/teams_bridge.py). The
    # ``a2a:task:`` prefix on ``approval_request_id`` lets the bridge
    # short-circuit to ``TaskCoordinator.handle_control`` instead of
    # delivering the click to the agent — without the prefix the
    # bridge would treat it as a tool-authorization approval. The
    # markdown rendering still surfaces ``/task <action> <id>`` so
    # web/CLI users can type the command instead of clicking.
    actions: list[dict[str, Any]] = []
    if not terminal:
        # ``a2a:task:<task_id>`` namespaces this approval_request_id
        # under the a2a-task protocol so the gateway's Teams bridge
        # short-circuits the click straight to TaskCoordinator.handle_control
        # (docs/07 §7) instead of forwarding it to the agent. The
        # prefix/format is owned by
        # :func:`format_a2a_task_request_id` so the gateway and client
        # cannot drift out of sync.
        request_id = format_a2a_task_request_id(task_id)
        if role == "recipient" and stage == "waiting_approval":
            actions.append(
                {
                    "type": "Action.Submit",
                    "title": "Approve",
                    "style": "positive",
                    "data": {
                        "approval_action": "approve",
                        "approval_request_id": request_id,
                    },
                }
            )
            actions.append(
                {
                    "type": "Action.Submit",
                    "title": "Deny",
                    "style": "destructive",
                    "data": {
                        "approval_action": "deny",
                        "approval_request_id": request_id,
                    },
                }
            )
        elif role == "recipient" and stage == "executing":
            # docs/07 §10: receiver uses ``interrupt`` to stop a task
            # they previously approved (``cancel`` is sender-only).
            actions.append(
                {
                    "type": "Action.Submit",
                    "title": "Interrupt",
                    "style": "destructive",
                    "data": {
                        "approval_action": "interrupt",
                        "approval_request_id": request_id,
                    },
                }
            )
        elif role == "sender" and stage in {
            "queued",
            "gating",
            "waiting_approval",
            "executing",
        }:
            actions.append(
                {
                    "type": "Action.Submit",
                    "title": "Cancel",
                    "style": "destructive",
                    "data": {
                        "approval_action": "cancel",
                        "approval_request_id": request_id,
                    },
                }
            )

    card: dict[str, Any] = {
        "type": "AdaptiveCard",
        "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
        "version": "1.4",
        "body": body_blocks,
    }
    if actions:
        card["actions"] = actions

    activity: dict[str, Any] = {
        "type": "message",
        "text": render_progress_card(body, role),
        "attachments": [
            {
                "contentType": _ADAPTIVE_CARD_CONTENT_TYPE,
                "content": card,
            }
        ],
    }
    return activity


async def publish_progress_notification(
    bus: MessageBus,
    body: dict[str, Any],
    *,
    channel: ChannelType | str = ChannelType.CLOUD,
    local_user_id: str | None = None,
) -> None:
    """Surface a ``task.progress`` body as a chat-visible notification.

    Routing strategy:

    * Render a markdown card (role-aware: sender vs recipient vs
      observer, and stage-aware: terminal vs in-flight).
    * Throttle ``executing`` heartbeats so the chat doesn't spam.
    * Publish as an ``OutboundMessage`` on ``ChannelType.WEB`` with a
      synthetic per-task channel_id. The web channel falls back to
      broadcast across all push subscribers when no precise route
      matches, so every connected ``pc chat`` / web client sees it.
    """

    text_summary = format_progress_notification(body)
    stage = str(body.get("stage") or "")
    task_id = str(body.get("task_id") or "")
    terminal = stage in TERMINAL_STAGES
    logger.info("task.progress: {} terminal={}", text_summary, terminal)

    if _should_throttle(task_id, stage):
        return

    role = _role_for(body, local_user_id)
    if role == "observer":
        # Don't push to user — we're not party to this task.
        return

    # Record the stage transition BEFORE rendering so the timeline
    # block on the card includes the current stage. ``_record_timeline``
    # dedupes on consecutive same-stage entries, so executing
    # heartbeats (already throttled above) won't pile on either.
    _record_timeline(task_id, stage)

    card = render_progress_card(body, role)
    sender = str(body.get("sender_user_id") or "")
    recipient = str(body.get("recipient_user_id") or "")
    is_a2a = bool(sender and recipient and sender != recipient)
    details = body.get("details") if isinstance(body.get("details"), dict) else {}
    result_text = ""
    if isinstance(details, dict):
        rt = details.get("result_text")
        if isinstance(rt, str):
            result_text = rt

    # Wire a structured JSON payload so the web UI can upsert a
    # single live card per task_id (see chat.js task_progress
    # handler). The ``markdown`` field is the fallback for surfaces
    # that don't recognise the typed payload.
    push_payload = {
        "type": "task_progress",
        "task_id": task_id,
        "stage": stage,
        "tier": str(body.get("tier") or ""),
        "summary": str(body.get("summary") or ""),
        "sender_user_id": sender,
        "recipient_user_id": recipient,
        "role": role,
        "is_a2a": is_a2a,
        "terminal": terminal,
        "elapsed_ms": body.get("elapsed_ms"),
        "stage_deadline_ms": body.get("stage_deadline_ms"),
        "result_text": result_text,
        "details": details if isinstance(details, dict) else {},
        "actions": body.get("actions") or [],
        "markdown": card,
    }
    msg = OutboundMessage(
        channel=ChannelType.WEB,
        channel_id=_channel_id_for_task(task_id),
        content=json.dumps(push_payload),
        format="json",
        metadata={
            "source": "task.progress",
            "task_id": task_id,
            "stage": stage,
            "role": role,
            "is_a2a": is_a2a,
        },
    )

    try:
        await bus.publish_outbound(msg)
    except Exception:
        logger.exception("task.progress: failed to surface notification")

    # Mirror the same notification onto the cloud channel as a Bot
    # Framework Activity wrapping an Adaptive Card. The cloud channel's
    # ``_send_notify`` recognises this exact shape and promotes the
    # inner card into ``content.card`` on the gateway notify body, so
    # Teams renders an actual interactive card. Surfaces that aren't
    # Teams (CLI / non-card pushers) get the activity's ``text`` field
    # as a markdown fallback. We only emit when there's a cloud channel
    # to avoid spurious "no transport" warnings on local-only setups.
    try:
        activity = render_progress_adaptive_card(body, role)
        cloud_msg = OutboundMessage(
            channel=ChannelType.CLOUD,
            channel_id=_channel_id_for_task(task_id),
            content=json.dumps(activity),
            format="json",
            metadata={
                "source": "task.progress",
                "task_id": task_id,
                "stage": stage,
                "role": role,
                "is_a2a": is_a2a,
                # In-place update on Teams: every stage transition for
                # the same task targets the same activity id, so the
                # card animates in place rather than stacking.
                "update_key": f"task:{task_id}",
                "push_target": "teams",
            },
        )
        await bus.publish_outbound(cloud_msg)
    except Exception:
        logger.exception("task.progress: failed to mirror to cloud channel")

    # Standalone result bubble for any terminal stage. The task card
    # stays a compact status surface; the actual reply text rides on a
    # normal chat message so it lands as a fresh bubble in the web UI
    # and a regular Teams message — not buried inside the (frequently
    # collapsed) card body.
    #
    # * ``done``: emit the executor's ``result_text`` verbatim (the
    #   user's expected reply).
    # * Non-``done`` terminals (declined / failed / interrupted /
    #   timed_out): emit a one-paragraph "why it didn't complete"
    #   message built from the humanized reason + actor + note so the
    #   user doesn't have to expand the card to learn what happened.
    result_payload: str = ""
    if stage == "done":
        result_payload = result_text.strip()
    elif terminal:
        # Mirror render_progress_card precedence: prefer the concrete
        # ``result_text`` (e.g. executor-supplied failure body) over the
        # generic humanized reason so the bubble carries the most
        # actionable detail. Fall back to the humanized reason / code
        # when no result_text was attached.
        detail = (
            result_text.strip()
            if result_text and result_text.strip()
            else _humanize_terminal_reason(
                details if isinstance(details, dict) else {},
                role,
                sender,
                recipient,
            )
        )
        badge = _STAGE_BADGE.get(stage, "•")
        stage_label = _STAGE_LABEL.get(stage, stage.upper().replace("_", " ")).lower()
        summary = str(body.get("summary") or "").strip()
        headline = f"{badge} Task {stage_label}"
        if summary:
            headline = f"{headline}: {summary}"
        if detail:
            result_payload = f"{headline}\n\n{detail}"
        else:
            result_payload = headline

    # On the sender side of an a2a task, prepend a one-line attribution
    # header so the owner doesn't confuse the remote executor's reply
    # with their own agent's output. Recipient-side keeps the bubble
    # bare — it IS their agent's reply, no attribution needed.
    if result_payload and role == "sender" and is_a2a:
        attr_summary = _escape_md(str(body.get("summary") or "").strip())
        peer = _escape_md(recipient or "remote user")
        attribution = (
            f"> 📨 Result from **{peer}**'s agent — task: _{attr_summary or _escape_md(task_id)}_"
        )
        result_payload = f"{attribution}\n\n{result_payload}"

    if result_payload:
        try:
            web_result = OutboundMessage(
                channel=ChannelType.WEB,
                channel_id=_channel_id_for_task(task_id),
                content=result_payload,
                format="markdown",
                metadata={
                    "source": "task.result",
                    "task_id": task_id,
                    "stage": stage,
                    "role": role,
                    "is_a2a": is_a2a,
                },
            )
            await bus.publish_outbound(web_result)
        except Exception:
            logger.exception("task.result: failed to surface result to web")
        try:
            cloud_result = OutboundMessage(
                channel=ChannelType.CLOUD,
                channel_id=_channel_id_for_task(task_id),
                content=result_payload,
                format="markdown",
                metadata={
                    "source": "task.result",
                    "task_id": task_id,
                    "stage": stage,
                    "role": role,
                    "is_a2a": is_a2a,
                    "push_target": "teams",
                },
            )
            await bus.publish_outbound(cloud_result)
        except Exception:
            logger.exception("task.result: failed to mirror result to cloud")


def handle_task_control_request(body: dict[str, Any]) -> dict[str, Any]:
    """Handle a ``task.control`` request forwarded by the Gateway.

    Phase 1: the only action the Gateway forwards to clients is
    ``undo`` (the others are interpreted by the coordinator itself).
    The client has no real undo capability — reply with
    ``task.undo_unsupported`` per spec §9, which surfaces as a wire
    ``error`` envelope on the correlation_id.

    Returning a normal mapping would produce a ``response`` envelope
    (i.e. silently ack the undo) — that is exactly what the spec
    forbids, so we always raise.

    A non-``undo`` action arriving here is unexpected (the coordinator
    consumes them); we still refuse so we never silently swallow it.
    """

    action = str(body.get("action") or "")
    task_id = str(body.get("task_id") or "")

    if action == "undo":
        logger.info(
            "task.control(undo) received task_id={} by_user_id={} — replying "
            "task.undo_unsupported (Phase 1 client has no undo capability)",
            task_id or "(unknown)",
            body.get("by_user_id") or "",
        )
        raise BusinessError(
            "task.undo_unsupported",
            "this agent cannot compensate the requested task",
            retryable=False,
            details={"task_id": task_id},
        )

    # Defensive: surface any other forwarded action loudly rather than
    # accidentally acknowledging it.
    logger.warning(
        "task.control received unexpected action={!r} task_id={} — refusing",
        action,
        task_id,
    )
    raise BusinessError(
        "task.unsupported_action",
        f"client does not handle task.control action={action!r}",
        retryable=False,
        details={"task_id": task_id, "action": action},
    )


def register_task_handlers(
    dispatcher: Dispatcher,
    bus: MessageBus,
    *,
    channel: ChannelType | str = ChannelType.CLOUD,
    local_user_id_provider: Callable[[], str] | None = None,
) -> None:
    """Wire the two Phase-1 task topics into *dispatcher*.

    Called by ``CloudChannel._register_dispatcher`` alongside the other
    on_event / on_request hookups. ``local_user_id_provider`` lets the
    caller defer user_id lookup until the event arrives (the auth
    handshake may not have completed when this is registered).
    """

    @dispatcher.on_event(TASK_PROGRESS_TOPIC)
    async def _on_progress(body: dict[str, Any], _ctx: Any) -> None:
        local_uid: str | None = None
        if local_user_id_provider is not None:
            try:
                local_uid = local_user_id_provider()
            except Exception:
                local_uid = None
        await publish_progress_notification(bus, body, channel=channel, local_user_id=local_uid)

    @dispatcher.on_request(TASK_CONTROL_TOPIC)
    async def _on_control(body: dict[str, Any], _ctx: Any) -> dict[str, Any]:
        # Sync helper; surface its BusinessError unchanged so the
        # dispatcher converts it to an error envelope.
        return handle_task_control_request(body)
