"""Agent-Gateway v2 wire protocol binding for the shared transport client."""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any

from agent_gateway_protocol.gateway_protocol.v2.transport import (
    DEFAULT_MAX_OUTBOX_BYTES,
    DEFAULT_MAX_PAYLOAD_BYTES,
    DEFAULT_PING_INTERVAL_MS,
    DEFAULT_PONG_TIMEOUT_MS,
    DEFAULT_RESUME_TTL_MS,
    SUPPORTED_PROTOCOL_VERSION,
    TransportCloseCode,
    TransportProtocolError,
    encoded_json_size,
)
from agent_gateway_protocol.gateway_protocol.v2.transport import (
    encode_transport_frame as _encode_transport_frame,
)
from agent_gateway_protocol.gateway_protocol.v2.transport import (
    parse_transport_frame as _parse_shared_transport_frame,
)

from praestoclaw.gateway_protocol.transport import (
    TransportCloseCodes,
    TransportError,
    TransportWireProtocol,
)

CloseCode = TransportCloseCode
PROTOCOL_VERSION = SUPPORTED_PROTOCOL_VERSION

V2_CLOSE_CODES = TransportCloseCodes(
    normal=int(CloseCode.NORMAL),
    authentication_failed=int(CloseCode.AUTHENTICATION_FAILED),
    server_internal_error=int(CloseCode.SERVER_INTERNAL_ERROR),
    protocol_error=int(CloseCode.PROTOCOL_ERROR),
    sequence_error=int(CloseCode.SEQUENCE_ERROR),
    payload_too_large=int(CloseCode.PAYLOAD_TOO_LARGE),
    heartbeat_timeout=int(CloseCode.HEARTBEAT_TIMEOUT),
    superseded=int(CloseCode.SUPERSEDED),
    resume_rejected=int(CloseCode.RESUME_REJECTED),
    version_unsupported=int(CloseCode.VERSION_UNSUPPORTED),
)

ERROR_CODE_CLOSE_CODES = {
    "unknown_session": V2_CLOSE_CODES.resume_rejected,
    "expired_session": V2_CLOSE_CODES.resume_rejected,
    "resume_rejected": V2_CLOSE_CODES.resume_rejected,
    "version_negotiation_failed": V2_CLOSE_CODES.version_unsupported,
    "authentication_failed": V2_CLOSE_CODES.authentication_failed,
    "superseded": V2_CLOSE_CODES.superseded,
    "payload_too_large": V2_CLOSE_CODES.payload_too_large,
}

RECOVERABLE_CLOSE_CODES = frozenset(
    {
        V2_CLOSE_CODES.server_internal_error,
        V2_CLOSE_CODES.heartbeat_timeout,
        V2_CLOSE_CODES.resume_rejected,
        V2_CLOSE_CODES.authentication_failed,
    }
)


def encode_frame(frame: Mapping[str, Any]) -> str:
    """Serialize a v2 transport frame to compact UTF-8 JSON text."""

    return _encode_transport_frame(dict(frame))


def parse_transport_frame(raw: str | bytes) -> dict[str, Any]:
    """Parse and validate a v2 transport frame received by the agent."""

    try:
        frame = _parse_shared_transport_frame(raw, role="agent")
    except TransportProtocolError as exc:
        raise TransportError(exc.close_code, exc.message) from exc
    return frame.model_dump()


V2_WIRE_PROTOCOL = TransportWireProtocol(
    name="agent_gateway_v2",
    protocol_version=PROTOCOL_VERSION,
    close_codes=V2_CLOSE_CODES,
    default_ping_interval_ms=DEFAULT_PING_INTERVAL_MS,
    default_pong_timeout_ms=DEFAULT_PONG_TIMEOUT_MS,
    default_resume_ttl_ms=DEFAULT_RESUME_TTL_MS,
    default_max_payload_bytes=DEFAULT_MAX_PAYLOAD_BYTES,
    default_max_outbox_bytes=DEFAULT_MAX_OUTBOX_BYTES,
    recoverable_close_codes=RECOVERABLE_CLOSE_CODES,
    error_code_close_codes=ERROR_CODE_CLOSE_CODES,
    parse_frame=parse_transport_frame,
    encode_frame=encode_frame,
    encoded_json_size=encoded_json_size,
)
