"""Compatibility re-exports for shared Agent-Gateway business data models."""

from agent_gateway_protocol.gateway_protocol.v1.business.data import (
    CONTENT_TYPES,
    TEXT_FORMATS,
    Content,
    ConversationBody,
    ConversationContext,
    FileChunkContent,
    Recipient,
    Sender,
    SessionBye,
    SessionByeReason,
    SessionHello,
    TextContent,
    parse_content,
    validate_conversation_body,
)

__all__ = [
    "CONTENT_TYPES",
    "TEXT_FORMATS",
    "Content",
    "ConversationBody",
    "ConversationContext",
    "FileChunkContent",
    "Recipient",
    "Sender",
    "SessionBye",
    "SessionByeReason",
    "SessionHello",
    "TextContent",
    "parse_content",
    "validate_conversation_body",
]
