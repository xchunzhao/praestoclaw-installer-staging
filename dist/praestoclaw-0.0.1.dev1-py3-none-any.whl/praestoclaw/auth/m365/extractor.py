"""Parse MSAL ``RefreshToken`` records from Teams Web's localStorage."""

from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True, slots=True)
class RefreshTokenRecord:
    """A single MSAL ``RefreshToken`` cache entry parsed from Teams localStorage."""

    client_id: str
    home_account_id: str  # ``<oid>.<tid>``
    tenant_id: str
    secret: str
    environment: str = "login.windows.net"

    @property
    def oid(self) -> str:
        return self.home_account_id.split(".", 1)[0]


def extract_refresh_tokens(local_storage: dict[str, str]) -> list[RefreshTokenRecord]:
    """Pull ``RefreshToken`` entries from a Teams Web ``localStorage`` snapshot.

    The keys MSAL uses look like::

        msal.2|<oid>.<tid>|login.windows.net|refreshtoken|<client_id>|||

    Values are JSON with at minimum ``credentialType``, ``secret``,
    ``clientId``, ``homeAccountId``, ``environment``. Tenant is split out of
    ``homeAccountId``. Entries that don't parse are skipped silently — the
    caller treats an empty list as "no usable RT".
    """
    out: list[RefreshTokenRecord] = []
    for key, value in local_storage.items():
        if not key.startswith("msal.2|") or "|refreshtoken|" not in key:
            continue
        try:
            entry = json.loads(value)
        except (TypeError, json.JSONDecodeError):
            continue
        if not isinstance(entry, dict):
            continue
        if entry.get("credentialType") != "RefreshToken":
            continue
        secret = entry.get("secret")
        client_id = entry.get("clientId")
        home = entry.get("homeAccountId")
        if not (secret and client_id and home and "." in home):
            continue
        tenant = home.split(".", 1)[1]
        out.append(
            RefreshTokenRecord(
                client_id=str(client_id),
                home_account_id=str(home),
                tenant_id=tenant,
                secret=str(secret),
                environment=str(entry.get("environment") or "login.windows.net"),
            )
        )
    return out


def pick_best_refresh_token(
    records: list[RefreshTokenRecord],
    *,
    preferred_tenant: str | None = None,
) -> RefreshTokenRecord | None:
    """Choose the most relevant RT when the cache contains multiple accounts.

    Preference order:
      1. Match on ``preferred_tenant`` (exact tenant_id) when supplied.
      2. First record encountered (mirrors Kosmos behaviour — the first
         RT MSAL writes is the active session).
    """
    if not records:
        return None
    if preferred_tenant:
        for r in records:
            if r.tenant_id.lower() == preferred_tenant.lower():
                return r
    return records[0]


def to_local_storage_dict(state: dict[str, Any]) -> dict[str, str]:
    """Flatten a Playwright ``storage_state()`` result to a single-origin dict.

    Playwright returns ``{"origins": [{"origin": "...", "localStorage": [{"name": k, "value": v}, ...]}]}``.
    Our extractor wants ``{key: value}``. If multiple origins are present we
    merge them — the MSAL keys are unique enough that collision risk is nil.
    """
    out: dict[str, str] = {}
    for origin in state.get("origins", []) or []:
        for kv in origin.get("localStorage", []) or []:
            name = kv.get("name")
            value = kv.get("value")
            if isinstance(name, str) and isinstance(value, str):
                out[name] = value
    return out
