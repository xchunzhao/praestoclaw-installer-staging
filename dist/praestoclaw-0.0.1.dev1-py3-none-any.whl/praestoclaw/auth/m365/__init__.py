"""Microsoft 365 sign-in provider (DEPRECATED).

Provider implementing :class:`AuthProvider` by wrapping the Teams Web RT
extraction strategy (Playwright + cache + HTTP refresh). New code should
use :class:`AzureCliProvider` instead — m365 is kept for tenants whose
Conditional Access blocks ARM and Graph for non-FOCI clients.
"""

from praestoclaw.auth.m365.cache import M365AuthCache, cache_filename
from praestoclaw.auth.m365.extractor import (
    RefreshTokenRecord,
    extract_refresh_tokens,
    pick_best_refresh_token,
)
from praestoclaw.auth.m365.provider import M365_TARGET_SCOPE, M365Provider
from praestoclaw.auth.m365.strategy import M365AuthStrategy

__all__ = [
    "M365AuthCache",
    "M365AuthStrategy",
    "M365Provider",
    "M365_TARGET_SCOPE",
    "RefreshTokenRecord",
    "cache_filename",
    "extract_refresh_tokens",
    "pick_best_refresh_token",
]
