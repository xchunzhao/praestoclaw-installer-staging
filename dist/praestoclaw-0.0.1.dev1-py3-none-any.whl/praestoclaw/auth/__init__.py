"""Authentication providers for the cloud channel.

Four providers, mapping 1:1 to the user-facing sign-in menu:

  - :class:`AzureCliProvider` — reuse the user's ``az login`` session
  - :class:`M365Provider` — borrow Teams Web's MSAL refresh token (DEPRECATED)
  - :class:`OsAccountProvider` — MSAL WAM broker / OS account picker
  - :class:`BrowserProvider` — MSAL browser PKCE

Use :func:`build_auth_provider` to construct the configured one from a
``CloudChannelConfig``; or :func:`all_providers` for the runtime menu's
re-pick flow.
"""

from __future__ import annotations

from praestoclaw.auth.base import AuthProvider, AuthResult

__all__ = ["AuthProvider", "AuthResult"]
