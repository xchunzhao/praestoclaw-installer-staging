"""Factory for building :class:`AuthProvider` instances from config.

The single entry point :func:`build_auth_provider` is what runtime + CLI
should call to construct the configured provider; :func:`all_providers`
returns the full menu set for the runtime "re-pick" flow when silent
acquisition fails and the user wants to switch providers for one session.

For ``os_account`` and ``browser``, the provider needs access to the
:class:`CloudChannel`'s MSAL state (during this transitional refactor).
The factory accepts an optional *channel* argument; pass it when building
providers that will be installed into a CloudChannel.
"""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING, Any

from loguru import logger

from praestoclaw.auth.azure_cli import AzureCliProvider
from praestoclaw.auth.base import AuthProvider
from praestoclaw.auth.browser import BrowserProvider
from praestoclaw.auth.m365 import M365Provider
from praestoclaw.auth.os_account import OsAccountProvider

if TYPE_CHECKING:
    from praestoclaw.channels.cloud import CloudChannel


def _build_m365_strategy(cloud_cfg: Any) -> Any:
    """Construct the legacy M365AuthStrategy or return None when unavailable."""
    m365_cfg = getattr(cloud_cfg, "m365_auth", None)
    if m365_cfg is None or not getattr(m365_cfg, "enabled", True):
        return None

    try:
        from praestoclaw.auth.m365.strategy import M365AuthStrategy
        from praestoclaw.utils.helpers import get_auth_dir, get_data_dir
    except ImportError as exc:
        logger.warning("m365_auth imports failed; strategy disabled: {}", exc)
        return None

    cache_dir = get_auth_dir()
    profile_dir_str = getattr(m365_cfg, "profile_dir", "") or ""
    profile_dir = (
        Path(profile_dir_str).expanduser()
        if profile_dir_str
        else get_data_dir() / "teams-edge-profile"
    )
    return M365AuthStrategy(
        cache_dir=cache_dir,
        profile_dir=profile_dir,
        enabled=True,
        allow_browser_launch=getattr(m365_cfg, "allow_browser_launch", True),
        login_timeout_s=getattr(m365_cfg, "login_timeout_s", 120),
        preferred_tenant=getattr(cloud_cfg, "tenant_id", None) or None,
    )


def build_auth_provider(
    cloud_cfg: Any,
    *,
    channel: CloudChannel | None = None,
) -> AuthProvider:
    """Build the provider named by ``cloud_cfg.auth_provider``.

    *channel* is required for ``os_account`` and ``browser``; can be ``None``
    for ``azure_cli`` and ``m365``. Raises ``ValueError`` for unknown names.
    """
    name = getattr(cloud_cfg, "auth_provider", "azure_cli")

    if name == "azure_cli":
        az_cfg = getattr(cloud_cfg, "azure_cli", None)
        resource = getattr(az_cfg, "resource", None) or "https://management.azure.com"
        tenant_id = getattr(az_cfg, "tenant_id", None) or getattr(cloud_cfg, "tenant_id", None)
        return AzureCliProvider(resource=resource, tenant_id=tenant_id)

    if name == "m365":
        strategy = _build_m365_strategy(cloud_cfg)
        if strategy is None:
            raise ValueError(
                "auth_provider=m365 selected but m365_auth could not be initialized"
                " (Playwright unavailable, or m365_auth disabled in config)."
            )
        return M365Provider(strategy)

    if name == "os_account":
        if channel is None:
            raise ValueError("os_account provider requires a CloudChannel reference")
        return OsAccountProvider(channel)

    if name == "browser":
        if channel is None:
            raise ValueError("browser provider requires a CloudChannel reference")
        return BrowserProvider(channel)

    raise ValueError(f"unknown auth_provider: {name!r}")


def all_providers(
    cloud_cfg: Any,
    *,
    channel: CloudChannel | None = None,
) -> list[AuthProvider]:
    """Build every menu-visible provider — used by the runtime re-pick menu.

    Only Azure CLI is offered. ``M365``, ``OsAccount`` and ``Browser`` remain
    constructible via :func:`build_auth_provider` for back-compat with users
    who pinned ``auth_provider`` in yaml, but are no longer interactive
    choices. ``channel`` is accepted but unused.
    """
    del channel  # kept for API compatibility
    az_cfg = getattr(cloud_cfg, "azure_cli", None)
    return [
        AzureCliProvider(
            resource=getattr(az_cfg, "resource", None) or "https://management.azure.com",
            tenant_id=getattr(az_cfg, "tenant_id", None) or getattr(cloud_cfg, "tenant_id", None),
        )
    ]
