"""OS account picker (MSAL WAM broker) auth provider.

Implements :class:`AuthProvider` by delegating to MSAL's broker-enabled
PublicClientApplication. Silent path uses the broker cache file under
``~/.praestoclaw/auth/token_cache_<cid8>_broker.bin`` and refreshes via
PRT (scopes=["openid"]). Interactive path is the OS account picker
(WAM on Windows, ASWebAuthenticationSession on macOS).

For now we delegate the heavy MSAL plumbing to :class:`CloudChannel` —
the channel still owns ``_msal_app``, ``_browser_flow``, the shared-app
fallback chain, etc. The provider passes itself through to channel
methods. A follow-up cleanup step will fully invert this dependency once
the channel's MSAL state machine is well isolated.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, ClassVar

from loguru import logger

from praestoclaw.auth.base import AuthResult

if TYPE_CHECKING:
    from praestoclaw.channels.cloud import CloudChannel


class OsAccountProvider:
    name: ClassVar[str] = "os_account"
    display_label: ClassVar[str] = "OS account picker"
    supports_interactive: ClassVar[bool] = True

    def __init__(self, channel: CloudChannel) -> None:
        self._channel = channel

    def has_cached_credentials(self) -> bool:
        """True when a broker cache file exists with at least one account."""
        import msal

        from praestoclaw.auth.persist import encrypted_cache_path, load_msal_cache
        from praestoclaw.mcp.defaults import SHARED_ENTRA_CLIENT_ID

        for cid in (self._channel._client_id, SHARED_ENTRA_CLIENT_ID):
            path = encrypted_cache_path(cid, broker=True)
            if not path.exists():
                continue
            cache = load_msal_cache(path)
            try:
                app = msal.PublicClientApplication(cid, token_cache=cache)
                if app.get_accounts():
                    return True
            except Exception:  # noqa: S112 — best-effort cache check
                continue
        return False

    def try_silent(self) -> str | None:
        """Probe the broker cache for both primary + shared client IDs."""
        from praestoclaw.auth.persist import broker_kwargs, encrypted_cache_path
        from praestoclaw.mcp.defaults import SHARED_ENTRA_CLIENT_ID

        bkw = broker_kwargs()
        if not bkw:
            logger.warning("[os_account] MSAL broker not available on this platform")
            return None

        ch = self._channel
        client_ids = [ch._client_id]
        if not ch._using_shared_app:
            client_ids.append(SHARED_ENTRA_CLIENT_ID)

        for cid in client_ids:
            authority = (
                f"https://login.microsoftonline.com/{ch._tenant_id}"
                if cid == ch._client_id
                else "https://login.microsoftonline.com/organizations"
            )
            try:
                token = ch._try_silent_one(
                    cid,
                    authority,
                    bkw,
                    encrypted_cache_path(cid, broker=True),
                    scopes=["openid"],
                )
            except Exception as exc:  # noqa: BLE001 — defensive
                logger.debug("[os_account] silent probe failed: {}", exc)
                continue
            if token:
                if cid != ch._client_id:
                    ch._switch_to_shared_app(enable_broker=True)
                return token
        return None

    def interactive_login(self) -> AuthResult:
        """Run MSAL ``acquire_token_interactive`` with the broker enabled."""
        ch = self._channel
        # Force the channel into broker mode for this call. _browser_flow
        # honours `try_wam=True` which enables WAM/ASWebAuth and falls back
        # to plain browser PKCE when WAM errors out.
        token = ch._browser_flow(try_wam=True)
        return AuthResult(token=token, claims=ch._last_msal_claims())
