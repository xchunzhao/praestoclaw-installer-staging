"""Cloud-channel authentication provider protocol and shared types.

Each of the four built-in providers (azure_cli, m365, os_account, browser)
implements :class:`AuthProvider`. CloudChannel only ever talks to providers
through this protocol — it never touches MSAL, az, or Playwright details
directly.

The protocol is deliberately narrow:

- ``has_cached_credentials`` — fast no-network probe, runtime decides
  whether to auto-connect on startup.
- ``try_silent`` — synchronous "give me a token from cache, don't prompt".
- ``interactive_login`` — show UI, complete sign-in, return token + claims.

Providers that cannot perform interactive login from inside the daemon
(``azure_cli`` is the canonical example — re-login must happen via
``az login`` in the user's terminal) set ``supports_interactive = False``;
CloudChannel raises a clear error in that case rather than hanging on a
prompt the user never asked for.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, ClassVar, Protocol, runtime_checkable


@dataclass
class AuthResult:
    """Outcome of a successful authentication.

    ``token`` is the bearer string handed to the relay. ``claims`` carries
    decoded id_token / access_token claims (oid, name, preferred_username,
    tid, ...) so CloudChannel can populate its identity state without
    re-decoding the JWT itself.
    """

    token: str
    claims: dict[str, Any] = field(default_factory=dict)


@runtime_checkable
class AuthProvider(Protocol):
    """Interface every cloud auth provider implements.

    Class-level metadata (``name`` / ``display_label`` / ``supports_interactive``)
    is read by the menu and factory layers without instantiating the provider.
    """

    name: ClassVar[str]
    """Stable identifier persisted to ``channels.cloud.auth_provider``."""

    display_label: ClassVar[str]
    """Human-readable label shown in the runtime sign-in menu."""

    supports_interactive: ClassVar[bool]
    """Whether ``interactive_login`` can be invoked from a daemon process.

    False for providers whose interactive flow is owned by an external tool
    that needs the user's terminal directly — e.g. ``azure_cli`` defers to
    ``az login`` which the daemon cannot drive.
    """

    def has_cached_credentials(self) -> bool:
        """Return True when a cached session likely exists. No network calls."""

    def try_silent(self) -> str | None:
        """Acquire a token from cache without user interaction.

        Returns the access token on success or ``None`` on any failure.
        Must never raise — silent failure surfaces as ``None`` so the
        caller can decide whether to escalate to interactive.
        """

    def interactive_login(self) -> AuthResult:
        """Run the interactive sign-in flow.

        Raises ``RuntimeError`` when the user cancels / skips. Raises
        ``NotImplementedError`` when ``supports_interactive`` is False.
        """
