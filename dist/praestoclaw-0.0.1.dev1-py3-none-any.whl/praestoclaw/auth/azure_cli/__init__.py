"""Azure CLI auth provider package.

Public API re-exports the provider class plus the install/login helpers
that ``pc init`` and the menu callback need.
"""

from praestoclaw.auth.azure_cli.installer import (
    InstallPlan,
    detect_install_plan,
    install_az,
    is_az_installed,
)
from praestoclaw.auth.azure_cli.login import interactive_login, is_logged_in
from praestoclaw.auth.azure_cli.provider import (
    AzureCliError,
    AzureCliNotInstalled,
    AzureCliNotLoggedIn,
    AzureCliProvider,
)

__all__ = [
    "AzureCliError",
    "AzureCliNotInstalled",
    "AzureCliNotLoggedIn",
    "AzureCliProvider",
    "InstallPlan",
    "detect_install_plan",
    "install_az",
    "interactive_login",
    "is_az_installed",
    "is_logged_in",
]
