"""MSAL token cache encrypted on-disk storage + broker capability probe.

Helpers extracted from ``utils/auth.py`` and ``channels/cloud.py`` so the
MSAL-based providers (``OsAccountProvider``, ``BrowserProvider``) and the
cloud channel itself share one implementation. Pure I/O — no UI, no
config dependencies.

Cache layout under ``~/.praestoclaw/auth/``:

  token_cache_<cid8>.bin        — browser PKCE refresh-token cache
  token_cache_<cid8>_broker.bin — WAM broker cache (PRT-based)

Both files store an encrypted MSAL serialized cache (Fernet via
``security.secrets.encrypt_at_rest``). When the master key is unavailable
we refuse to overwrite an existing encrypted cache with plaintext.
"""

from __future__ import annotations

import sys
from pathlib import Path
from typing import Any

import msal
from loguru import logger


def encrypted_cache_path(client_id: str, *, broker: bool) -> Path:
    """Return the on-disk cache file for the given client_id + flavour."""
    from praestoclaw.utils.helpers import get_auth_dir

    suffix = "_broker" if broker else ""
    return get_auth_dir() / f"token_cache_{client_id[:8]}{suffix}.bin"


def load_msal_cache(cache_path: Path) -> msal.SerializableTokenCache:
    """Load an encrypted MSAL cache from disk. Returns empty cache on miss/error."""
    cache = msal.SerializableTokenCache()
    if not cache_path.exists():
        return cache

    try:
        from praestoclaw.security.secrets import decrypt_at_rest

        raw = decrypt_at_rest(cache_path.read_bytes())
        if raw:
            cache.deserialize(raw.decode("utf-8"))
    except Exception as exc:  # noqa: BLE001 — corrupt cache shouldn't crash auth
        logger.warning("Corrupted MSAL cache at {} ({}); starting fresh", cache_path, exc)
    return cache


def persist_msal_cache(cache: Any, cache_path: Path) -> None:
    """Write the cache to disk if it changed since load.

    Encrypts via ``security.secrets.encrypt_at_rest``. Refuses to overwrite
    an existing encrypted cache with plaintext when the master key is
    unavailable — silently no-op in that case so we don't downgrade
    storage security.
    """
    if not (hasattr(cache, "has_state_changed") and cache.has_state_changed):
        return

    from praestoclaw.security.secrets import (
        _atomic_write_file,
        encrypt_at_rest,
        is_encrypted,
    )

    plaintext = cache.serialize().encode("utf-8")
    data = encrypt_at_rest(plaintext)
    if data == plaintext and cache_path.exists():
        try:
            if is_encrypted(cache_path.read_bytes()):
                return
        except OSError:
            return

    cache_path.parent.mkdir(parents=True, exist_ok=True)
    _atomic_write_file(cache_path, data)


# ── Broker capability probe ──────────────────────────────────────────────────


_broker_cache: dict[str, Any] | None = None


def broker_kwargs() -> dict[str, Any]:
    """Return MSAL broker kwargs for the current platform, or empty dict.

    Probes ``pymsalruntime`` importability (required on all platforms) and
    maps to the platform-specific MSAL flag. Result is memoized after the
    first call so repeated probes are cheap.
    """
    global _broker_cache  # noqa: PLW0603
    if _broker_cache is not None:
        return _broker_cache

    try:
        import pymsalruntime  # noqa: F401
    except Exception:
        # ImportError (not installed), OSError (missing native lib),
        # RuntimeError (SSO extension unavailable on macOS CI), etc.
        _broker_cache = {}
        return _broker_cache

    if sys.platform == "win32":
        _broker_cache = {"enable_broker_on_windows": True}
    elif sys.platform == "darwin":
        _broker_cache = {"enable_broker_on_mac": True}
    elif sys.platform == "linux":
        _broker_cache = {"enable_broker_on_linux": True}
    else:
        _broker_cache = {}
    return _broker_cache


def reset_broker_cache_for_tests() -> None:
    """Clear the memoized broker probe — only for use in tests."""
    global _broker_cache  # noqa: PLW0603
    _broker_cache = None
