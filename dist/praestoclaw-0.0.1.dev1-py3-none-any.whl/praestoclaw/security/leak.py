"""Credential pattern detection -- scan text for common secret formats.

Covers JWT, AWS keys, GitHub PATs, OpenAI keys, Slack tokens,
Google API keys, Stripe keys, private key headers, Azure storage
connection strings, and high-entropy hex strings.

Used by HttpRequestTool for outbound scanning.
Hook pipeline integration in praestoclaw/hooks/handlers.py.
"""

from __future__ import annotations

import re

_CREDENTIAL_PATTERNS: list[tuple[str, re.Pattern[str]]] = [
    (
        "JWT",
        re.compile(r"eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}"),
    ),
    ("AWS Access Key", re.compile(r"AKIA[A-Z0-9]{16}")),
    (
        "AWS Secret Key",
        re.compile(r"""(?i)aws.{0,20}['"][0-9a-zA-Z/+]{40}['"]"""),
    ),
    (
        "GitHub PAT",
        re.compile(r"(ghp|gho|ghs|github_pat)_[A-Za-z0-9_]{36,}"),
    ),
    ("OpenAI Key", re.compile(r"sk-(proj-)?[A-Za-z0-9]{32,}")),
    ("Slack Token", re.compile(r"xox[baprs]-[0-9A-Za-z-]{10,}")),
    ("Google API Key", re.compile(r"AIza[0-9A-Za-z\-_]{35}")),
    (
        "Stripe Key",
        re.compile(r"(sk|pk)_(live|test)_[0-9a-zA-Z]{24,}"),
    ),
    (
        "Private Key",
        re.compile(r"-----BEGIN[A-Z ]*PRIVATE KEY-----[\s\S]*?-----END[A-Z ]*PRIVATE KEY-----"),
    ),
    (
        "Azure Storage",
        re.compile(r"DefaultEndpointsProtocol=https;[^\s]+"),
    ),
    (
        "High-Entropy Hex",
        re.compile(r"(?<![a-zA-Z0-9/])[0-9a-fA-F]{80,}(?![a-zA-Z0-9/])"),
    ),
]


def detect_credentials(text: str) -> list[tuple[str, str]]:
    """Scan *text* for credential patterns.

    Returns a list of ``(credential_type, preview)`` tuples where *preview*
    is at most 8 characters of the matched value followed by ``...``.
    """
    findings: list[tuple[str, str]] = []
    for cred_type, pattern in _CREDENTIAL_PATTERNS:
        for match in pattern.finditer(text):
            matched = match.group()
            preview = matched[:8] + "..." if len(matched) > 8 else matched
            findings.append((cred_type, preview))
    return findings


def redact_credentials(text: str) -> str:
    """Replace detected credentials with ``[REDACTED:{type}]``."""
    result = text
    for cred_type, pattern in _CREDENTIAL_PATTERNS:
        result = pattern.sub(f"[REDACTED:{cred_type}]", result)
    return result
