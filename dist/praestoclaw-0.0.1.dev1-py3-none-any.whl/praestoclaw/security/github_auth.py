"""
GitHub OAuth Device Code Flow — interactive sign-in for GitHub Copilot.

Uses the same client ID as VS Code / Copilot editor plugins so the
resulting token has access to the Copilot API.  Configurable via the
``GITHUB_OAUTH_CLIENT_ID`` environment variable.
"""

from __future__ import annotations

import os
import shutil
import subprocess
import time
from dataclasses import dataclass
from typing import Any
from urllib.parse import urlparse

import httpx
from loguru import logger
from rich.console import Console, Group
from rich.panel import Panel

# Well-known client ID used by VS Code GitHub Copilot / copilot.vim
DEFAULT_CLIENT_ID = "Iv1.b507a08c87ecfe98"

_DEVICE_CODE_URL = "https://github.com/login/device/code"
_TOKEN_URL = "https://github.com/login/oauth/access_token"
_SCOPE = "read:user repo"

_GRANT_TYPE = "urn:ietf:params:oauth:grant-type:device_code"


_COPILOT_TOKEN_PATH = "/copilot_internal/v2/token"
_COPILOT_TOKEN_URL = f"https://api.github.com{_COPILOT_TOKEN_PATH}"

# GitHub validates these headers — requests without them get 403.
# Values aligned with OpenClaw / pi-mono (vscode/1.107.0).
_COPILOT_HEADERS = {
    "Editor-Version": "vscode/1.107.0",
    "Editor-Plugin-Version": "copilot-chat/0.35.0",
    "User-Agent": "GitHubCopilotChat/0.35.0",
    "Copilot-Integration-Id": "vscode-chat",
    "Openai-Intent": "conversation-edits",
    "Accept": "application/json",
}


class GitHubAuthError(Exception):
    """Raised when GitHub device code authentication fails."""


@dataclass(frozen=True)
class ExistingGitHubToken:
    """GitHub token discovered from an existing local sign-in."""

    token: str
    source: str
    label: str


# ── Copilot token exchange ───────────────────────────────────────────────────


@dataclass(frozen=True)
class CopilotSessionToken:
    """Short-lived Copilot session token and its OpenAI-compatible API base."""

    token: str
    api_base: str
    expires_at: float


# Cached Copilot session tokens (short-lived, ~30 min), isolated by host and credential.
_CopilotCacheKey = tuple[str | None, str]
_copilot_sessions: dict[_CopilotCacheKey, CopilotSessionToken] = {}
_last_copilot_cache_key: _CopilotCacheKey | None = None


def _endpoint_host(value: str) -> str:
    """Return a lowercase host[:port] from a host or URL-like value."""
    parsed = urlparse(value if "://" in value else f"//{value}")
    host = parsed.netloc or parsed.path
    if "@" in host:
        host = host.rsplit("@", 1)[1]
    return host.split("/", 1)[0].strip().lower()


def _normalize_ghe_host(ghe_host: str | None) -> str | None:
    """Normalize an optional GitHub Enterprise host to a bare host[:port]."""
    if not ghe_host:
        return None

    host = _endpoint_host(str(ghe_host).strip())
    if not host:
        return None
    if host.startswith("api."):
        host = host.removeprefix("api.")
    return host


def _copilot_token_url(ghe_host: str | None = None) -> str:
    normalized_host = _normalize_ghe_host(ghe_host)
    if not normalized_host:
        return _COPILOT_TOKEN_URL
    return f"https://api.{normalized_host}{_COPILOT_TOKEN_PATH}"


def _api_base_from_token_response(data: dict[str, Any]) -> str:
    """Return the LLM API base URL advertised by the Copilot token API.

    The token exchange endpoint is tied to GitHub.com or a GHE host, but the
    OpenAI-compatible LLM endpoint is not. It must come from ``endpoints.api``
    in the token API response.
    """
    endpoints = data.get("endpoints")
    if not isinstance(endpoints, dict):
        raise GitHubAuthError("Copilot token response missing endpoints.api")

    api_base = endpoints.get("api")
    if not isinstance(api_base, str) or not api_base.strip():
        raise GitHubAuthError("Copilot token response missing endpoints.api")

    api_base = api_base.strip().rstrip("/")
    parsed = urlparse(api_base)
    if not parsed.scheme or not parsed.netloc:
        raise GitHubAuthError("Copilot token response endpoints.api must be an absolute URL")
    return api_base


def invalidate_copilot_token(
    ghe_host: str | None = None,
    *,
    github_token: str | None = None,
) -> None:
    """Clear cached Copilot session token entries.

    Call this after a 401 to force re-exchange on the next request.
    This handles the case where an external process (e.g. copilot-api)
    has invalidated the token by obtaining a newer one.
    """
    global _last_copilot_cache_key  # noqa: PLW0603

    normalized_host = _normalize_ghe_host(ghe_host)
    if ghe_host is None and github_token is None:
        _copilot_sessions.clear()
        _last_copilot_cache_key = None
    elif github_token is not None:
        _copilot_sessions.pop((normalized_host, github_token), None)
    else:
        for key in list(_copilot_sessions):
            if key[0] == normalized_host:
                _copilot_sessions.pop(key, None)

    if _last_copilot_cache_key not in _copilot_sessions:
        _last_copilot_cache_key = None
    if ghe_host is None and github_token is None:
        logger.debug("Copilot session token cache invalidated (all hosts)")
    else:
        logger.debug(
            "Copilot session token cache invalidated (host={})",
            normalized_host or "github.com",
        )


def get_copilot_session(
    github_token: str,
    ghe_host: str | None = None,
) -> CopilotSessionToken:
    """Exchange a GitHub OAuth token for a short-lived Copilot session.

    The result is cached in-memory until it expires (5-minute safety margin).
    """
    global _last_copilot_cache_key  # noqa: PLW0603

    normalized_host = _normalize_ghe_host(ghe_host)
    cache_key = (normalized_host, github_token)
    cached = _copilot_sessions.get(cache_key)
    if cached and time.time() < cached.expires_at - 300:
        _last_copilot_cache_key = cache_key
        return cached

    with httpx.Client(timeout=30) as http:
        resp = http.get(
            _copilot_token_url(normalized_host),
            headers={
                **_COPILOT_HEADERS,
                "Authorization": f"Bearer {github_token}",
            },
        )
        resp.raise_for_status()
        data = resp.json()

    token = data["token"]
    api_base = _api_base_from_token_response(data)

    # Normalise expires_at — may be seconds or milliseconds
    expires_at = data.get("expires_at", time.time() + 1800)
    if isinstance(expires_at, str):
        from datetime import datetime

        expires_at = datetime.fromisoformat(expires_at.replace("Z", "+00:00")).timestamp()
    elif isinstance(expires_at, (int, float)) and expires_at > 10_000_000_000:
        expires_at = expires_at / 1000  # milliseconds → seconds

    session = CopilotSessionToken(token=token, api_base=api_base, expires_at=float(expires_at))
    _copilot_sessions[cache_key] = session
    _last_copilot_cache_key = cache_key

    logger.debug(
        "Copilot session token acquired (host={}, base={}, expires in {}s)",
        normalized_host or "github.com",
        api_base,
        int(session.expires_at - time.time()),
    )
    return session


def get_copilot_token(github_token: str, ghe_host: str | None = None) -> str:
    """Exchange a GitHub OAuth token for a short-lived Copilot API token."""
    return get_copilot_session(github_token, ghe_host).token


def get_copilot_api_base(
    ghe_host: str | None = None,
    *,
    github_token: str | None = None,
) -> str:
    """Return the Copilot API base URL derived from a cached token exchange."""
    normalized_host = _normalize_ghe_host(ghe_host)

    if github_token is not None:
        cached = _copilot_sessions.get((normalized_host, github_token))
        if cached:
            return cached.api_base

    if _last_copilot_cache_key is not None:
        last_host = _last_copilot_cache_key[0]
        cached = _copilot_sessions.get(_last_copilot_cache_key)
        if cached and (ghe_host is None or last_host == normalized_host):
            return cached.api_base

    for (host, _token), cached in _copilot_sessions.items():
        if host == normalized_host:
            return cached.api_base

    raise GitHubAuthError(
        "No cached Copilot token response for API base; call get_copilot_session() first"
    )


def github_token_from_gh_cli(*, timeout: float = 5.0) -> str | None:
    """Best-effort token lookup from an existing GitHub CLI login."""
    if shutil.which("gh") is None:
        return None
    try:
        proc = subprocess.run(
            ["gh", "auth", "token", "--hostname", "github.com"],
            capture_output=True,
            text=True,
            timeout=timeout,
            check=False,
        )
    except (OSError, subprocess.TimeoutExpired) as exc:
        logger.debug("GitHub CLI token lookup unavailable ({})", exc)
        return None
    if proc.returncode != 0:
        return None
    token = proc.stdout.strip().splitlines()[0] if proc.stdout.strip() else ""
    return token or None


_GITHUB_TOKEN_PREFIXES = ("ghp_", "gho_", "ghu_", "ghs_", "ghr_", "github_pat_")


def _looks_like_github_token(value: str) -> bool:
    """Return True if ``value`` matches a known GitHub token prefix."""
    return any(value.startswith(prefix) for prefix in _GITHUB_TOKEN_PREFIXES)


def github_token_from_git_credential(*, timeout: float = 5.0) -> str | None:
    """Best-effort token lookup from Git Credential Manager without prompting."""
    if shutil.which("git") is None:
        return None
    try:
        proc = subprocess.run(
            ["git", "credential", "fill"],
            input="protocol=https\nhost=github.com\n\n",
            capture_output=True,
            env={
                **os.environ,
                "GIT_TERMINAL_PROMPT": "0",
                "GCM_INTERACTIVE": "Never",
            },
            text=True,
            timeout=timeout,
            check=False,
        )
    except (OSError, subprocess.TimeoutExpired) as exc:
        logger.debug("Git Credential Manager token lookup unavailable ({})", exc)
        return None

    if proc.returncode != 0:
        return None
    fields: dict[str, str] = {}
    for line in proc.stdout.splitlines():
        if "=" not in line:
            continue
        key, value = line.split("=", 1)
        fields[key] = value
    if fields.get("protocol") != "https" or fields.get("host") != "github.com":
        return None
    username = fields.get("username") or ""
    password = (fields.get("password") or "").strip()
    if not password:
        return None
    # Accept either the canonical GitHub Credential Manager pattern
    # (``username=x-access-token``, password is the OAuth token) or any
    # entry whose password matches a known GitHub PAT prefix \u2014 the
    # latter covers users who stored a PAT under their real GitHub
    # username via ``git config credential.helper`` directly. Anything
    # else (a basic-auth password, an Azure DevOps token, …) is rejected
    # so we never treat a stored login secret as a Copilot token.
    if username == "x-access-token" or _looks_like_github_token(password):
        return password
    return None


@dataclass(frozen=True)
class CredentialAcquisition:
    """Result of :func:`ensure_github_credential_cached`.

    ``ok``        — a usable github.com OAuth credential is available.
    ``persisted`` — we explicitly called ``git credential approve`` so the
                    credential is durably stored in the helper chain. False
                    when ``ok`` is False, or when we deliberately skipped
                    approve because the configured helper chain isn't in
                    the known-secure set (in which case downstream clones
                    may re-prompt).
    """

    ok: bool
    persisted: bool = False

    def __bool__(self) -> bool:
        return self.ok


def ensure_github_credential_cached(*, timeout: float = 180.0) -> CredentialAcquisition:
    """Make sure the system credential helper has a github.com credential.

    Runs ``git credential fill`` *with* terminal/UI prompts enabled, so
    that:

    * If the helper (e.g. Git Credential Manager) already has a cached
      credential, the call returns it immediately — no UI is shown.
    * If nothing is cached, the helper is allowed to interact with the
      user (GCM opens its browser sign-in window, ``manager-core``
      prompts, etc.) and the call blocks until the user finishes or
      ``timeout`` expires.

    This is the active counterpart to
    :func:`github_token_from_git_credential`, which deliberately disables
    prompts. Use this when you *want* to drive the user through a
    one-time sign-in (e.g. before cloning private/internal GitHub repos
    or scanning team ``.claude`` folders that need an OAuth token).

    ``timeout`` is a single end-to-end deadline shared across every
    subprocess this function may spawn (fill, helper-chain probe,
    approve). The total wall time will not exceed ``timeout`` plus a
    small constant for our own bookkeeping; individual sub-calls are
    capped at the remaining budget.

    Returns a :class:`CredentialAcquisition` that supports ``bool()``
    for easy ``if``-tests. ``persisted=False`` means we got a credential
    but did not write it through ``git credential approve`` (insecure
    helper chain, or approve failed); the caller can use this to
    soften UX wording about "cached for all future clones". Never
    raises — failures are non-fatal.
    """
    if shutil.which("git") is None:
        return CredentialAcquisition(ok=False)

    deadline = time.monotonic() + max(0.0, timeout)

    def _remaining() -> float:
        """Time left in the shared deadline. May be 0 or negative."""
        return deadline - time.monotonic()

    if _remaining() <= 0:
        return CredentialAcquisition(ok=False)

    try:
        proc = subprocess.run(
            ["git", "credential", "fill"],
            input="protocol=https\nhost=github.com\n\n",
            capture_output=True,
            text=True,
            timeout=_remaining(),
            check=False,
            # Intentionally inherit the parent environment as-is. We
            # specifically do NOT set ``GIT_TERMINAL_PROMPT=0`` or
            # ``GCM_INTERACTIVE=Never`` (cf.
            # ``github_token_from_git_credential``) so that the helper
            # can open its sign-in UI when no credential is cached.
        )
    except (OSError, subprocess.TimeoutExpired) as exc:
        logger.debug("Interactive GitHub credential acquisition failed ({})", exc)
        return CredentialAcquisition(ok=False)

    if proc.returncode != 0:
        return CredentialAcquisition(ok=False)
    fields: dict[str, str] = {}
    for line in proc.stdout.splitlines():
        if "=" not in line:
            continue
        key, value = line.split("=", 1)
        fields[key] = value
    if fields.get("protocol") != "https" or fields.get("host") != "github.com":
        return CredentialAcquisition(ok=False)
    # Apply the same token-shape check as ``github_token_from_git_credential``
    # so "credential cached" means the same thing in both directions: the
    # cached value is actually a GitHub OAuth token (browser sign-in always
    # mints one of these prefixes), not a stale basic-auth password that
    # downstream API/clone calls couldn't use anyway.
    username = fields.get("username") or ""
    password = (fields.get("password") or "").strip()
    if not password:
        return CredentialAcquisition(ok=False)
    if not (username == "x-access-token" or _looks_like_github_token(password)):
        return CredentialAcquisition(ok=False)

    # ``git credential fill`` is a read operation. Per the git credential
    # protocol the caller MUST follow up with ``git credential approve`` to
    # tell every configured helper "this credential worked, please remember
    # it". Without that, GCM may return the OAuth token from its in-memory
    # OAuth flow but never persist it, which means the very next ``git
    # clone`` (e.g. the marketplace background worker) would re-trigger
    # the browser sign-in even though the user just signed in.
    #
    # Gate the approve on ``_has_secure_git_credential_helper``: if the
    # configured helper chain includes ``store`` / ``cache`` / unknown
    # helpers, ``git credential approve`` would write the OAuth token to
    # plaintext. Same security policy as ``store_github_token_in_git_credential``.
    # On insecure chains we skip approve and accept that the user will be
    # re-prompted on each clone (their helper choice, not ours).
    persisted = False
    # Skip persistence work entirely when the deadline has been exhausted
    # by the fill stage \u2014 same end-to-end deadline as the caller asked
    # for, no follow-on subprocess after time runs out.
    if _remaining() <= 0:
        return CredentialAcquisition(ok=True, persisted=False)
    helper_secure = _has_secure_git_credential_helper(timeout=_remaining())
    if helper_secure and _remaining() > 0:
        approve_input = "".join(f"{k}={v}\n" for k, v in fields.items()) + "\n"
        try:
            approve_proc = subprocess.run(
                ["git", "credential", "approve"],
                input=approve_input,
                capture_output=True,
                text=True,
                timeout=_remaining(),
                check=False,
            )
            persisted = approve_proc.returncode == 0
        except (OSError, subprocess.TimeoutExpired) as exc:
            # Persistence is best-effort. If approve fails, the in-memory
            # credential just acquired still satisfied this call; the
            # caller treats us as "cached". Worst case the next git clone
            # re-prompts.
            logger.debug("git credential approve failed after fill ({})", exc)
    elif not helper_secure:
        logger.debug(
            "Skipping git credential approve: helper chain not in secure set; "
            "credential will not be persisted by us, downstream clones may re-prompt"
        )
    return CredentialAcquisition(ok=True, persisted=persisted)


# Helpers known to back credentials with an OS-level secure store. Only these
# are trusted to receive an OAuth token via ``git credential approve``.
# Plaintext helpers like ``store`` and ``cache`` are deliberately excluded so
# we don't bridge a Copilot-scope GitHub token into ``~/.git-credentials``.
_SECURE_GIT_CREDENTIAL_HELPERS = frozenset(
    {
        "manager",
        "manager-core",
        "osxkeychain",
        "wincred",
        "libsecret",
        "secretservice",
    }
)


def _normalize_git_credential_helper(value: str) -> str | None:
    """Reduce a ``credential.helper`` config value to its canonical short name.

    Returns the lowercased helper short name (e.g. ``manager-core``,
    ``osxkeychain``), or ``None`` for empty / shell (``!…``) helpers that
    we cannot classify safely.
    """
    from os.path import basename

    raw = value.strip()
    if not raw or raw.startswith("!"):
        return None
    # Take the first whitespace-separated token. We deliberately do NOT use
    # shlex here because shlex with ``posix=True`` mangles Windows paths
    # ("C:\\Program Files\\..." becomes "C:Program Files..."), and shlex
    # with ``posix=False`` mishandles Unix-quoted helper specs. The rare
    # path-with-spaces helper config is configured via Git's quoted form
    # but ``credential.helper`` rarely uses it; falling back to the first
    # whitespace token still catches the binary name when it does.
    head = raw.split(None, 1)[0]
    head = head.strip().strip('"').strip("'")
    # Handle Windows backslash paths.
    head = head.replace("\\", "/")
    name = basename(head).lower()
    if name.endswith(".exe"):
        name = name[:-4]
    if name.startswith("git-credential-"):
        name = name[len("git-credential-") :]
    return name or None


def _effective_git_credential_helpers(*, timeout: float) -> list[str] | None:
    """Return the effective ``credential.helper`` chain, or ``None`` on error.

    Returns an empty list when no helper is configured. An empty value in
    the multi-valued list resets the chain (Git's documented behaviour for
    ``credential.helper``), so we honour that here.
    """
    if shutil.which("git") is None:
        return None
    try:
        proc = subprocess.run(
            ["git", "config", "--get-all", "credential.helper"],
            capture_output=True,
            text=True,
            timeout=timeout,
            check=False,
        )
    except (OSError, subprocess.TimeoutExpired) as exc:
        logger.debug("Git credential helper lookup unavailable ({})", exc)
        return None
    if proc.returncode != 0:
        return []
    chain: list[str] = []
    for line in proc.stdout.splitlines():
        if not line.strip():
            chain.clear()
            continue
        chain.append(line)
    return chain


def _has_secure_git_credential_helper(*, timeout: float) -> bool:
    """Return True iff every effective credential helper is a secure helper.

    A mixed chain such as ``manager-core`` + ``store`` is rejected because
    ``git credential approve`` writes to every helper in the chain — leaving
    the OAuth token in plaintext in ``~/.git-credentials`` even though a
    secure helper is also present.
    """
    chain = _effective_git_credential_helpers(timeout=timeout)
    if not chain:
        return False
    for raw in chain:
        normalized = _normalize_git_credential_helper(raw)
        if normalized is None or normalized not in _SECURE_GIT_CREDENTIAL_HELPERS:
            logger.debug(
                "Skipping git credential bridge: unrecognized or insecure helper {!r}",
                raw,
            )
            return False
    return True


def store_github_token_in_git_credential(
    token: str,
    *,
    timeout: float = 5.0,
) -> bool:
    """Store a GitHub token through git-credential so GCM can reuse it.

    Only writes when **every** configured ``credential.helper`` is in a
    known-secure set (Git Credential Manager, macOS keychain, Windows
    credential store, Secret Service / libsecret). Plaintext helpers such
    as ``store`` or ``cache``, or unknown / shell-based helpers, cause
    this function to return ``False`` without touching the chain — even
    if a secure helper is also configured, because ``git credential
    approve`` would still write the token to the insecure helper.
    """
    token = token.strip()
    if not token or "\n" in token or "\r" in token:
        return False
    if not _has_secure_git_credential_helper(timeout=timeout):
        return False
    try:
        proc = subprocess.run(
            ["git", "credential", "approve"],
            input=(
                f"protocol=https\nhost=github.com\nusername=x-access-token\npassword={token}\n\n"
            ),
            capture_output=True,
            env={
                **os.environ,
                "GIT_TERMINAL_PROMPT": "0",
                "GCM_INTERACTIVE": "Never",
            },
            text=True,
            timeout=timeout,
            check=False,
        )
    except (OSError, subprocess.TimeoutExpired) as exc:
        logger.debug("Git credential store unavailable ({})", exc)
        return False
    if proc.returncode != 0:
        logger.debug("Git credential store failed with code {}", proc.returncode)
        return False
    return True


def discover_existing_github_token(*, timeout: float = 5.0) -> ExistingGitHubToken | None:
    """Return an existing local GitHub token, preferring non-interactive sources.

    This avoids opening the device-code flow when the user is already signed in
    via Git Credential Manager, environment, or GitHub CLI.  Credential Manager
    and general GitHub credentials are preferred over Copilot-only environment
    tokens because repo discovery needs GitHub API/repo access too.
    """
    credential_token = github_token_from_git_credential(timeout=timeout)
    if credential_token:
        return ExistingGitHubToken(
            token=credential_token,
            source="git-credential-manager",
            label="Git Credential Manager",
        )

    github_token = os.environ.get("GITHUB_TOKEN", "").strip()
    if github_token:
        return ExistingGitHubToken(
            token=github_token,
            source="env:GITHUB_TOKEN",
            label="$GITHUB_TOKEN",
        )

    gh_token = github_token_from_gh_cli(timeout=timeout)
    if gh_token:
        return ExistingGitHubToken(
            token=gh_token,
            source="gh",
            label="GitHub CLI",
        )

    env_sources = (("GITHUB_COPILOT_TOKEN", "env:GITHUB_COPILOT_TOKEN", "$GITHUB_COPILOT_TOKEN"),)
    for env_name, source, label in env_sources:
        token = os.environ.get(env_name, "").strip()
        if token:
            return ExistingGitHubToken(token=token, source=source, label=label)

    return None


def discover_existing_copilot_token() -> ExistingGitHubToken | None:
    """Return an existing token PraestoClaw is permitted to use for Copilot LLM calls.

    Distinct from :func:`discover_existing_github_token`, which is allowed to
    surface any github.com credential the user has on the box (GCM, ``gh``
    CLI, ``$GITHUB_TOKEN``). Those sources are fine for ``git clone`` /
    repo discovery but must **never** silently become the LLM token:

    * GCM stores whatever PAT/OAuth token the user happens to have for git
      push (``ghp_*`` PATs, ``gh auth login`` OAuth tokens with ``repo`` /
      ``read:org`` scopes, etc). None of those carry the Copilot scope, so
      adopting one as the Copilot token results in 401s on every LLM call
      with no clear root-cause for the user — and worse, transmits a token
      the user assigned to git push to the Copilot endpoint without
      explicit consent.
    * ``$GITHUB_TOKEN`` is ambiguous — the variable name carries no
      promise about scope or intended audience. Many CI pipelines set it
      as an Actions-issued token good only for the current workflow run.

    Only ``$GITHUB_COPILOT_TOKEN`` carries an explicit, unambiguous
    "this is for Copilot" signal from the user. Anything else must come
    from PraestoClaw's own device-flow (which is what the caller falls
    back to when this returns ``None``).
    """
    token = os.environ.get("GITHUB_COPILOT_TOKEN", "").strip()
    if token:
        return ExistingGitHubToken(
            token=token,
            source="env:GITHUB_COPILOT_TOKEN",
            label="$GITHUB_COPILOT_TOKEN",
        )
    return None


def github_device_login(
    client_id: str | None = None,
    console: Console | None = None,
    *,
    scope: str | None = None,
    interactive: bool = True,
) -> str:
    """Run the GitHub OAuth Device Code Flow and return an access token.

    Parameters
    ----------
    client_id:
        GitHub OAuth App client ID.  Defaults to the VS Code Copilot
        client ID, overridable via ``GITHUB_OAUTH_CLIENT_ID`` env var.
    console:
        Rich console for user-facing output.  A default is created if
        not provided.
    interactive:
        If ``True`` (default) and running in a real terminal, prompt
        the user to press Enter to open the browser while polling
        for authorization in the background.  If ``False`` or in a
        non-interactive environment (tests, piped stdin), falls back
        to a blocking poll without opening a browser.

    Returns
    -------
    str
        The OAuth access token.

    Raises
    ------
    GitHubAuthError
        If the flow fails, is denied, or times out.
    """
    if client_id is None:
        client_id = os.environ.get("GITHUB_OAUTH_CLIENT_ID", DEFAULT_CLIENT_ID)
    if console is None:
        console = Console()

    headers = {**_COPILOT_HEADERS}

    # Step 1 — request a device code
    with httpx.Client(timeout=30) as http:
        resp = http.post(
            _DEVICE_CODE_URL,
            data={"client_id": client_id, "scope": scope or _SCOPE},
            headers=headers,
        )
        resp.raise_for_status()
        data = resp.json()

    device_code: str = data.get("device_code", "")
    user_code: str = data.get("user_code", "")
    verification_uri: str = data.get("verification_uri", "https://github.com/login/device")
    expires_in: int = data.get("expires_in", 900)
    interval: int = data.get("interval", 5)

    if not device_code or not user_code:
        raise GitHubAuthError(f"Failed to initiate device code flow: {data}")

    # Step 2 — show the user code (highlighted panel — needs user action)
    console.print()
    console.print(
        Panel(
            Group(
                f"[bold]URL :[/bold]  [cyan]{verification_uri}[/cyan]",
                f"[bold]Code:[/bold]  [yellow bold]{user_code}[/yellow bold]",
                "[dim]Open URL \u2192 Login GitHub \u2192 Paste code \u2192 Authorize and come back[/dim]",
            ),
            border_style="cyan",
            padding=(1, 2),
        )
    )

    logger.debug("GitHub device code flow started (expires in {}s)", expires_in)

    # Step 3 — poll for the token
    # Interactive mode: Enter opens browser, background polling checks auth
    # Non-interactive (tests): blocking poll, no browser
    if interactive and _is_interactive():
        console.print()
        console.print("  Press [bold]Enter[/bold] to open browser\u2026")
        return _interactive_device_wait(
            console=console,
            client_id=client_id,
            device_code=device_code,
            interval=interval,
            expires_in=expires_in,
            verification_uri=verification_uri,
            headers=headers,
        )

    console.print()
    console.print("  [cyan]Waiting for authorization\u2026[/cyan]")
    return _blocking_device_poll(
        console=console,
        client_id=client_id,
        device_code=device_code,
        interval=interval,
        expires_in=expires_in,
        headers=headers,
    )


def _is_interactive() -> bool:
    """Return True if running in a real terminal."""
    import sys

    try:
        return sys.stdin.isatty() and sys.stdout.isatty()
    except Exception:
        return False


def _check_enter() -> bool:
    """Non-blocking check if Enter was pressed. Returns True if detected."""
    from praestoclaw.utils.input import read_key_nonblocking

    try:
        key = read_key_nonblocking()
        return key == "enter"
    except (KeyboardInterrupt, EOFError):
        return False


def _interactive_device_wait(
    *,
    console: Console,
    client_id: str,
    device_code: str,
    interval: int,
    expires_in: int,
    verification_uri: str,
    headers: dict[str, str],
) -> str:
    """Wait for device auth with Enter-to-open-browser and background polling."""
    import threading

    result: dict[str, str | None] = {"token": None, "error": None}
    done = threading.Event()

    def _poll() -> None:
        poll_interval = interval
        deadline = time.monotonic() + expires_in
        try:
            with httpx.Client(timeout=30) as http:
                while time.monotonic() < deadline and not done.is_set():
                    done.wait(poll_interval)
                    if done.is_set():
                        return
                    resp = http.post(
                        _TOKEN_URL,
                        data={
                            "client_id": client_id,
                            "device_code": device_code,
                            "grant_type": _GRANT_TYPE,
                        },
                        headers=headers,
                    )
                    resp.raise_for_status()
                    token_data = resp.json()
                    error = token_data.get("error")
                    if error is None:
                        result["token"] = token_data["access_token"]
                        done.set()
                        return
                    if error == "slow_down":
                        poll_interval = token_data.get("interval", poll_interval + 5)
                    elif error != "authorization_pending":
                        result["error"] = token_data.get("error_description", error)
                        done.set()
                        return
        except Exception as exc:
            result["error"] = str(exc)
            done.set()
            return
        # Expired
        if not done.is_set():
            result["error"] = "Device code expired \u2014 please try again"
            done.set()

    poll_thread = threading.Thread(target=_poll, daemon=True)
    poll_thread.start()

    browser_opened = False
    while not done.is_set():
        if _check_enter():
            if not browser_opened:
                import webbrowser

                webbrowser.open(verification_uri)
                browser_opened = True
                console.print(
                    "  [cyan]\u2713 Browser opened \u2014 waiting for authorization\u2026[/cyan]"
                )
            else:
                import webbrowser

                webbrowser.open(verification_uri)
                console.print("  [dim]Browser reopened\u2026[/dim]")
        done.wait(0.15)

    if result["token"]:
        logger.info("GitHub authentication successful")
        return result["token"]
    raise GitHubAuthError(f"GitHub auth failed: {result['error']}")


def _blocking_device_poll(
    *,
    console: Console,
    client_id: str,
    device_code: str,
    interval: int,
    expires_in: int,
    headers: dict[str, str],
) -> str:
    """Blocking poll for device auth (non-interactive / tests)."""
    deadline = time.monotonic() + expires_in

    with httpx.Client(timeout=30) as http:
        while time.monotonic() < deadline:
            time.sleep(interval)

            resp = http.post(
                _TOKEN_URL,
                data={
                    "client_id": client_id,
                    "device_code": device_code,
                    "grant_type": _GRANT_TYPE,
                },
                headers=headers,
            )
            resp.raise_for_status()
            token_data = resp.json()

            error = token_data.get("error")

            if error is None:
                access_token: str = token_data["access_token"]
                logger.info("GitHub authentication successful")
                return access_token

            if error == "authorization_pending":
                continue

            if error == "slow_down":
                interval = token_data.get("interval", interval + 5)
                continue

            description = token_data.get("error_description", error)
            raise GitHubAuthError(f"GitHub auth failed: {description}")

    raise GitHubAuthError("Device code expired \u2014 please try again")


# ── Pure functions for background-thread usage ───────────────────────────────


def github_request_device_code(
    client_id: str | None = None,
    scope: str | None = None,
) -> dict[str, str | int]:
    """Request a device code from GitHub. No terminal I/O.

    Returns dict with keys: device_code, user_code, verification_uri,
    expires_in, interval.
    Raises GitHubAuthError on failure.
    """
    if client_id is None:
        client_id = os.environ.get("GITHUB_OAUTH_CLIENT_ID", DEFAULT_CLIENT_ID)
    with httpx.Client(timeout=30) as http:
        resp = http.post(
            _DEVICE_CODE_URL,
            data={"client_id": client_id, "scope": scope or _SCOPE},
            headers={**_COPILOT_HEADERS},
        )
        resp.raise_for_status()
        data = resp.json()
    if not data.get("device_code") or not data.get("user_code"):
        raise GitHubAuthError(f"Failed to initiate device code flow: {data}")
    return {
        "device_code": data["device_code"],
        "user_code": data["user_code"],
        "verification_uri": data.get("verification_uri", "https://github.com/login/device"),
        "expires_in": data.get("expires_in", 900),
        "interval": data.get("interval", 5),
        "client_id": client_id,
    }


def github_poll_device_code(
    client_id: str,
    device_code: str,
    interval: int = 5,
    expires_in: int = 900,
    *,
    stop_event: Any = None,
) -> str:
    """Blocking poll for device code completion. No terminal I/O.

    Returns the access_token string.
    Raises GitHubAuthError on failure/expiry.
    If *stop_event* is provided and set, exits early with GitHubAuthError.
    """
    import threading as _threading

    _stop = stop_event or _threading.Event()
    deadline = time.monotonic() + expires_in
    poll_interval = interval
    with httpx.Client(timeout=30) as http:
        while time.monotonic() < deadline:
            _stop.wait(poll_interval)
            if _stop.is_set():
                raise GitHubAuthError("Polling stopped by caller")
            resp = http.post(
                _TOKEN_URL,
                data={
                    "client_id": client_id,
                    "device_code": device_code,
                    "grant_type": _GRANT_TYPE,
                },
                headers={**_COPILOT_HEADERS},
            )
            resp.raise_for_status()
            token_data = resp.json()
            error = token_data.get("error")
            if error is None:
                logger.info("GitHub authentication successful")
                return str(token_data["access_token"])
            if error == "slow_down":
                poll_interval = token_data.get("interval", poll_interval + 5)
            elif error != "authorization_pending":
                raise GitHubAuthError(
                    f"GitHub auth failed: {token_data.get('error_description', error)}"
                )
    raise GitHubAuthError("Device code expired")
