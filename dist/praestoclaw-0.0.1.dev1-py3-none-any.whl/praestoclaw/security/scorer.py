"""
Risk Scorer — fast LLM classifier for tool-call approval (v2).

Replaces the v1 SecurityClassifier.  Evaluates tool calls by assigning
an integer risk score 0-10 (or null).  The score feeds into the policy
table (security/risk.py) which maps score × profile → action.

Scoring flow (security-classification.md §7):
  1. User explicit risk_score override → RiskScore (skip LLM)
  2. Tool assess_risk(args) → RiskScore → done (skip LLM)
  3. Tool assess_risk(args) → RiskPrompt → LLM path
     MCP risk_prompt → LLM path
     MCP null → LLM path
     → cache check → LLM call → parse → cache → RiskScore

Design spec: docs/design/core/security-classification.md
"""

from __future__ import annotations

import asyncio
import hashlib
import json
import re
import time
from typing import TYPE_CHECKING, Any

from loguru import logger

from praestoclaw.config.schema import SecurityProfile
from praestoclaw.security.leak import redact_credentials
from praestoclaw.security.risk import RiskAssessment, RiskPrompt, RiskScore

if TYPE_CHECKING:
    from praestoclaw.agent.tools.base import Tool
    from praestoclaw.providers.base import LLMProvider

# ── Regex patterns for secret-like values ────────────────────────────────────

_SECRET_PATTERNS: list[re.Pattern[str]] = [
    re.compile(r"eyJ[A-Za-z0-9_-]{10,}"),  # JWT
    re.compile(r"ghp_[A-Za-z0-9]{36}"),  # GitHub PAT
    re.compile(r"sk-[A-Za-z0-9]{20,}"),  # OpenAI key
    re.compile(r"AKIA[A-Z0-9]{16}"),  # AWS access key
    re.compile(r"xox[bprs]-[A-Za-z0-9-]+"),  # Slack token
]

_SENSITIVE_ARG_KEYS = frozenset(
    {
        "password",
        "secret",
        "token",
        "api_key",
        "apikey",
        "auth",
        "authorization",
        "credentials",
        "private_key",
        "access_token",
        "refresh_token",
    }
)

# ── System prompts ───────────────────────────────────────────────────────────
# Generic prompt loaded from _SECURITY.md; tool-specific prompts override it.


def _load_system_prompt(name: str = "_SECURITY.md") -> str:
    """Load a security scorer system prompt by file name."""
    from importlib.resources import files as _pkg_files

    try:
        return _pkg_files("praestoclaw.defaults").joinpath(name).read_text(encoding="utf-8").strip()
    except Exception:
        if name != "_SECURITY.md":
            # Tool-specific prompt missing — fall back to generic
            return _load_system_prompt("_SECURITY.md")
        # Fallback — should never happen in a proper install
        return (
            "You are a security risk scorer for an AI agent's tool calls.\n"
            "Score the risk from 0 to 10 (integer only).\n"
            'Respond with JSON only: {"reason": "...", "score": <integer 0-10 or null>}'
        )


_SYSTEM_PROMPT = _load_system_prompt()

# Tool-specific system prompts — keyed by tool name.
# Falls back to _SYSTEM_PROMPT for unlisted tools.
_TOOL_PROMPTS: dict[str, str] = {
    "shell": _load_system_prompt("_SECURITY_SHELL.md"),
}

# Max characters for user intent context
_USER_INTENT_MAX_CHARS = 4000

# ── Profile-aware scoring stance ─────────────────────────────────────────────
# Injected into the user prompt so the LLM adjusts its confidence / caution
# level per profile.  System prompt sets the baseline; stance tunes it.

_PROFILE_STANCE: dict[str, str] = {
    "open": (
        "Scoring stance: always return a concrete integer score, never null. "
        "When uncertain, lean toward the lower end of the range."
    ),
    "standard": (
        "Scoring stance: prefer a concrete integer score over null. "
        "When uncertain, lean toward the higher end of the range."
    ),
    "controlled": (
        "Scoring stance: be conservative, lean toward the higher end. "
        "Null is acceptable only if the command is genuinely unassessable."
    ),
    "restricted": (
        "Scoring stance: be very conservative, lean toward the higher end. "
        "Return null if there is meaningful uncertainty about the command's safety."
    ),
}


# ── Scorer ───────────────────────────────────────────────────────────────────


class RiskScorer:
    """Fast LLM risk scorer for tool-call approval (v2).

    Parameters
    ----------
    provider:
        LLMProvider for calling the fast model.
    profile:
        Active security profile.
    risk_context:
        Optional environment-specific risk hints injected into LLM prompts.
    """

    CACHE_TTL = 300  # 5 minutes
    CACHE_MAX_SIZE = 1024
    TIMEOUT = 60.0  # seconds — agent-level hard cap

    def __init__(
        self,
        provider: LLMProvider,
        profile: str | SecurityProfile = "standard",
        risk_context: str | None = None,
    ) -> None:
        self._provider = provider
        self._profile = profile.value if isinstance(profile, SecurityProfile) else profile
        self._risk_context = risk_context or ""
        self._cache: dict[str, tuple[RiskScore, float]] = {}

    @property
    def profile(self) -> str:
        return self._profile

    @staticmethod
    def _compute_fallback(lo: int, hi: int) -> int | None:
        """Conservative fallback: assume worst case within the range.

        Returns ``hi`` (upper bound) so the policy table treats LLM failure
        as the highest-risk scenario the tool declared possible.
        If ``hi >= 8`` the risk is too high to auto-decide — return ``None``
        (null → human approval on all profiles).
        """
        if hi >= 8:
            return None
        return hi

    async def score(
        self,
        tool_name: str,
        args: dict[str, Any],
        *,
        tool_ref: Tool | None = None,
        user_risk_score_override: int | None = None,
        user_risk_reason: str = "",
        user_messages: list[str] | None = None,
    ) -> RiskScore:
        """Score a tool call following security-classification.md §7.

        Returns a RiskScore with an integer score (0-10) or None.
        """
        # ── 1. User explicit override (non-restricted) ───────────────
        if (
            user_risk_score_override is not None
            and self._profile != SecurityProfile.RESTRICTED.value
        ):
            logger.debug(
                "Risk score from user override: tool={} score={}",
                tool_name,
                user_risk_score_override,
            )
            return RiskScore(user_risk_score_override, user_risk_reason)

        # ── 2. Tool assess_risk() ────────────────────────────────────
        # For built-in tools: deterministic scoring based on args.
        # For MCP tools: 8-level config-driven resolution (see adapter.py).
        assessment: RiskAssessment | None = None
        if tool_ref is not None and hasattr(tool_ref, "assess_risk"):
            try:
                assessment = tool_ref.assess_risk(args)
            except Exception as exc:
                logger.warning("assess_risk() failed for {}: {}", tool_name, exc)
                # Fall through to LLM path
            if isinstance(assessment, RiskScore):
                logger.debug(
                    "Risk score from assess_risk(): tool={} score={}",
                    tool_name,
                    assessment.score,
                )
                return assessment

        # ── 3. LLM path ─────────────────────────────────────────────
        # Build tool context from RiskPrompt (assess_risk already includes
        # MCP description and scoring factors in the prompt text).
        # Redact credentials that may have leaked into prompt text from
        # raw args (URLs with tokens, shell commands with secrets, etc.)
        tool_context = assessment.prompt if isinstance(assessment, RiskPrompt) else ""
        if tool_context:
            tool_context = redact_credentials(tool_context)

        # Redact args (and exclude keys the tool declared irrelevant to scoring)
        exclude_keys = (
            assessment.exclude_args if isinstance(assessment, RiskPrompt) else frozenset()
        )
        filtered_args = {k: v for k, v in args.items() if k not in exclude_keys}
        redacted_args = _redact_args(filtered_args)

        # Check cache
        cache_key = self._cache_key(tool_name, redacted_args)
        cached = self._cache.get(cache_key)
        if cached and (time.monotonic() - cached[1]) < self.CACHE_TTL:
            logger.debug("Risk score from cache: tool={} score={}", tool_name, cached[0].score)
            return cached[0]

        # Build user prompt
        user_prompt = _build_user_prompt(
            tool_context=tool_context,
            risk_context=self._risk_context,
            redacted_args=redacted_args,
            user_messages=user_messages,
        )

        # Append profile-specific scoring stance
        stance = _PROFILE_STANCE.get(self._profile, "")
        if stance:
            user_prompt = f"{user_prompt}\n{stance}"

        # Call LLM
        try:
            result = await asyncio.wait_for(
                self._call_llm(user_prompt, tool_name), timeout=self.TIMEOUT
            )
        except Exception as exc:  # includes TimeoutError from asyncio.wait_for
            # Apply conservative fallback on LLM failure
            if isinstance(assessment, RiskPrompt):
                lo, hi = assessment.range
                fallback = self._compute_fallback(lo, hi)
                if fallback is not None:
                    logger.warning(
                        "Risk scorer error for {} ({}) → fallback={}",
                        tool_name,
                        exc,
                        fallback,
                    )
                    return RiskScore(
                        fallback,
                        f"Risk scorer unavailable ({type(exc).__name__}), fallback",
                    )
            logger.warning("Risk scorer timeout/error for {}: {}", tool_name, exc)
            return RiskScore(None, f"Risk scorer unavailable: {type(exc).__name__}")

        # Apply conservative fallback when LLM returns null
        if result.score is None and isinstance(assessment, RiskPrompt):
            lo, hi = assessment.range
            fallback = self._compute_fallback(lo, hi)
            if fallback is not None:
                logger.info(
                    "Risk scorer null → fallback={} for {}: {}",
                    fallback,
                    tool_name,
                    result.reason,
                )
                result = RiskScore(fallback, f"{result.reason} [fallback]")

        # Cache only successfully parsed results (score is not None).
        # Malformed responses (score=None) are not cached — allow retry.
        if result.score is not None:
            self._cache[cache_key] = (result, time.monotonic())
            if len(self._cache) > self.CACHE_MAX_SIZE:
                self._evict_expired()

        return result

    # ── LLM call ─────────────────────────────────────────────────────

    async def _call_llm(self, user_prompt: str, tool_name: str = "") -> RiskScore:
        """Send scoring prompt to the fast model and parse response."""
        system_prompt = _TOOL_PROMPTS.get(tool_name, _SYSTEM_PROMPT)
        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ]
        response = await self._provider.complete(
            model="fast",
            messages=messages,
        )
        if not response.content or not response.content.strip():
            logger.warning(
                "Risk scorer empty response: tool={} model={} finish_reason={} "
                "completion_tokens={} duration_ms={:.0f} has_reasoning={}",
                tool_name,
                response.model,
                response.finish_reason,
                response.completion_tokens,
                response.duration_ms,
                bool(response.reasoning_content),
            )
        return _parse_response(response.content)

    # ── Cache management ─────────────────────────────────────────────

    def _cache_key(
        self,
        tool_name: str,
        redacted_args: dict[str, Any],
    ) -> str:
        """SHA-256 cache key per security-classification.md §6."""
        risk_context_hash = hashlib.sha256(self._risk_context.encode()).hexdigest()
        payload = "\0".join(
            [
                tool_name,
                json.dumps(redacted_args, sort_keys=True, default=str),
                risk_context_hash,
                self._profile,
            ]
        )
        return hashlib.sha256(payload.encode()).hexdigest()

    def _evict_expired(self) -> None:
        """Remove expired entries, then oldest if still over max."""
        now = time.monotonic()
        expired = [k for k, (_, ts) in self._cache.items() if (now - ts) >= self.CACHE_TTL]
        for k in expired:
            del self._cache[k]
        if len(self._cache) > self.CACHE_MAX_SIZE:
            sorted_keys = sorted(self._cache, key=lambda k: self._cache[k][1])
            for k in sorted_keys[: len(self._cache) - self.CACHE_MAX_SIZE]:
                del self._cache[k]


# ── Prompt construction ──────────────────────────────────────────────────────


def _build_user_prompt(
    *,
    tool_context: str,
    risk_context: str,
    redacted_args: dict[str, Any],
    user_messages: list[str] | None,
) -> str:
    """Build user prompt per security-classification.md §5.3."""
    parts: list[str] = []

    if tool_context:
        parts.append(tool_context)
    if risk_context:
        parts.append(risk_context)

    parts.append(f"Arguments: {json.dumps(redacted_args, default=str)}")

    if user_messages:
        # Last 3 messages, oldest first, max 4K chars total
        intent_parts: list[str] = []
        total = 0
        for i, msg in enumerate(user_messages[-3:], 1):
            line = f"[{i}] {msg}"
            if total + len(line) > _USER_INTENT_MAX_CHARS:
                remaining = _USER_INTENT_MAX_CHARS - total
                if remaining > 0:
                    intent_parts.append(line[:remaining])
                break
            intent_parts.append(line)
            total += len(line)
        if intent_parts:
            parts.append("User intent:\n" + "\n".join(intent_parts))

    return "\n".join(parts)


# ── Response parsing ─────────────────────────────────────────────────────────


def _parse_response(content: str) -> RiskScore:
    """Parse ``{"reason": "...", "score": <int|null>}`` from LLM response.

    Per security-classification.md §5.6:
    - Valid int 0-10 → use
    - null → None
    - < 0 → None (unknown)
    - > 10 → clamp to 10
    - Invalid JSON → None
    """
    try:
        # Strip markdown code fences (```json ... ```) that LLMs commonly wrap around JSON
        stripped = content.strip()
        if stripped.startswith("```"):
            # Remove opening fence (```json or ```) and optional language tag
            if "\n" in stripped:
                stripped = stripped.split("\n", 1)[1]
            else:
                stripped = stripped[3:]
                # Remove leading language tag (e.g. "json")
                stripped = stripped.lstrip()
                if stripped.lower().startswith("json"):
                    stripped = stripped[4:].lstrip()
        if stripped.endswith("```"):
            stripped = stripped[:-3]
        stripped = stripped.strip()

        data = json.loads(stripped)
        reason = str(data.get("reason", ""))
        raw_score = data.get("score")

        if raw_score is None:
            return RiskScore(None, reason)

        score = int(raw_score)
        if score < 0:
            return RiskScore(None, reason)
        if score > 10:
            score = 10
        return RiskScore(score, reason)

    except (json.JSONDecodeError, TypeError, ValueError, AttributeError):
        return RiskScore(None, f"Malformed scorer response: {content!r}")


# ── Argument redaction ───────────────────────────────────────────────────────


def _redact_args(args: dict[str, Any]) -> dict[str, Any]:
    """Replace secret-like values with ``[REDACTED]``."""
    redacted: dict[str, Any] = {}
    for key, value in args.items():
        if key.lower() in _SENSITIVE_ARG_KEYS:
            redacted[key] = "[REDACTED]"
        elif isinstance(value, str) and _looks_like_secret(value):
            redacted[key] = "[REDACTED]"
        elif isinstance(value, dict):
            redacted[key] = _redact_args(value)
        elif isinstance(value, list):
            redacted[key] = _redact_list(value)
        else:
            redacted[key] = value
    return redacted


def _redact_list(items: list[Any]) -> list[Any]:
    """Recursively redact secrets inside a list."""
    result: list[Any] = []
    for item in items:
        if isinstance(item, str) and _looks_like_secret(item):
            result.append("[REDACTED]")
        elif isinstance(item, dict):
            result.append(_redact_args(item))
        elif isinstance(item, list):
            result.append(_redact_list(item))
        else:
            result.append(item)
    return result


def _looks_like_secret(value: str) -> bool:
    """Return True if value matches any known secret pattern."""
    return any(pat.search(value) for pat in _SECRET_PATTERNS)
