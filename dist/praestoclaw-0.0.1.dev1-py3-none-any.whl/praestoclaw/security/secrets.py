"""
Secret Store — unified protocol for local credential encryption & management.

Provides a pluggable backend system for storing secrets locally:
- **KeyringBackend**: OS-native credential store (Windows/macOS/Linux desktop)
- **FernetBackend**: AES-128-CBC + HMAC-SHA256 encrypted file (universal fallback)
- **EnvBackend**: read-only, reads from ``os.environ`` (CI/Docker)

The ``get_secret_store()`` factory auto-selects the best available backend.
``_try_get_fernet()`` is a standalone helper used internally for MSAL cache
encryption and the FernetBackend file store.
"""

from __future__ import annotations

import base64
import os
from abc import ABC, abstractmethod
from pathlib import Path
from typing import TYPE_CHECKING

from loguru import logger

from praestoclaw.utils.helpers import get_auth_dir

if TYPE_CHECKING:
    from cryptography.fernet import Fernet

    from praestoclaw.config.schema import AppConfig

# Master key keyring entry name.
_MASTER_KEY_KEYRING_NAME = "__master_key__"
_KEYRING_SERVICE = "praestoclaw"

# Known secret names for EnvBackend.list_names().
KNOWN_SECRET_NAMES: tuple[str, ...] = (
    "GITHUB_TOKEN",
    "GITHUB_COPILOT_TOKEN",
    "OPENAI_API_KEY",
    "AZURE_API_KEY",
    "AZURE_OPENAI_API_KEY",
    "AZURE_AI_FOUNDRY_API_KEY",
    "PRAESTOCLAW_API_KEY",
    "WEB_API_KEY",
)


class SecretStoreError(Exception):
    """Raised when a secret store operation fails."""


class SecretStore(ABC):
    """Abstract base for local credential storage backends."""

    @abstractmethod
    def get(self, name: str) -> str | None:
        """Retrieve a secret by name.  Returns ``None`` if not found."""

    @abstractmethod
    def set(self, name: str, value: str) -> None:
        """Store a secret.  Overwrites if it already exists."""

    @abstractmethod
    def delete(self, name: str) -> None:
        """Remove a secret.  No-op if it doesn't exist."""

    @abstractmethod
    def list_names(self) -> list[str]:
        """Return all stored secret names (never values)."""

    def exists(self, name: str) -> bool:
        """Check if a secret exists."""
        return self.get(name) is not None

    @abstractmethod
    def backend_info(self) -> str:
        """Human-readable description of the backend for diagnostics."""


# ---------------------------------------------------------------------------
# Standalone Fernet helper — used by config/loader.py before Runtime exists
# ---------------------------------------------------------------------------


_fernet_cache: Fernet | None = None
_fernet_cache_checked: bool = False


def _try_get_fernet() -> Fernet | None:
    """Try to obtain a Fernet instance using available master key sources.

    Result is cached after first successful lookup.  Does NOT require
    ``AppConfig`` or ``Runtime``.

    Returns ``None`` if no master key is available.
    """
    global _fernet_cache, _fernet_cache_checked  # noqa: PLW0603
    if _fernet_cache_checked:
        return _fernet_cache

    try:
        from cryptography.fernet import Fernet
    except ImportError:
        _fernet_cache_checked = True
        return None

    for source in (
        _try_master_key_from_keyring,
        _try_master_key_from_env,
        _try_master_key_from_file,
    ):
        key = source()
        if key:
            _fernet_cache = Fernet(key)
            _fernet_cache_checked = True
            return _fernet_cache

    _fernet_cache_checked = True
    return None


def _validate_fernet_key(value: str) -> bytes | None:
    """Validate and return a Fernet key, or ``None`` if invalid.

    A valid Fernet key is exactly 44 base64url characters that decode to 32 bytes.
    """
    if not isinstance(value, str) or len(value) != 44:
        return None
    try:
        raw = base64.urlsafe_b64decode(value)
        if len(raw) == 32:
            return value.encode()
    except Exception:
        pass
    return None


def _try_master_key_from_keyring() -> bytes | None:
    """Read the master key from OS keyring.  Returns None on any failure."""
    try:
        import keyring  # type: ignore[import]

        value = keyring.get_password(_KEYRING_SERVICE, _MASTER_KEY_KEYRING_NAME)
        if value:
            return _validate_fernet_key(value)
    except Exception:
        pass
    return None


def _try_master_key_from_env() -> bytes | None:
    """Read the master key from ``$PRAESTOCLAW_MASTER_KEY``."""
    value = os.environ.get("PRAESTOCLAW_MASTER_KEY")
    if not value:
        return None
    key = _validate_fernet_key(value)
    if key is None:
        logger.warning(
            "$PRAESTOCLAW_MASTER_KEY is not a valid Fernet key (expected 44-char base64url)"
        )
    return key


def _try_master_key_from_file() -> bytes | None:
    """Read the master key from ``~/.praestoclaw/auth/master.key``."""
    # Pure path computation — avoid get_auth_dir() which creates the directory.
    from praestoclaw.utils.helpers import get_data_dir

    path = get_data_dir() / "auth" / "master.key"
    if not path.is_file():
        return None
    try:
        value = path.read_text(encoding="utf-8").strip()
        key = _validate_fernet_key(value)
        if key is None:
            logger.warning(
                "Master key file {} does not contain a valid Fernet key (expected 44-char base64url)",
                path,
            )
        return key
    except Exception:
        logger.warning("Master key file {} is corrupted or unreadable", path)
    return None


def _init_master_key() -> bytes:
    """Initialize a new master key, storing it in the best available location.

    Tries (in order): keyring → env var (read-only) → key file.
    Returns the Fernet key bytes.
    """
    from cryptography.fernet import Fernet

    # Already have one?
    existing = (
        _try_master_key_from_keyring() or _try_master_key_from_env() or _try_master_key_from_file()
    )
    if existing:
        return existing

    # Lock to prevent concurrent key generation (two processes starting simultaneously)
    from contextlib import AbstractContextManager

    lock_path = get_auth_dir() / "master_key_init.lock"
    lock: AbstractContextManager  # type: ignore[type-arg]
    try:
        from filelock import FileLock

        lock = FileLock(lock_path, timeout=10)
    except ImportError:
        from contextlib import nullcontext

        lock = nullcontext()

    with lock:
        # Re-check after acquiring lock (another process may have created it)
        existing = (
            _try_master_key_from_keyring()
            or _try_master_key_from_env()
            or _try_master_key_from_file()
        )
        if existing:
            return existing

        new_key = Fernet.generate_key()

        # Clear negative cache so _try_get_fernet() picks up the new key
        global _fernet_cache, _fernet_cache_checked  # noqa: PLW0603
        _fernet_cache = None
        _fernet_cache_checked = False

        # Try keyring first
        if _keyring_available():
            try:
                import keyring  # type: ignore[import]

                keyring.set_password(_KEYRING_SERVICE, _MASTER_KEY_KEYRING_NAME, new_key.decode())
                logger.info("Master key stored in OS keyring")
                return new_key
            except Exception as exc:
                logger.debug("Could not store master key in keyring: {}", exc)

        # Fallback: key file
        key_path = lock_path.parent / "master.key"
        _atomic_write_file(key_path, new_key)
        logger.warning("Master key stored as plain file at {}. Protect this file.", key_path)
        return new_key


# ---------------------------------------------------------------------------
# Keyring availability probe
# ---------------------------------------------------------------------------


def _keyring_available() -> bool:
    """Check if OS keyring is usable (import + actual write/read/delete probe)."""
    try:
        import keyring  # type: ignore[import]
        from keyring.backends.fail import Keyring as FailKeyring

        backend = keyring.get_keyring()
        if isinstance(backend, FailKeyring):
            return False

        # ChainerBackend with no viable sub-backends is effectively FailKeyring
        try:
            from keyring.backends.chainer import ChainerBackend

            if isinstance(backend, ChainerBackend) and not backend.backends:
                return False
        except ImportError:
            pass

        # Probe with actual write/read/delete (UUID avoids collision with real secrets)
        import uuid

        probe_name = f"__probe_{uuid.uuid4().hex[:8]}__"
        keyring.set_password(_KEYRING_SERVICE, probe_name, "1")
        try:
            ok: bool = keyring.get_password(_KEYRING_SERVICE, probe_name) == "1"
            return ok
        finally:
            try:
                keyring.delete_password(_KEYRING_SERVICE, probe_name)
            except Exception:
                pass
    except Exception:
        return False


# ---------------------------------------------------------------------------
# Unified at-rest encryption — callers don't need to know about Fernet
# ---------------------------------------------------------------------------

# Versioned envelope: "WP1:" prefix → Fernet (AES-128-CBC + HMAC-SHA256).
# Future versions (WP2:, WP3:, ...) can use different algorithms.
_ENVELOPE_V1 = b"WP1:"


def is_encrypted(data: bytes) -> bool:
    """Check whether *data* is encrypted (versioned envelope)."""
    return data.startswith(_ENVELOPE_V1)


def _get_or_create_fernet() -> Fernet:
    """Return a Fernet instance, creating a master key if none exists."""
    from cryptography.fernet import Fernet as _Fernet

    fernet = _try_get_fernet()
    if fernet is None:
        key = _init_master_key()
        fernet = _Fernet(key)
    return fernet


def encrypt_at_rest(data: bytes, *, strict: bool = False) -> bytes:
    """Encrypt bytes for at-rest storage.

    With ``strict=False`` (default): returns original data if no key available.
    With ``strict=True``: creates a master key if needed — encryption is guaranteed.
    """
    if strict:
        f = _get_or_create_fernet()
        return _ENVELOPE_V1 + f.encrypt(data)
    fernet = _try_get_fernet()
    if fernet:
        return _ENVELOPE_V1 + fernet.encrypt(data)
    return data


def decrypt_at_rest(data: bytes) -> bytes:
    """Decrypt bytes from at-rest storage.  Auto-detects encrypted vs plaintext."""
    if data.startswith(_ENVELOPE_V1):
        fernet = _try_get_fernet()
        if fernet:
            try:
                return fernet.decrypt(data[len(_ENVELOPE_V1) :])
            except Exception:
                logger.warning("Failed to decrypt WP1 data — wrong master key or corrupted")
                return b""
        logger.warning("WP1 encrypted data found but no master key available")
        return b""

    return data  # plaintext


def encrypt_envelope(fernet: Fernet, data: bytes) -> bytes:
    """Encrypt *data* with an explicit Fernet instance and wrap in a WP1 envelope.

    Unlike ``encrypt_at_rest`` this accepts a caller-supplied Fernet key,
    which is needed for key rotation (encrypt with the *new* key).
    """
    return _ENVELOPE_V1 + fernet.encrypt(data)


# ---------------------------------------------------------------------------
# Windows ACL helper
# ---------------------------------------------------------------------------


def _set_windows_acl(path: Path) -> None:
    """Restrict file to current user + SYSTEM + Administrators via icacls."""
    import subprocess

    username = os.environ.get("USERNAME") or os.environ.get("USER", "")
    if not username:
        return
    domain = os.environ.get("USERDOMAIN", "")
    qualified = f"{domain}\\{username}" if domain and "\\" not in username else username
    try:
        subprocess.run(  # noqa: S603
            [
                "icacls",
                str(path),
                "/inheritance:r",
                "/grant:r",
                f"{qualified}:(F)",
                "/grant:r",
                "SYSTEM:(F)",
                "/grant:r",
                "BUILTIN\\Administrators:(F)",
            ],
            check=True,
            capture_output=True,
        )
    except Exception:
        pass  # Best-effort; parent dir ACL is the primary protection


# ---------------------------------------------------------------------------
# Atomic file write helper
# ---------------------------------------------------------------------------


def _atomic_write_file(path: Path, data: bytes | str) -> None:
    """Write data to *path* atomically via temp file + rename."""
    import stat
    import sys
    import tempfile

    if isinstance(data, str):
        data = data.encode("utf-8")

    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp_path = tempfile.mkstemp(dir=path.parent, prefix=".tmp_")
    try:
        f = os.fdopen(fd, "wb")
        fd = -1  # os.fdopen took ownership; f.close() will close the fd
        with f:
            f.write(data)
            f.flush()
            os.fsync(f.fileno())

        # Set restrictive permissions on temp file before rename
        tmp = Path(tmp_path)
        if sys.platform == "win32":
            _set_windows_acl(tmp)
        else:
            tmp.chmod(stat.S_IRUSR | stat.S_IWUSR)  # 0o600

        os.replace(tmp_path, path)
    except BaseException:
        if fd >= 0:
            os.close(fd)
        try:
            os.unlink(tmp_path)
        except OSError:
            pass
        raise


# ---------------------------------------------------------------------------
# Factory
# ---------------------------------------------------------------------------

# Module-level singleton cache.
_store_instance: SecretStore | None = None


def get_secret_store(
    config: AppConfig | None = None,
    *,
    backend_hint: str | None = None,
) -> SecretStore:
    """Return the singleton ``SecretStore``.

    Auto-selects the best backend when ``secret_backend`` is ``"auto"``.
    ``backend_hint`` allows ``load_config()`` to pass the raw config value
    before ``AppConfig`` is constructed.
    """
    global _store_instance  # noqa: PLW0603

    if _store_instance is not None:
        return _store_instance

    backend = backend_hint or "auto"
    if config:
        backend = getattr(config.security, "secret_backend", backend)

    # Env var override
    backend = os.environ.get("PRAESTOCLAW_SECRET_BACKEND", backend)

    if backend == "keyring":
        from praestoclaw.security.secrets_keyring import KeyringBackend

        _store_instance = KeyringBackend()
    elif backend == "fernet":
        from praestoclaw.security.secrets_fernet import FernetBackend

        _store_instance = FernetBackend()
    elif backend == "env":
        from praestoclaw.security.secrets_env import EnvBackend

        _store_instance = EnvBackend()
    elif backend == "auto":
        if _keyring_available():
            from praestoclaw.security.secrets_keyring import KeyringBackend

            _store_instance = KeyringBackend()
            logger.debug("Secret store: auto-selected KeyringBackend")
        else:
            from praestoclaw.security.secrets_fernet import FernetBackend

            _store_instance = FernetBackend()
            logger.debug("Secret store: auto-selected FernetBackend")
    else:
        raise SecretStoreError(f"Unknown secret_backend: {backend!r}")

    return _store_instance


def reset_secret_store() -> None:
    """Reset the singleton and fernet cache — for testing only."""
    global _store_instance, _fernet_cache, _fernet_cache_checked  # noqa: PLW0603
    _store_instance = None
    _fernet_cache = None
    _fernet_cache_checked = False


# ---------------------------------------------------------------------------
# Convenience API — callers don't need to touch get_secret_store() directly
# ---------------------------------------------------------------------------


def get_secret(name: str) -> str | None:
    """Read a secret by name.  Shorthand for ``get_secret_store().get(name)``."""
    return get_secret_store().get(name)


def set_secret(name: str, value: str) -> None:
    """Write a secret.  Shorthand for ``get_secret_store().set(name, value)``."""
    get_secret_store().set(name, value)
