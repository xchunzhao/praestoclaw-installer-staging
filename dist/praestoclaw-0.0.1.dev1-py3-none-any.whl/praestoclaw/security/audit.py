"""
Enterprise audit logger — records all significant actions for compliance.

Every tool execution, channel message, and auth event is logged with
correlation IDs and automatic secret redaction. Writes to a daily-rotated
JSONL file under ~/.praestoclaw/audit/ (or a configured path).
"""

from __future__ import annotations

import json
import re
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from loguru import logger

from praestoclaw.config.schema import AuditConfig

_REDACT_KEYS = frozenset(
    {
        "password",
        "secret",
        "token",
        "key",
        "credential",
        "authorization",
        "apikey",
        "api_key",
        "pat",
        "api_secret",
        "client_secret",
        "app_password",
        "webhook_secret",
    }
)

_SECRET_PATTERNS = [
    re.compile(r"(eyJ[A-Za-z0-9_-]{10,}\.){1,2}[A-Za-z0-9_-]{10,}"),  # JWT
    re.compile(r"AKIA[0-9A-Z]{16}"),  # AWS
    re.compile(r"gh[pousr]_[A-Za-z0-9_]{36,}"),  # GitHub PAT/OAuth/user tokens
    re.compile(r"xox[bpors]-[A-Za-z0-9-]+"),  # Slack
    re.compile(r"sk-[A-Za-z0-9]{20,}"),  # OpenAI-style
]


def _redact_dict(obj: dict[str, Any]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for k, v in obj.items():
        if k.lower() in _REDACT_KEYS:
            result[k] = "[REDACTED]"
        elif isinstance(v, dict):
            result[k] = _redact_dict(v)
        elif isinstance(v, str):
            result[k] = _redact_string(v)
        else:
            result[k] = v
    return result


def _redact_string(value: str) -> str:
    for pattern in _SECRET_PATTERNS:
        value = pattern.sub("[REDACTED]", value)
    return value


class AuditLogger:
    """Structured audit logger with secret redaction and daily rotation.

    Writes to ``<dir>/<stem>-YYYY-MM-DD<suffix>`` (e.g. audit-2026-03-12.jsonl).
    A new file is created automatically each day — no external rotation needed.
    If the file cannot be written a WARNING is emitted on each failed attempt.
    """

    def __init__(self, config: AuditConfig | None = None) -> None:
        self._enabled = config.enabled if config else False
        self._redact = config.redact_secrets if config else True

        base = Path(
            config.log_file if config and config.log_file else "~/.praestoclaw/audit/audit.jsonl"
        ).expanduser()
        self._audit_dir = base.parent
        self._stem = base.stem
        self._suffix = base.suffix or ".jsonl"

        try:
            self._audit_dir.mkdir(parents=True, exist_ok=True)
        except OSError as exc:
            logger.warning(f"Audit log directory unavailable ({self._audit_dir}): {exc}")

    def _daily_file(self) -> Path:
        date = datetime.now(UTC).strftime("%Y-%m-%d")
        return self._audit_dir / f"{self._stem}-{date}{self._suffix}"

    def _write(self, event: str, fields: dict[str, Any]) -> None:
        """Write a single audit entry. Adds timestamp, strips None values."""
        if not self._enabled:
            return
        entry: dict[str, Any] = {
            "ts": datetime.now(UTC).isoformat(),
            "event": event,
            **{k: v for k, v in fields.items() if v is not None},
        }
        if self._redact:
            entry = _redact_dict(entry)
        line = json.dumps(entry, default=str, ensure_ascii=False)
        path = self._daily_file()
        try:
            with path.open("a", encoding="utf-8") as f:
                f.write(line + "\n")
        except OSError as exc:
            logger.warning(f"Audit log write failed ({path}): {exc}")

    def log_tool(
        self,
        *,
        tool: str,
        actor: str,
        args: dict[str, Any],
        result: str,
        is_error: bool = False,
        session_id: str | None = None,
        duration_ms: float | None = None,
        tool_call_id: str | None = None,
    ) -> None:
        self._write(
            "tool:execute",
            {
                "tool": tool,
                "actor": actor,
                "args": args,
                "result_preview": (result or "")[:200],
                "is_error": is_error,
                "session_id": session_id,
                "duration_ms": duration_ms,
                "tool_call_id": tool_call_id,
            },
        )

    def log_message(
        self,
        *,
        channel: str,
        direction: str,
        actor: str,
        session_id: str | None = None,
    ) -> None:
        self._write(
            f"channel:{direction}",
            {
                "channel": channel,
                "actor": actor,
                "session_id": session_id,
            },
        )

    def log_auth(
        self,
        *,
        provider: str,
        actor: str,
        result: str,
    ) -> None:
        self._write(
            "auth:attempt",
            {
                "provider": provider,
                "actor": actor,
                "result": result,
            },
        )

    def log_security(
        self,
        *,
        event: str,
        details: dict[str, Any],
        severity: str = "warning",
    ) -> None:
        self._write(
            f"security:{event}",
            {
                "severity": severity,
                **details,
            },
        )

    def log_event(self, *, action: str, data: dict[str, Any]) -> None:
        """Log a generic workflow/lifecycle event."""
        self._write(action, data)

    def recent_entries(self, limit: int = 200) -> list[dict[str, Any]]:
        """Read the most recent *limit* audit entries across daily files."""
        import json
        from collections import deque

        entries: list[dict[str, Any]] = []
        if not self._audit_dir.is_dir():
            return entries

        # Daily files sorted newest first
        pattern = f"{self._stem}-*{self._suffix}"
        files = sorted(self._audit_dir.glob(pattern), reverse=True)

        remaining = limit
        for f in files:
            if remaining <= 0:
                break
            try:
                with open(f, encoding="utf-8") as fh:
                    tail = deque(fh, maxlen=remaining)
                for line in reversed(tail):
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        entries.append(json.loads(line))
                        remaining -= 1
                    except json.JSONDecodeError:
                        continue
            except Exception:  # noqa: BLE001, S112
                continue
        return entries
