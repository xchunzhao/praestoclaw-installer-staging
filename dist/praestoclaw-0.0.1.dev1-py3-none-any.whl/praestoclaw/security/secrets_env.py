"""
EnvBackend — read-only secret store backed by ``os.environ``.

Used in CI/Docker environments where secrets are injected as environment
variables by the orchestrator (GitHub Actions, Azure DevOps, Docker ``--env``).
"""

from __future__ import annotations

import os

from praestoclaw.security.secrets import KNOWN_SECRET_NAMES, SecretStore, SecretStoreError


class EnvBackend(SecretStore):
    """Read-only backend — reads secrets from environment variables."""

    def get(self, name: str) -> str | None:
        return os.environ.get(name) or None

    def set(self, name: str, value: str) -> None:
        raise SecretStoreError("EnvBackend is read-only. Export the variable directly.")

    def delete(self, name: str) -> None:
        raise SecretStoreError("EnvBackend is read-only.")

    def list_names(self) -> list[str]:
        return [k for k in KNOWN_SECRET_NAMES if k in os.environ]

    def backend_info(self) -> str:
        count = len(self.list_names())
        return f"EnvBackend (read-only, {count} known secrets in environment)"
