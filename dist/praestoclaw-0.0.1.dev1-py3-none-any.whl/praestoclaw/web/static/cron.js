'use strict';
// PraestoClaw Portal — Cron tab. All UI strings English-only (UX-06, lang="en").
// Single-file module loaded after portal.js. Server is the single source of truth
// for schedule validation, human translation, next runs, and unified status.

(function () {
  // ── Style block (scoped with .cron- prefix) ────────────────────────
  if (!document.getElementById('cron-styles')) {
    const css = `
.cron-page { padding: 0 4px; }
.cron-hd-row { display: flex; align-items: center; gap: 12px; margin-bottom: 14px; }
.cron-hd-row .spacer { flex: 1; }
.cron-card { background: var(--bg2); border: 1px solid var(--border); border-radius: var(--radius); padding: 16px; margin-bottom: 14px; transition: background .2s, border-color .2s; }
.cron-card-t { font-size: 11px; font-family: var(--mono); font-weight: 500; color: var(--fg2); text-transform: uppercase; letter-spacing: .08em; margin-bottom: 10px; }
.cron-presets { display: flex; flex-wrap: wrap; gap: 6px; margin-bottom: 10px; }
.cron-chip { background: var(--accent-dim); color: var(--accent); border: 1px solid transparent; border-radius: var(--radius-badge); padding: 4px 12px; font-size: 12px; cursor: pointer; transition: filter .15s; }
.cron-chip:hover { filter: brightness(1.15); }
.cron-input-row { display: flex; align-items: stretch; gap: 8px; margin-bottom: 8px; }
.cron-input { flex: 1; background: var(--bg3); color: var(--fg-bright); border: 1px solid var(--border); border-radius: var(--radius-sm); padding: 8px 10px; font-family: var(--mono); font-size: 13px; transition: border-color .15s; }
.cron-input:focus { outline: none; border-color: var(--accent); }
.cron-input.invalid { border-color: var(--red); }
.cron-type-badge { background: var(--bg3); color: var(--fg2); border: 1px solid var(--border); border-radius: var(--radius-sm); padding: 6px 10px; font-size: 11px; font-family: var(--mono); align-self: center; min-width: 60px; text-align: center; }
.cron-preview { background: var(--bg3); border-radius: var(--radius-sm); padding: 10px 12px; min-height: 70px; }
.cron-preview-h { font-size: 14px; color: var(--fg-bright); margin-bottom: 6px; min-height: 1.4em; }
.cron-preview-runs { font-size: 12px; color: var(--fg2); }
.cron-preview-runs ul { list-style: none; margin-top: 4px; }
.cron-preview-runs li { padding: 2px 0; font-family: var(--mono); }
.cron-preview-runs .rel { color: var(--fg); margin-left: 8px; }
.cron-preview-err { color: var(--red); font-size: 13px; }
.cron-tw { background: var(--bg2); border: 1px solid var(--border); border-radius: var(--radius); overflow: hidden; }
.cron-tw table { width: 100%; border-collapse: collapse; font-size: 13px; }
.cron-tw th { text-align: left; padding: 10px 14px; font-size: 11px; font-family: var(--mono); font-weight: 500; color: var(--fg2); text-transform: uppercase; letter-spacing: .06em; background: var(--bg3); border-bottom: 1px solid var(--border); }
.cron-tw td { padding: 10px 14px; border-bottom: 1px solid var(--border); color: var(--fg); vertical-align: middle; }
.cron-tw tr:last-child td { border-bottom: none; }
.cron-tw .name { color: var(--fg-bright); font-weight: 500; }
.cron-tw .desc { color: var(--fg2); max-width: 220px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.cron-tw .sched { font-family: var(--mono); font-size: 12px; }
.cron-dot { display: inline-block; width: 8px; height: 8px; border-radius: 50%; margin-right: 6px; vertical-align: middle; }
.cron-dot-success { background: var(--green); }
.cron-dot-error { background: var(--red); }
.cron-dot-never { background: var(--fg2); }
.cron-badge { display: inline-block; padding: 3px 9px; border-radius: var(--radius-badge); font-size: 11px; font-weight: 500; }
.cron-badge.disabled { background: var(--bg3); color: var(--fg2); }
.cron-badge.running  { background: var(--blue-dim); color: var(--blue); animation: cron-pulse 1.4s ease-in-out infinite; }
.cron-badge.error    { background: var(--red-dim); color: var(--red); }
.cron-badge.idle     { background: var(--green-dim); color: var(--green); }
@keyframes cron-pulse { 0%,100% { opacity: 1; } 50% { opacity: .55; } }
.cron-actions { display: flex; gap: 6px; }
.cron-actions button { background: transparent; border: 1px solid var(--border); color: var(--fg); border-radius: var(--radius-sm); padding: 4px 10px; font-size: 11px; cursor: pointer; transition: border-color .15s, color .15s; }
.cron-actions button:hover { border-color: var(--border-hover); color: var(--fg-bright); }
.cron-actions button.danger { color: var(--red); border-color: rgba(248,81,73,.18); }
.cron-actions button.danger:hover { background: rgba(248,81,73,.10); }
.cron-actions button.run { color: var(--accent); border-color: var(--accent-dim); }
.cron-toggle { position: relative; display: inline-block; width: 34px; height: 18px; cursor: pointer; }
.cron-toggle input { opacity: 0; width: 0; height: 0; }
.cron-toggle .slider { position: absolute; inset: 0; background: var(--bg3); border: 1px solid var(--border); border-radius: 999px; transition: background .2s; }
.cron-toggle .slider::before { content: ''; position: absolute; left: 2px; top: 1px; width: 12px; height: 12px; background: var(--fg2); border-radius: 50%; transition: transform .2s, background .2s; }
.cron-toggle input:checked + .slider { background: var(--accent-dim); border-color: var(--accent); }
.cron-toggle input:checked + .slider::before { transform: translateX(16px); background: var(--accent); }
.cron-modal-bg { position: fixed; inset: 0; background: rgba(0,0,0,.5); display: flex; align-items: center; justify-content: center; z-index: 200; }
.cron-modal { background: var(--bg2); border: 1px solid var(--border); border-radius: var(--radius); width: min(640px, 92vw); max-height: 88vh; overflow-y: auto; padding: 18px 22px; }
.cron-modal h2 { font-size: 16px; color: var(--fg-bright); margin-bottom: 14px; }
.cron-modal label { display: block; font-size: 11px; font-family: var(--mono); color: var(--fg2); text-transform: uppercase; letter-spacing: .06em; margin: 12px 0 5px; }
.cron-modal input[type=text], .cron-modal textarea { width: 100%; background: var(--bg3); color: var(--fg-bright); border: 1px solid var(--border); border-radius: var(--radius-sm); padding: 8px 10px; font-family: var(--font); font-size: 13px; }
.cron-modal textarea { font-family: var(--mono); resize: vertical; min-height: 80px; }
.cron-modal input:disabled { color: var(--fg2); cursor: not-allowed; }
.cron-modal-err { background: var(--red-dim); color: var(--red); border-radius: var(--radius-sm); padding: 8px 12px; margin: 10px 0; font-size: 13px; }
.cron-modal-foot { display: flex; gap: 8px; margin-top: 16px; justify-content: flex-end; }
.cron-modal-foot button { background: transparent; color: var(--fg); border: 1px solid var(--border); border-radius: var(--radius-sm); padding: 8px 18px; font-size: 13px; cursor: pointer; }
.cron-modal-foot button.primary { background: var(--accent); color: #fff; border-color: var(--accent); }
.cron-modal-foot button.primary:disabled { opacity: .5; cursor: not-allowed; }
.cron-modal-foot button.primary:not(:disabled):hover { filter: brightness(1.1); }
.cron-confirm-modal { width: min(420px, 90vw); }
.cron-confirm-body { font-size: 14px; color: var(--fg); padding: 4px 0 8px; }
.cron-confirm-body code { font-family: var(--mono); background: var(--bg3); color: var(--fg-bright); padding: 1px 6px; border-radius: var(--radius-sm); }
.cron-modal-foot button.primary.danger-primary { background: var(--red); border-color: var(--red); }
.cron-toast { position: fixed; top: 16px; right: 16px; background: var(--bg2); border: 1px solid var(--border); border-radius: var(--radius-sm); padding: 10px 14px; font-size: 13px; color: var(--fg-bright); box-shadow: var(--shadow-lift); z-index: 300; }
.cron-toast.error { border-color: var(--red); color: var(--red); }
.cron-readonly-hint { font-size: 11px; color: var(--fg2); margin-top: 4px; }
.cron-empty { padding: 40px; text-align: center; color: var(--fg2); }
.cron-preset-modal { width: min(760px, 94vw); }
.cron-preset-sub { font-size: 12px; color: var(--fg2); margin: -6px 0 14px; }
.cron-preset-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(220px, 1fr)); gap: 10px; }
.cron-preset-card { background: var(--bg3); border: 1px solid var(--border); border-radius: var(--radius-sm); padding: 12px 14px; cursor: pointer; display: flex; gap: 10px; align-items: flex-start; transition: border-color .15s, background .15s, transform .1s; }
.cron-preset-card:hover { border-color: var(--accent); background: var(--accent-dim); }
.cron-preset-card:active { transform: translateY(1px); }
.cron-preset-icon { font-size: 22px; line-height: 1; flex-shrink: 0; margin-top: 1px; }
.cron-preset-body { min-width: 0; flex: 1; }
.cron-preset-name { font-size: 13px; color: var(--fg-bright); font-weight: 500; margin-bottom: 3px; }
.cron-preset-desc { font-size: 12px; color: var(--fg2); line-height: 1.4; }
`;
    const s = document.createElement('style');
    s.id = 'cron-styles';
    s.textContent = css;
    document.head.appendChild(s);
  }

  // ── API client (relative to /api via portal's apiBase prefix) ─────
  const BROWSER_TZ = (() => {
    try { return Intl.DateTimeFormat().resolvedOptions().timeZone || null; }
    catch { return null; }
  })();

  const API = {
    preview: (schedule, count = 5, tz = BROWSER_TZ) => apiPostStrict('/cron/preview', { schedule, count, tz }),
    list: () => apiGetStrict('/cron/jobs'),
    create: (payload) => apiPostStrict('/cron/jobs', payload),
    update: (name, payload) => apiPutStrict('/cron/jobs/' + encodeURIComponent(name), payload),
    del: (name) => apiDelStrict('/cron/jobs/' + encodeURIComponent(name)),
    enable: (name) => apiPostStrict('/cron/jobs/' + encodeURIComponent(name) + '/enable', {}),
    disable: (name) => apiPostStrict('/cron/jobs/' + encodeURIComponent(name) + '/disable', {}),
    run: (name) => apiPostStrict('/cron/jobs/' + encodeURIComponent(name) + '/run', {}),
  };

  // ── Module state (per cron-tab visit) ──────────────────────────────
  const state = {
    jobs: [],
    modalOpen: false,
    cronStartVer: -1,          // routeVer when current pgCron started
  };

  // ── Constants ──────────────────────────────────────────────────────
  const PRESETS = [
    { label: 'Every minute',    value: '* * * * *' },
    { label: 'Every 30 min',    value: '*/30 * * * *' },
    { label: 'Hourly',          value: '0 * * * *' },
    { label: 'Daily 9 AM',      value: '0 9 * * *' },
    { label: 'Weekly Mon 9 AM', value: '0 9 * * 1' },
  ];
  const POLL_MS = 10000;
  const PREVIEW_DEBOUNCE_MS = 300;

  // Preset cron tasks shown in the picker. Edit this list to add/remove presets.
  // Each entry pre-fills the new-task dialog; users can still edit any field.
  const PRESET_TASKS = [
    {
      icon: '📅',
      name: 'daily-standup-summary',
      description: 'Summarize yesterday\'s activity every weekday morning.',
      schedule: '0 9 * * 1-5',
      prompt: 'Summarize my activity from yesterday across emails, chats, and commits. Highlight blockers and items needing my attention today.',
    },
    {
      icon: '📥',
      name: 'inbox-triage',
      description: 'Triage unread messages every hour during work hours.',
      schedule: '0 9-18 * * 1-5',
      prompt: 'Scan my unread messages, group them by urgency, and draft short replies for the top 3 most important items.',
    },
    {
      icon: '🧹',
      name: 'workspace-cleanup',
      description: 'Tidy temp files and stale branches once a week.',
      schedule: '0 10 * * 6',
      prompt: 'Audit my workspace: list large temp files, stale git branches (no commits in 30 days), and orphaned MCP server processes. Suggest a cleanup plan but do not delete anything.',
    },
    {
      icon: '🔄',
      name: 'dependency-check',
      description: 'Check for outdated dependencies every Monday.',
      schedule: '0 9 * * 1',
      prompt: 'Run a dependency audit on the active project. Report outdated packages, known security advisories, and a prioritized upgrade list.',
    },
    {
      icon: '📝',
      name: 'weekly-retro',
      description: 'Generate a weekly retrospective every Friday afternoon.',
      schedule: '0 16 * * 5',
      prompt: 'Compile a weekly retrospective: what shipped, what slipped, key decisions, and one process improvement to try next week.',
    },
    {
      icon: '🩺',
      name: 'system-health',
      description: 'Probe key endpoints every 30 minutes.',
      schedule: '*/30 * * * *',
      prompt: 'Probe the configured health endpoints, capture latency and status, and alert me only if any check fails or exceeds the latency budget.',
    },
  ];

  // ── Pure helpers ───────────────────────────────────────────────────
  function relTime(iso) {
    if (!iso) return '—';
    const t = new Date(iso).getTime();
    if (isNaN(t)) return '—';
    const diff = (t - Date.now()) / 1000;          // seconds; future positive
    const abs = Math.abs(diff);
    const fmt = (n, unit) => Math.round(n) + ' ' + unit + (Math.round(n) === 1 ? '' : 's');
    let body;
    if (abs < 60)        body = fmt(abs, 'second');
    else if (abs < 3600) body = fmt(abs / 60, 'minute');
    else if (abs < 86400) body = fmt(abs / 3600, 'hour');
    else                  body = fmt(abs / 86400, 'day');
    return diff >= 0 ? 'in ' + body : body + ' ago';
  }
  function fmtTime(iso, tz) {
    if (!iso) return '—';
    const d = new Date(iso);
    if (isNaN(d.getTime())) return iso;
    try {
      // YYYY-MM-DD HH:mm in target tz; tz=null → browser tz.
      const fmt = new Intl.DateTimeFormat('en-CA', {
        year: 'numeric', month: '2-digit', day: '2-digit',
        hour: '2-digit', minute: '2-digit', hour12: false,
        timeZone: tz || undefined,
      });
      // 'en-CA' yields '2026-05-11, 09:30' — replace the comma with a space.
      return fmt.format(d).replace(',', '');
    } catch {
      const pad = n => String(n).padStart(2, '0');
      return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate())
           + ' ' + pad(d.getHours()) + ':' + pad(d.getMinutes());
    }
  }
  function truncate(s, max) {
    if (!s) return '';
    return s.length > max ? s.slice(0, max - 1) + '…' : s;
  }
  function debounce(fn, ms) {
    let h = null;
    return function (...args) {
      if (h) clearTimeout(h);
      h = setTimeout(() => { h = null; fn.apply(this, args); }, ms);
    };
  }
  function toast(msg, isError) {
    const t = el('div', { class: 'cron-toast' + (isError ? ' error' : ''), text: msg });
    document.body.appendChild(t);
    setTimeout(() => t.remove(), 2400);
  }

  // ── Schedule preview component (used in modal) ─────────────────────
  // Returns an object with: { node, getValue, isValid, onValidChange, getTz }.
  // initialTz: explicit tz to use; null preserves "no tz" (server will use tzlocal)
  // — important for editing legacy jobs whose timezone field is null. Pass undefined
  // (the default) to fall back to the browser's tz, which is what we want at create time.
  function buildScheduleEditor(initial, initialTz) {
    let isValidNow = false;
    const validListeners = [];
    const onValid = fn => validListeners.push(fn);
    const fireValid = v => { isValidNow = v; validListeners.forEach(fn => fn(v)); };
    const tz = initialTz === undefined ? BROWSER_TZ : initialTz;

    const input = el('input', { type: 'text', class: 'cron-input',
      placeholder: '0 9 * * 1-5  (or interval seconds, e.g. 1800)' });
    if (initial) input.value = initial;
    const typeBadge = el('span', { class: 'cron-type-badge', text: '—' });

    const presetRow = el('div', { class: 'cron-presets' });
    PRESETS.forEach(p => {
      const chip = el('span', { class: 'cron-chip', text: p.label,
        onclick: () => { input.value = p.value; fireRefresh(); } });
      presetRow.appendChild(chip);
    });

    const previewHuman = el('div', { class: 'cron-preview-h', text: '—' });
    const previewRuns = el('div', { class: 'cron-preview-runs' });
    const previewBox = el('div', { class: 'cron-preview' }, previewHuman, previewRuns);

    async function refresh() {
      const v = input.value.trim();
      if (!v) {
        input.classList.remove('invalid');
        typeBadge.textContent = '—';
        previewHuman.textContent = '—';
        previewRuns.replaceChildren();
        fireValid(false);
        return;
      }
      let res;
      try { res = await API.preview(v, 5, tz); }
      catch (e) {
        input.classList.add('invalid');
        previewHuman.textContent = '';
        previewRuns.replaceChildren(el('div', { class: 'cron-preview-err', text: 'Preview failed: ' + e.message }));
        fireValid(false);
        return;
      }
      typeBadge.textContent = res.trigger_type || '—';
      if (!res.valid) {
        input.classList.add('invalid');
        previewHuman.textContent = '';
        previewRuns.replaceChildren(el('div', { class: 'cron-preview-err', text: res.error || 'Invalid schedule' }));
        fireValid(false);
        return;
      }
      input.classList.remove('invalid');
      previewHuman.textContent = res.human || (res.trigger_type === 'event' || res.trigger_type === 'at'
        ? 'No preview for ' + res.trigger_type + ' triggers' : '—');
      const runs = res.next_runs || [];
      if (runs.length) {
        const ul = el('ul');
        // When the editor has no tz (legacy job with timezone=null), the server
        // evaluates in its tzlocal — we honestly label the timestamps as such
        // rather than pretending they're in the browser's tz.
        const labelTz = tz || 'server tz';
        const firstSuffix = ' (' + labelTz + ')';
        runs.forEach((r, i) => {
          ul.appendChild(el('li', null,
            document.createTextNode(fmtTime(r, tz) + (i === 0 ? firstSuffix : '')),
            el('span', { class: 'rel', text: relTime(r) })));
        });
        previewRuns.replaceChildren(el('div', { text: 'Next 5 runs in ' + labelTz + ':' }), ul);
      } else {
        previewRuns.replaceChildren();
      }
      fireValid(true);
    }
    const debouncedRefresh = debounce(refresh, PREVIEW_DEBOUNCE_MS);
    function fireRefresh() { refresh(); }
    input.addEventListener('input', debouncedRefresh);
    input.addEventListener('blur', refresh);

    const node = el('div', null,
      el('label', { text: 'Schedule' }),
      presetRow,
      el('div', { class: 'cron-input-row' }, input, typeBadge),
      previewBox);

    // Fire initial preview if pre-filled (edit mode)
    if (initial) setTimeout(refresh, 0);

    return {
      node,
      getValue: () => input.value.trim(),
      // Empty schedule is never valid — server requires it on create. On edit,
      // the modal pre-fills schedule from the existing job so this stays true.
      isValid: () => isValidNow && !!input.value.trim(),
      onValidChange: onValid,
      getTz: () => tz,
    };
  }

  // ── Modal (New / Edit) ─────────────────────────────────────────────
  // prefill: { name?, description?, prompt?, schedule? } — used by preset picker
  // to seed a fresh "New" dialog. Ignored when isEdit is true.
  function openModal(existingJob, prefill) {
    const isEdit = !!existingJob;
    state.modalOpen = true;

    const errBox = el('div');
    const nameInput = el('input', { type: 'text', placeholder: 'my-task' });
    if (isEdit) { nameInput.value = existingJob.name; nameInput.disabled = true; }
    else if (prefill?.name) nameInput.value = prefill.name;
    const descInput = el('input', { type: 'text', placeholder: 'Optional short description' });
    if (isEdit && existingJob.description) descInput.value = existingJob.description;
    else if (!isEdit && prefill?.description) descInput.value = prefill.description;
    const promptInput = el('textarea', { placeholder: 'Prompt the agent will run…' });
    if (isEdit && existingJob.prompt) promptInput.value = existingJob.prompt;
    else if (!isEdit && prefill?.prompt) promptInput.value = prefill.prompt;

    const editor = isEdit
      ? buildScheduleEditor(String(existingJob.schedule), existingJob.timezone ?? null)
      : buildScheduleEditor(prefill?.schedule || '');
    const saveBtn = el('button', { class: 'primary', text: isEdit ? 'Save' : 'Create' });
    saveBtn.disabled = !editor.isValid();
    editor.onValidChange(v => { saveBtn.disabled = !v; });

    saveBtn.addEventListener('click', async () => {
      errBox.replaceChildren();
      const name = nameInput.value.trim();
      const desc = descInput.value.trim();
      const prompt = promptInput.value;
      const schedule = editor.getValue();
      try {
        if (isEdit) {
          // Partial-merge: only send keys that actually changed.
          const payload = {};
          if (desc !== (existingJob.description || '')) payload.description = desc || null;
          if (prompt !== (existingJob.prompt || '')) payload.prompt = prompt;
          if (schedule !== String(existingJob.schedule)) payload.schedule = schedule;
          // tz is fixed to the editor's tz (browser tz when creating; original tz when editing).
          if (!Object.keys(payload).length) { closeModal(); return; }
          await API.update(name, payload);
          toast('Updated');
        } else {
          if (!name) { errBox.replaceChildren(el('div', { class: 'cron-modal-err', text: 'Name is required' })); return; }
          await API.create({ name, description: desc || null, prompt, schedule, timezone: editor.getTz() });
          toast('Created');
        }
        closeModal();
        refreshTable();
      } catch (e) {
        errBox.replaceChildren(el('div', { class: 'cron-modal-err', text: e.message }));
      }
    });

    const cancelBtn = el('button', { text: 'Cancel', onclick: closeModal });
    const modal = el('div', { class: 'cron-modal' },
      el('h2', { text: isEdit ? 'Edit cron task' : 'New cron task' }),
      errBox,
      el('label', { text: 'Name' }),
      nameInput,
      isEdit ? el('div', { class: 'cron-readonly-hint', text: '(read-only — recreate to rename)' }) : null,
      el('label', { text: 'Description' }),
      descInput,
      el('label', { text: 'Prompt' }),
      promptInput,
      editor.node,
      el('div', { class: 'cron-modal-foot' }, cancelBtn, saveBtn));

    const bg = el('div', { class: 'cron-modal-bg', id: 'cron-modal-bg', onclick: e => { if (e.target.id === 'cron-modal-bg') closeModal(); } }, modal);
    document.body.appendChild(bg);
  }
  function closeModal() {
    state.modalOpen = false;
    const bg = document.getElementById('cron-modal-bg');
    if (bg) bg.remove();
  }

  // ── Preset picker ──────────────────────────────────────────────────
  // Closes itself and opens the New-task modal pre-filled with the chosen preset.
  function openPresetPicker() {
    state.modalOpen = true;
    const grid = el('div', { class: 'cron-preset-grid' });
    PRESET_TASKS.forEach(p => {
      const card = el('div', { class: 'cron-preset-card', title: 'Schedule: ' + p.schedule, onclick: () => {
        closePresetPicker();
        openModal(null, p);
      }});
      card.appendChild(el('div', { class: 'cron-preset-icon', text: p.icon || '⏱' }));
      card.appendChild(el('div', { class: 'cron-preset-body' },
        el('div', { class: 'cron-preset-name', text: p.name }),
        el('div', { class: 'cron-preset-desc', text: p.description || '' })));
      grid.appendChild(card);
    });
    const closeBtn = el('button', { text: 'Close', onclick: closePresetPicker });
    const modal = el('div', { class: 'cron-modal cron-preset-modal' },
      el('h2', { text: 'Preset cron tasks' }),
      el('div', { class: 'cron-preset-sub', text: 'Pick a template to pre-fill the new-task form. You can edit any field before saving.' }),
      grid,
      el('div', { class: 'cron-modal-foot' }, closeBtn));
    const bg = el('div', { class: 'cron-modal-bg', id: 'cron-preset-bg', onclick: e => { if (e.target.id === 'cron-preset-bg') closePresetPicker(); } }, modal);
    document.body.appendChild(bg);
  }
  function closePresetPicker() {
    state.modalOpen = false;
    const bg = document.getElementById('cron-preset-bg');
    if (bg) bg.remove();
  }

  // ── Table render ───────────────────────────────────────────────────
  function statusBadge(s) {
    const cls = ['disabled', 'running', 'error', 'idle'].includes(s) ? s : 'idle';
    const label = cls.charAt(0).toUpperCase() + cls.slice(1);
    return el('span', { class: 'cron-badge ' + cls, text: label });
  }
  function lastRunCell(job) {
    if (!job.last_run_at) {
      return el('span', { title: 'Never run' }, el('span', { class: 'cron-dot cron-dot-never' }), '—');
    }
    const dotCls = job.last_status === 'error' ? 'cron-dot-error' : 'cron-dot-success';
    const tip = (job.last_run_at || '') + (job.last_error ? '\n' + job.last_error : '');
    return el('span', { title: tip }, el('span', { class: 'cron-dot ' + dotCls }), relTime(job.last_run_at));
  }
  function openConfirmDelete(job) {
    state.modalOpen = true;
    const cancelBtn = el('button', { text: 'Cancel', onclick: closeConfirm });
    const confirmBtn = el('button', { class: 'primary danger-primary', text: 'Delete', onclick: async () => {
      try { await API.del(job.name); toast('Deleted'); closeConfirm(); await refreshTable(); }
      catch (e) { toast(e.message, true); closeConfirm(); }
    }});
    const modal = el('div', { class: 'cron-modal cron-confirm-modal' },
      el('h2', { text: 'Delete cron task?' }),
      el('div', { class: 'cron-confirm-body' },
        document.createTextNode('Delete '),
        el('code', { text: job.name }),
        document.createTextNode('? This cannot be undone.')),
      el('div', { class: 'cron-modal-foot' }, cancelBtn, confirmBtn));
    const bg = el('div', { class: 'cron-modal-bg', id: 'cron-confirm-bg', onclick: e => { if (e.target.id === 'cron-confirm-bg') closeConfirm(); } }, modal);
    document.body.appendChild(bg);
  }
  function closeConfirm() {
    state.modalOpen = false;
    const bg = document.getElementById('cron-confirm-bg');
    if (bg) bg.remove();
  }

  function buildActions(job) {
    const editBtn = el('button', { text: 'Edit', onclick: () => openModal(job) });
    const runBtn = el('button', { class: 'run', text: 'Run now', onclick: async () => {
      // optimistic flip to Running
      const row = document.querySelector('tr[data-job="' + CSS.escape(job.name) + '"] .cron-badge');
      if (row) { row.className = 'cron-badge running'; row.textContent = 'Running'; }
      try { await API.run(job.name); toast('Started'); }
      catch (e) { toast(e.message, true); refreshTable(); }
    }});
    const toggle = el('label', { class: 'cron-toggle', title: job.enabled ? 'Disable' : 'Enable' });
    const cb = el('input', { type: 'checkbox' });
    cb.checked = job.enabled;
    cb.addEventListener('change', async () => {
      const wantEnable = cb.checked;
      try {
        if (wantEnable) await API.enable(job.name); else await API.disable(job.name);
        await refreshTable();
      } catch (e) {
        cb.checked = !wantEnable;
        toast('Failed to ' + (wantEnable ? 'enable' : 'disable') + ': ' + e.message, true);
      }
    });
    toggle.appendChild(cb);
    toggle.appendChild(el('span', { class: 'slider' }));
    const delBtn = el('button', { class: 'danger', text: 'Delete', onclick: () => openConfirmDelete(job) });
    return el('div', { class: 'cron-actions' }, editBtn, runBtn, toggle, delBtn);
  }
  function renderTbody(tbody) {
    tbody.replaceChildren();
    // Server already filters out internal system jobs (heartbeat) at /api/cron/jobs.
    const userJobs = state.jobs;
    if (!userJobs.length) {
      const tr = el('tr');
      tr.appendChild(el('td', { colspan: 7, class: 'cron-empty', text: 'No scheduled tasks yet. Click "+ New cron task" to add one.' }));
      tbody.appendChild(tr);
      return;
    }
    userJobs.forEach(job => {
      const tr = el('tr');
      tr.setAttribute('data-job', job.name);
      tr.appendChild(el('td', { class: 'name', text: job.name }));
      tr.appendChild(el('td', { class: 'desc', title: job.description || '', text: truncate(job.description, 60) || '—' }));
      const tzLabel = job.timezone || 'server';
      const schedTitle = 'raw: ' + job.schedule + '\nin ' + tzLabel;
      const schedText = String(job.schedule) + '  (' + tzLabel + ')';
      tr.appendChild(el('td', { class: 'sched', title: schedTitle }, document.createTextNode(schedText)));
      tr.appendChild(el('td', null, lastRunCell(job)));
      tr.appendChild(el('td', { text: job.enabled ? relTime(job.next_run_at) : '—' }));
      tr.appendChild(el('td', null, statusBadge(job.status)));
      tr.appendChild(el('td', null, buildActions(job)));
      tbody.appendChild(tr);
    });
  }
  async function refreshTable() {
    if (state.modalOpen) return;          // never disrupt an open dialog
    try { state.jobs = await API.list() || []; }
    catch (e) { /* keep stale list; don't toast on auto-poll */ return; }
    const tbody = document.getElementById('cron-tbody');
    if (tbody) renderTbody(tbody);
  }
  function buildTableCard() {
    const headers = ['Name', 'Description', 'Schedule', 'Last run', 'Next run', 'Status', 'Actions'];
    const tw = el('div', { class: 'cron-tw' });
    const t = el('table');
    const thead = el('thead');
    const trh = el('tr');
    headers.forEach(h => trh.appendChild(el('th', { text: h })));
    thead.appendChild(trh);
    const tbody = el('tbody', { id: 'cron-tbody' });
    t.appendChild(thead);
    t.appendChild(tbody);
    tw.appendChild(t);
    renderTbody(tbody);
    return tw;
  }

  // ── Polling tick ───────────────────────────────────────────────────
  function tick(myVer) {
    if (myVer !== getRouteVer()) return;
    refreshTable().finally(() => {
      if (myVer === getRouteVer()) schedulePoll(() => tick(myVer), POLL_MS, myVer);
    });
  }

  // ── Page entry ─────────────────────────────────────────────────────
  async function pgCron() {
    const myVer = getRouteVer();
    state.cronStartVer = myVer;

    const presetBtn = el('button', { class: 'btn', text: 'Use preset',
      onclick: openPresetPicker });
    const newBtn = el('button', { class: 'btn btn-accent', text: '+ New cron task',
      onclick: () => openModal(null) });
    const header = el('div', { class: 'cron-hd-row' },
      C.page('Scheduled Tasks', 'Cron / interval / event triggers'),
      newBtn,
      presetBtn);

    // Initial fetch (so first paint already has data)
    try { state.jobs = await API.list() || []; }
    catch (e) { /* render empty card if list fails */ state.jobs = []; }
    if (myVer !== getRouteVer()) return;

    const page = el('div', { class: 'cron-page' }, header, buildTableCard());
    render(page);
    schedulePoll(() => tick(myVer), POLL_MS, myVer);
  }

  // ── Register page ─────────────────────────────────────────────────
  // Portal's init() calls route() at the end of its async startup, AFTER
  // auth has been resolved. Because <script src=cron.js> runs after
  // portal.js parses, pgCron is already on PRAESTOCLAW_PAGES by the time
  // route() fires. Calling route() ourselves here would bypass portal's
  // auth gate and trigger an Authentication popup (apiGetStrict → 401 →
  // onAuthExpired) on direct hash deep-link.
  window.PRAESTOCLAW_PAGES.cron = pgCron;
})();
