"""
PraestoClaw Runtime — wires together config, providers, tools, agent,
channels, security, web server, skills, and scheduling.
"""

from __future__ import annotations

import asyncio
import json
import uuid
from collections.abc import Callable
from pathlib import Path
from typing import TYPE_CHECKING, Any

from loguru import logger

from praestoclaw import __version__
from praestoclaw.agent.loop_v2 import AgentLoopV2
from praestoclaw.agent.tools.filesystem import (
    EditFileTool,
    ListDirTool,
    ReadFileTool,
    SearchFilesTool,
    WriteFileTool,
)
from praestoclaw.agent.tools.git import GitTool
from praestoclaw.agent.tools.notify import NotifyTool
from praestoclaw.agent.tools.registry import PROTECTED_TOOLS, ToolRegistry
from praestoclaw.agent.tools.shell import ShellTool
from praestoclaw.agent.tools.web import HttpRequestTool, WebFetchTool, WebSearchTool
from praestoclaw.bus.queue import MessageBus
from praestoclaw.channels.manager import ChannelManager
from praestoclaw.config.schema import AppConfig, ChannelType
from praestoclaw.hooks.manager import HookManager
from praestoclaw.host.legacy_agent_runtime import AgentLoopRuntimeAdapter
from praestoclaw.host.tui_backend import CloudTuiBackend, HostBackedTuiBackend
from praestoclaw.host.tui_shell import TuiShell
from praestoclaw.providers.resolver import get_provider
from praestoclaw.security.audit import AuditLogger
from praestoclaw.security.rbac import PolicyEngine
from praestoclaw.security.sandbox import Sandbox
from praestoclaw.session.bridge import SessionBridge
from praestoclaw.session.manager import SessionManager
from praestoclaw.session.store import SessionStore
from praestoclaw.skills.loader import SkillLoader
from praestoclaw.utils.helpers import get_data_dir, get_sessions_dir

if TYPE_CHECKING:
    from praestoclaw.cron.service import SchedulerService
    from praestoclaw.mcp.manager import MCPManager
    from praestoclaw.web.server import WebServer

_SHUTDOWN_TIMEOUT = 3  # seconds per cleanup step
_PROCESS_EXIT_HOOKS_INSTALLED = False


async def _quiet_stop(coro: Any, label: str = "") -> None:
    """Await a shutdown coroutine with a bounded timeout.

    Logs warnings on timeout or unexpected errors so failures aren't silent,
    but never blocks shutdown for longer than ``_SHUTDOWN_TIMEOUT``.

    CancelledError is suppressed (not re-raised) so that subsequent cleanup
    steps still run when the event loop cancels tasks during Ctrl+C shutdown.
    """
    try:
        await asyncio.wait_for(coro, timeout=_SHUTDOWN_TIMEOUT)
    except TimeoutError:
        logger.warning("Shutdown step timed out ({}s): {}", _SHUTDOWN_TIMEOUT, label)
    except asyncio.CancelledError:
        logger.debug("Shutdown step cancelled: {}", label)
    except Exception:
        logger.opt(exception=True).warning("Shutdown step failed: {}", label)


def _resolve_log_path(configured: str | None) -> Path:
    """Resolve ``logging.file`` to an absolute path anchored at the data dir.

    - ``None``: default to ``<data_dir>/logs/praestoclaw-<version>.log``.
    - Absolute path (after ``~`` expansion): used as-is.
    - Relative path: resolved against ``get_data_dir()`` so it doesn't depend
      on the process cwd at startup.
    """
    from praestoclaw import __version__ as _ver
    from praestoclaw.utils.helpers import get_data_dir

    if configured is None:
        return get_data_dir() / "logs" / f"praestoclaw-{_ver}.log"
    p = Path(configured).expanduser()
    if not p.is_absolute():
        p = get_data_dir() / p
    return p


class Runtime:
    """Main runtime orchestrator — wires all subsystems together."""

    def __init__(
        self,
        config: AppConfig,
        workspace: Path | None = None,
        config_local_path: Path | None = None,
    ) -> None:
        self.config = config
        self.workspace = (workspace or Path(config.workspace)).resolve()
        self._config_local_path = config_local_path

        # Configure logging
        self._setup_logging()

        # Process exit / signal observability — record final disposition so the
        # difference between graceful shutdown, signal kill, and crash is
        # visible in the log instead of looking identical (silent end of file).
        self._install_process_exit_hooks()

        # Core subsystems
        self.audit = AuditLogger(config.security.audit)

        # Initialize secret store with config BEFORE migration (so backend selection
        # respects security.secret_backend and singleton is set for all later callers)
        from praestoclaw.security.secrets import get_secret_store

        get_secret_store(config)

        # Auto-migrate plaintext secrets to encrypted form (before provider resolution)
        from praestoclaw.security.migrate import maybe_migrate_secrets

        maybe_migrate_secrets(config, self._config_local_path, self.audit)

        # A2A runtime (async envelope model) — wired even when disabled
        self._a2a_task_store = None  # legacy attr (unused; kept for back-compat)
        self._a2a_runtime: Any = None
        # Always resolve instance_id — required for cloud handshake even without A2A.
        # channels.cloud.a2a_instance_id is kept as a legacy fallback; the canonical
        # config location is channels.a2a.instance_id.
        from praestoclaw.a2a.identity import get_or_create_instance_id

        self._a2a_instance_id = (
            config.channels.a2a.instance_id
            or config.channels.cloud.a2a_instance_id
            or get_or_create_instance_id(get_data_dir())
        )
        if config.channels.a2a.enabled:
            from praestoclaw.a2a.models import A2AParty
            from praestoclaw.a2a.runtime import A2ARuntime

            # A2A user_id resolution order:
            #   1. explicit config.channels.a2a.user_id (multi-instance dev override)
            #      or legacy config.channels.cloud.a2a_user_id
            #   2. fre_state.user.upn / oid (captured by `pc init` from id_token)
            #   3. instance_id (anon fallback — produces "anon-<id>" on the gateway)
            # Without (2), users who finish init see their A2A identity as
            # "anon-<random>" until they manually edit channels.a2a.user_id,
            # which breaks cross-instance addressing.
            _a2a_user_id = config.channels.a2a.user_id or config.channels.cloud.a2a_user_id
            _fre_upn: str | None = None
            if not _a2a_user_id:
                try:
                    from praestoclaw.utils.fre_state import load_fre_state

                    _fre_user = load_fre_state().get("user") or {}
                    _fre_upn = (
                        _fre_user.get("upn")
                        or _fre_user.get("preferred_username")
                        or _fre_user.get("oid")
                        or None
                    )
                except Exception:
                    _fre_upn = None
                _a2a_user_id = _fre_upn or self._a2a_instance_id
            _a2a_display = self._derive_a2a_display_name() or _a2a_user_id
            self._a2a_runtime = A2ARuntime(
                local_party=A2AParty(id=_a2a_user_id, name=_a2a_display),
            )
            _source = (
                "config"
                if config.channels.a2a.user_id
                else ("fre_state" if _fre_upn else "anon-instance")
            )
            logger.info(
                "A2A enabled: instance_id={}, user_id={} (source={})",
                self._a2a_instance_id,
                _a2a_user_id,
                _source,
            )

        self.sandbox = Sandbox(
            self.workspace,
            shell_config=config.tools.shell,
            profile=config.security.profile,
            allowed_paths=config.security.allowed_paths,
            denied_paths=config.security.denied_paths,
        )
        self.bus = MessageBus()
        # Strong references to fire-and-forget background tasks so the event
        # loop's weak-ref behavior doesn't GC them mid-run. See PEP 3156 /
        # https://docs.python.org/3/library/asyncio-task.html#asyncio.create_task
        # ("a task may be garbage collected at any time, even before it's done").
        # Tasks self-remove via add_done_callback when they complete.
        self._background_tasks: set[asyncio.Task[Any]] = set()
        self.session_manager = SessionManager(get_sessions_dir())
        self.provider = get_provider(config.providers)
        # Token usage tracking (persistent JSONL)
        from praestoclaw.providers.usage import TokenUsageTracker

        self.usage_tracker = TokenUsageTracker(get_data_dir())
        if hasattr(self.provider, "set_usage_tracker"):
            self.provider.set_usage_tracker(self.usage_tracker)

        self.tool_registry = ToolRegistry(self.audit)
        self.tool_registry.set_output_config(config.tools.output)
        self.channel_manager = ChannelManager(self.bus)
        self.hook_manager = HookManager()
        self.policy_engine = PolicyEngine(config.security)
        self.skill_loader = SkillLoader(
            self.workspace,
            tool_registry=self.tool_registry,
            disabled_names=list(config.skills.disabled),
        )

        # E-stop
        from praestoclaw.security.estop import EStop

        self.estop = EStop(events=self.bus.events, audit=self.audit)

        # Risk scorer (v2) — wired for ALL profiles.
        # The scorer always runs; the policy table decides the action per profile.
        self._scorer = None
        if self.provider:
            from praestoclaw.security.scorer import RiskScorer

            self._scorer = RiskScorer(
                self.provider,
                profile=config.security.profile,
                risk_context=getattr(config.security, "risk_context", None),
            )

        # Approval manager and allowlist for human-in-the-loop approval routing
        from praestoclaw.security.approval import ApprovalManager

        self.approval_manager = ApprovalManager(config.security.approval)

        self._allowlist = None
        if config.security.allowlist.enabled:
            from praestoclaw.security.allowlist import AllowlistManager

            # Allowlist persistence to praestoclaw.local.yaml
            def _persist_entry(entry_dict: dict) -> None:  # type: ignore[type-arg]
                try:
                    from praestoclaw.config.loader import append_local_config_list

                    append_local_config_list("security.allowlist.entries", entry_dict)
                except Exception as exc:
                    logger.warning("Failed to persist allowlist entry: {}", exc)

            def _remove_entry(index: int) -> None:
                try:
                    from praestoclaw.config.loader import remove_local_config_list

                    remove_local_config_list("security.allowlist.entries", index)
                except Exception as exc:
                    logger.warning("Failed to persist allowlist removal: {}", exc)

            self._allowlist = AllowlistManager(
                config.security.allowlist,
                persist_fn=_persist_entry,
                remove_fn=_remove_entry,
                audit_logger=self.audit,
            )

        # Register built-in hook handlers
        # NOTE: Runtime wiring is tested via integration tests (not unit tests).
        from praestoclaw.hooks.handlers import register_builtin_handlers

        register_builtin_handlers(
            self.hook_manager,
            estop=self.estop,
            policy_engine=self.policy_engine,
            audit_logger=self.audit,
            scorer=self._scorer,
            approval_manager=self.approval_manager,
            allowlist=self._allowlist,
            bus=self.bus.events,
            message_bus=self.bus,
            channel_manager=self.channel_manager,
            session_manager=self.session_manager,
            auto_approve_timeout=config.security.approval.auto_approve_timeout,
            security_profile=config.security.profile,
        )

        # Wire APPROVAL_RESOLVED events directly to ApprovalManager.resolve().
        # This bypasses the inbound message queue to avoid deadlock — the agent
        # loop blocks in the pre_tool_use hook while waiting for approval.
        from praestoclaw.bus.events import EventType

        async def _on_approval_resolved(event_type: EventType, payload: dict) -> None:
            action = payload.get("action", "")
            request_id = payload.get("request_id", "")
            resolver = payload.get("resolver", "unknown")
            # Empty request_id = resolve whichever single pending approval exists
            # (used by plain-text keyword fast-path: "yes", "no", etc.)
            if not request_id:
                pending = self.approval_manager.get_pending()
                if len(pending) == 1:
                    request_id = pending[0].id
                else:
                    return
            try:
                approved = action in ("approve", "always")
                self.approval_manager.resolve(
                    request_id, approved=approved, resolver=resolver, action=action
                )
                if action == "always" and self._allowlist:
                    req = self.approval_manager.get_request(request_id)
                    if req:
                        self._allowlist.add(
                            req.tool_name, req.args, added_by=resolver, note="Added via always"
                        )
                # Persist the approval resolution to session history.
                # Append a new approval_resolved record (add_message persists to JSONL)
                # rather than mutating the in-memory cache directly.
                status = "approved" if approved else "denied"
                for sid, msgs in self.session_manager._sessions.items():
                    for m in msgs:
                        if m.get("role") != "approval_request":
                            continue
                        try:
                            data = json.loads(m.get("content", "{}"))
                        except Exception as exc:
                            logger.debug("Failed to parse approval_request content: {}", exc)
                            continue
                        if data.get("request_id") != request_id:
                            continue
                        try:
                            self.session_manager.add_message(
                                sid,
                                {
                                    "role": "approval_resolved",
                                    "content": json.dumps(
                                        {
                                            "request_id": request_id,
                                            "status": status,
                                            "resolver": resolver,
                                        }
                                    ),
                                },
                            )
                        except Exception as exc:
                            logger.warning("Failed to persist approval resolution: {}", exc)
                        return  # request_id is unique — stop after first match
            except (KeyError, ValueError) as exc:
                logger.warning("Approval resolve failed: {}", exc)

        self.bus.events.on(EventType.APPROVAL_RESOLVED, _on_approval_resolved)

        # E-stop → kill all background shell processes
        async def _on_estop(event_type: EventType, payload: dict) -> None:
            reason = payload.get("reason", "E-stop event")
            actor = payload.get("actor", "system")
            if not self.estop.is_halted:
                self.estop.trigger(reason, actor=actor)
            shell_tool = self.tool_registry.get("shell")
            if shell_tool and hasattr(shell_tool, "kill_all_background"):
                killed = await shell_tool.kill_all_background()
                if killed:
                    logger.warning(f"E-stop: killed {killed} background shell processes")

        self.bus.events.on(EventType.SECURITY_ESTOP, _on_estop)

        # Scheduler (cron + interval + event + heartbeat)
        self.scheduler: SchedulerService | None = None
        if config.cron.enabled:
            from praestoclaw.cron.service import SchedulerService

            self.scheduler = SchedulerService(
                config.cron,
                bus=self.bus,
                active_channels_fn=self.channel_manager.active_channel_names,
            )

        # Optional subsystems (initialized lazily)
        self._web_server: WebServer | None = None
        self._mcp_manager: MCPManager | None = None
        self._copilot_service: Any = None  # set in _register_tools() if SDK available
        self._claude_code_service: Any = None  # set in _register_tools() if SDK importable

        # Shared memory (used by both AgentLoop and SearchHistoryTool)
        from praestoclaw.agent.memory import AgentMemory

        self._memory = AgentMemory()

        # Register built-in tools
        self._register_tools()

        # CronTool (agent self-scheduling — dynamically registered when cron.enabled)
        if self.scheduler:
            from praestoclaw.agent.tools.cron import CronTool

            self.tool_registry.register(CronTool(self.scheduler, self.tool_registry))

            # Megaphone auto-registration (if config exists and enabled)
            from praestoclaw.megaphone.loader import maybe_register_megaphone_jobs

            maybe_register_megaphone_jobs(self.scheduler)

            # Megaphone tools — reload applies config edits; state gives cron
            # scans narrow access to config/state outside the workspace sandbox.
            from praestoclaw.agent.tools.megaphone import MegaphoneReloadTool, MegaphoneStateTool

            self.tool_registry.register(MegaphoneReloadTool(self.scheduler))
            self.tool_registry.register(MegaphoneStateTool())

        # Merge built-in + user agents
        from praestoclaw.agents.builtin import get_builtin_agents, merge_agents

        self._all_agents = merge_agents(get_builtin_agents(), config.agents.agents)

        # Also apply explicit overrides from agents.default onto the merged
        # built-in default agent. This keeps backward compatibility for users
        # who configure default under agents.default in YAML.
        if "default" in self._all_agents:
            default_overlay = merge_agents(
                {"default": self._all_agents["default"]},
                {"default": config.agents.default},
            )
            self._all_agents["default"] = default_overlay["default"]

        # Auto-populate tools=None → all registered tool names.
        # The default agent sets tools=None meaning "all tools"; at this point
        # the registry has every built-in + conditional tool registered, so we
        # resolve None to a concrete list before any code iterates over it.
        all_tool_names = sorted(t.name for t in self.tool_registry.list_tools())
        self._auto_tools_agents: set[str] = set()  # agents that had tools=None
        for _name, _cfg in self._all_agents.items():
            if _cfg.tools is None:
                self._auto_tools_agents.add(_name)
                self._all_agents[_name] = _cfg.model_copy(update={"tools": list(all_tool_names)})

        # Create agent loop for entrypoint
        agent_config = self._all_agents.get("default", config.agents.default)
        if config.entrypoint != "default" and config.entrypoint in self._all_agents:
            agent_config = self._all_agents[config.entrypoint]

        # Inject available agent names into SpawnTool (registered before _all_agents was ready)
        spawn_tool = self.tool_registry.get("spawn")
        if spawn_tool and hasattr(spawn_tool, "set_available_agents"):
            spawn_tool.set_available_agents(list(self._all_agents.keys()))

        # Load skills and mark protected-name conflicts
        skills = self.skill_loader.load_all()
        for skill in skills:
            if skill.name in PROTECTED_TOOLS:
                logger.warning("Skill '{}' shadows a protected tool — hidden from LLM", skill.name)
                skill.disable_model_invocation = True

        # Register installed-skill safe_tools as ephemeral allowlist entries.
        # IMPORTANT: only ``bundled`` skills are auto-trusted to declare
        # ``safe-tools``.  ``user`` and ``workspace`` tiers are explicitly
        # NOT trusted because their files can be authored by anyone with
        # write access to the user's home directory or the repo (a PR
        # contributor, a malicious skill imported from ``~/.claude`` or VS
        # Code Copilot via ``pc init``, etc.).  Allowing those tiers to
        # register safe-tool entries would let an attacker bypass the entire
        # approval pipeline with a single committed file like::
        #
        #     safe-tools:
        #       - tool: shell
        #         match: {command: ".*"}
        #
        # Bundled patterns are vetted by us and additionally auto-anchored
        # by ``AllowlistManager.add_ephemeral_entries`` for defense in depth.
        if self._allowlist is not None:
            for skill in skills:
                if skill.source_tier == "bundled" and skill.safe_tools:
                    self._allowlist.add_ephemeral_entries(
                        skill.safe_tools,
                        added_by=f"skill:{skill.name}@{skill.source_tier}",
                    )
                elif skill.safe_tools:
                    # Visible warning so the skill author / user knows the
                    # safe-tools block was deliberately ignored.
                    logger.warning(
                        "Skill '{}' (tier={}) declares safe-tools but only "
                        "bundled skills may register them; ignoring.",
                        skill.name,
                        skill.source_tier,
                    )

        logger.info(
            "Agent core: v2 (Hermes-style) — budget={}, failover_chain={}, session=SQLite",
            agent_config.budget.max_iterations,
            len(getattr(agent_config, "failover", None) and agent_config.failover.chain or []),
        )

        # Initialize SQLite session store (async init happens in _async_start)
        self._session_store_v2 = SessionStore(db_path=get_data_dir() / "sessions.db")

        # Replace session_manager with sync bridge so web handlers,
        # CLI commands, and other code that does rt.session_manager.xxx()
        # reads/writes the same SQLite store as the v2 agent loop.
        self.session_manager = SessionBridge(self._session_store_v2)  # type: ignore[assignment]

        # Build failover provider
        provider = self._build_failover_provider(agent_config)

        self.agent = AgentLoopV2(
            config=agent_config,
            provider=provider,
            tool_registry=self.tool_registry,
            bus=self.bus,
            session_store=self._session_store_v2,
            workspace=self.workspace,
            audit=self.audit,
            hooks=self.hook_manager,
            available_agents=self._all_agents,
            skill_loader=self.skill_loader,
            skills_config=self.config.skills,
            approval_manager=self.approval_manager,
            allowlist=self._allowlist,
            mcp_configs=self.config.tools.mcp_servers or None,
            memory=self._memory,
        )

        # Wire A2A runtime's process function to the main agent loop
        if self._a2a_runtime is not None:
            self._a2a_runtime.set_process_fn(self.agent.run_once)
            self._a2a_runtime.set_bus(self.bus)
            self._a2a_runtime.set_channel_resolver(self.channel_manager.get)
            self._a2a_runtime.set_notify_channel_picker(self._pick_a2a_notify_channel)

        logger.debug(
            f"Runtime initialized: {config.name} v{__version__} "
            f"(profile={config.security.profile.value})"
        )

    def _pick_a2a_notify_channel(self) -> list[ChannelType]:
        """Pick the channel(s) that should carry A2A user-facing notifications.

        Broadcasts to every locally-connected channel so the user sees the
        notification wherever they happen to be sitting (Teams via cloud
        bridge, local browser webchat, ``pc chat`` terminal, etc.). Cloud
        cannot know which downstream subscriber is the right destination,
        and the local web channel only has push subscribers when an actual
        browser is open — so fanning out across all active channels is
        cheap and correct: each channel's own `send` decides whether to
        deliver or drop. Returns an empty list when nothing is connected;
        the A2A runtime then falls back to its own default so the message
        is at least logged.
        """
        return self.channel_manager.active_channel_names()

    def _build_failover_provider(self, agent_config: Any) -> Any:
        """Build FailoverProvider from config or wrap primary."""
        from praestoclaw.providers.failover import FailoverProvider, ProviderEntry

        failover_config = getattr(agent_config, "failover", None)
        if not failover_config or not failover_config.chain:
            return FailoverProvider(chain=[ProviderEntry(backend=self.provider, label="primary")])
        entries = [ProviderEntry(backend=self.provider, label="primary")]
        for pc in failover_config.chain:
            backend = self._create_provider_backend(pc)
            if backend:
                entries.append(
                    ProviderEntry(
                        backend=backend,
                        label=f"{pc.type}/{pc.model or 'default'}",
                    )
                )
        return FailoverProvider(chain=entries)

    def _create_provider_backend(self, pc: Any) -> Any:
        """Create a provider backend from ProviderBackendConfig."""
        try:
            if pc.type == "openai":
                from praestoclaw.providers.openai import OpenAIProvider

                return OpenAIProvider(
                    api_key=pc.api_key.get_secret_value() if pc.api_key else "",
                    base_url=pc.base_url,
                    api_mode=pc.api_mode,
                )
            elif pc.type == "anthropic":
                from praestoclaw.providers.anthropic import AnthropicProvider

                return AnthropicProvider(
                    api_key=pc.api_key.get_secret_value() if pc.api_key else "",
                    base_url=pc.base_url,
                )
        except ImportError as exc:
            logger.warning("Provider {} unavailable: {}", pc.type, exc)
        return None

    def _install_process_exit_hooks(self) -> None:
        """Register atexit + signal handlers that log a final disposition line.

        Without these, a killed/crashed process leaves no record — the log
        just stops mid-stream. We want to be able to tell graceful exit
        from SIGTERM (parent supervisor / OS shutdown), SIGINT (Ctrl+C),
        or an unhandled crash.

        Idempotent: safe to call multiple times across Runtime instances
        (tests, embedded uses). Only the first call installs handlers, and
        the SIGINT handler delegates to whatever handler was already in
        place so we don't break Ctrl+C → KeyboardInterrupt semantics or
        other supervisors' SIGTERM coordination.
        """
        global _PROCESS_EXIT_HOOKS_INSTALLED
        if _PROCESS_EXIT_HOOKS_INSTALLED:
            return
        _PROCESS_EXIT_HOOKS_INSTALLED = True

        import atexit
        import os
        import signal

        pid = os.getpid()
        logger.info("praestoclaw process started: pid={} version={}", pid, __version__)

        def _on_exit() -> None:
            logger.info("praestoclaw process exiting (atexit) pid={}", pid)

        atexit.register(_on_exit)

        def _make_signal_handler(prev_handler: Any) -> Callable[[int, Any], None]:
            def _on_signal(signum: int, frame: Any) -> None:
                try:
                    name = signal.Signals(signum).name
                except ValueError:
                    name = str(signum)
                logger.warning(
                    "praestoclaw received signal {} ({}) pid={}",
                    name,
                    signum,
                    pid,
                )
                # Delegate to the prior handler so existing semantics stay
                # intact: SIG_DFL (default), default_int_handler (raises
                # KeyboardInterrupt), or whatever the embedding supervisor
                # installed (e.g., uvicorn). SIG_IGN means we just log.
                if callable(prev_handler):
                    prev_handler(signum, frame)
                elif prev_handler == signal.SIG_DFL:
                    signal.signal(signum, signal.SIG_DFL)
                    os.kill(pid, signum)

            return _on_signal

        for sig in (signal.SIGTERM, signal.SIGINT):
            try:
                prev = signal.getsignal(sig)
                signal.signal(sig, _make_signal_handler(prev))
            except (OSError, ValueError):
                # Not on the main thread (some test/embed contexts) — skip silently.
                pass

        self._install_stuck_traceback_dumper(pid)

    def _install_stuck_traceback_dumper(self, pid: int) -> None:
        """Periodically dump every thread's stack to ``stuck.log``.

        The dump is driven by a stdlib :mod:`faulthandler` timer rather
        than an asyncio task, so a blocked event loop — the one failure
        mode where regular logging stops working — cannot suppress it.
        Each entry looks like::

            Timeout (0:00:60)!
            Thread 0x... (most recent call first):
              File "subprocess.py", line 1209, in _communicate
              File "auth/azure_cli/provider.py", line 87, in try_silent
              ...

        When a user reports "agent stopped responding but the process
        is still alive", ``stuck.log`` is the single artefact that
        tells you which line of code the event loop is parked on.

        The file is truncated on each process start so it only ever
        holds dumps from the current run; we do not want stale stacks
        from a previous hang masquerading as a current one.
        """
        try:
            import faulthandler

            from praestoclaw.utils.helpers import get_data_dir

            stuck_path = get_data_dir() / "logs" / "stuck.log"
            stuck_path.parent.mkdir(parents=True, exist_ok=True)
            # Truncate (mode "w") then keep open for the lifetime of the
            # process. Line-buffered so partial dumps survive a hard
            # kill. The file handle is intentionally not closed — it
            # lives until the process exits.
            self._stuck_log_handle = stuck_path.open("w", buffering=1)
            faulthandler.dump_traceback_later(60, repeat=True, file=self._stuck_log_handle)
            logger.info(
                "faulthandler installed: dumping every 60s to {} (pid={})",
                stuck_path,
                pid,
            )
        except Exception as exc:  # noqa: BLE001 - never block startup on diagnostics
            logger.warning("faulthandler install failed: {}", exc)

    def _setup_logging(self) -> None:
        import sys
        import warnings

        # Windows has no time.tzset(), so tzlocal cannot reconcile TZ env
        # with the system clock — it always warns on non-UTC machines.
        if sys.platform == "win32":
            warnings.filterwarnings(
                "ignore",
                message="Timezone offset does not match system offset",
                category=UserWarning,
                module=r"^tzlocal",
            )

        logger.remove()
        log_cfg = self.config.logging
        console_level = log_cfg.console_level.value
        file_level = log_cfg.file_level.value
        if log_cfg.format == "json":
            logger.add(sys.stderr, level=console_level, serialize=True)
        else:
            logger.add(
                sys.stderr,
                level=console_level,
                format="<green>{time:HH:mm:ss}</green> | <level>{level: <8}</level> | {message}",
            )
        # Log file path is fixed — `logging.file` in config is
        # intentionally ignored. A misconfigured path (typo, relative
        # path that resolves to a surprising cwd, unwritable
        # directory) silently turned the file sink into a no-op and
        # was a recurring source of "no log file" support reports.
        log_path = str(_resolve_log_path(None))
        logger.add(
            log_path,
            level=file_level,
            rotation=log_cfg.rotation,
            retention=log_cfg.retention,
            compression="zip",
            enqueue=True,
        )

    @staticmethod
    def _load_config_schema() -> dict[str, Any]:
        """Load the bundled JSON Schema for config validation and lookup."""
        import json
        from importlib.resources import files

        try:
            text = (
                files("praestoclaw.defaults")
                .joinpath("praestoclaw-config.schema.json")
                .read_text(encoding="utf-8")
            )
            result: dict[str, Any] = json.loads(text)
            return result
        except Exception as exc:
            logger.warning("Failed to load bundled config schema: {}", exc)
            return {}

    def _register_tools(self) -> None:
        """Register all built-in tools.

        Registration order: core (alphabetical) → standard (alphabetical).
        This keeps list_tools() output naturally ordered for the common case.
        MCP and conditional tools (copilot, claude_code, cron) are registered
        dynamically and may appear out of order; list_tools_sorted() produces
        a stable display order (tier → category → name) when needed.
        """
        # ── Core tier (auto-activate, always in schema) ──────────────────
        self.tool_registry.register(
            EditFileTool(
                self.sandbox, max_file_size_bytes=self.config.tools.filesystem.max_file_size_bytes
            )
        )
        self.tool_registry.register(ListDirTool(self.sandbox))
        self.tool_registry.register(
            NotifyTool(
                self.bus,
                active_channels_fn=self.channel_manager.active_channel_names,
            )
        )
        self.tool_registry.register(ReadFileTool(self.sandbox))
        self.tool_registry.register(SearchFilesTool(self.sandbox))

        from praestoclaw.agent.tools.search_history import SearchHistoryTool

        self.tool_registry.register(SearchHistoryTool(self._memory))

        from praestoclaw.agent.tools.memory_tool import MemoryTool

        # Always register — per-agent memory_writable enforcement is in
        # AgentLoopV2._get_tool_schemas() and _execute_tools()
        self.tool_registry.register(
            MemoryTool(
                self._memory,
                user_file=self.config.agents.default.user_file,
                workspace=self.workspace,
            )
        )
        self.tool_registry.register(ShellTool(self.sandbox))

        # Plan tool — structured TODO / SOP runtime for long-running tasks.
        # Persists plans to <data_dir>/plans/<session_id>.json.
        from praestoclaw.agent.tools.plan import PlanTool

        self._plan_tool = PlanTool(bus=self.bus)
        self.tool_registry.register(self._plan_tool)

        # ── Standard tier (on-demand activation) ─────────────────────────
        from praestoclaw.agent.tools.skill_manage import SkillManageTool

        self.tool_registry.register(SkillManageTool(self.skill_loader))
        if self.config.tools.browser.enabled:
            from praestoclaw.agent.tools.browser import BrowserTool

            self.tool_registry.register(BrowserTool(self.config.tools.browser))

        from praestoclaw.agent.tools.update import UpdateCheckTool

        self.tool_registry.register(UpdateCheckTool())

        from praestoclaw.agent.tools.config_praestoclaw import ConfigPraestoclawTool
        from praestoclaw.config.loader import _home_local_override

        local_path = self._config_local_path or _home_local_override()
        self.tool_registry.register(
            ConfigPraestoclawTool(self.config, local_path, self._load_config_schema(), runtime=self)
        )
        self.tool_registry.register(GitTool(self.sandbox))
        self.tool_registry.register(HttpRequestTool())

        from praestoclaw.agent.tools.spawn import SpawnTool

        self.tool_registry.register(SpawnTool(self._spawn_agent))

        # A2A tool (conditional on A2A being enabled)
        if self._a2a_runtime is not None:
            from praestoclaw.agent.tools.a2a import A2ATool
            from praestoclaw.agent.tools.u2u import U2UTool

            self.tool_registry.register(A2ATool(self._a2a_runtime))
            self.tool_registry.register(
                U2UTool(lambda: self.channel_manager.get(ChannelType.CLOUD))
            )

        self.tool_registry.register(WebFetchTool())
        self.tool_registry.register(WebSearchTool())
        self.tool_registry.register(
            WriteFileTool(
                self.sandbox, max_file_size_bytes=self.config.tools.filesystem.max_file_size_bytes
            )
        )

        # ── Conditional standard tools (depend on optional SDKs) ─────────
        # Copilot delegate tool (if enabled and copilot SDK is installed)
        if getattr(self.config.tools.copilot, "enabled", False):
            try:
                from praestoclaw.agent.tools.copilot import (
                    CopilotDelegateService,
                    CopilotDelegateTool,
                    CopilotModelsTool,
                    CopilotStatusTool,
                )

                gh_token = self.config.providers.github_copilot.token
                github_token = gh_token.get_secret_value() if gh_token else None
                self._copilot_service = CopilotDelegateService(
                    self.workspace,
                    self.bus,
                    config=self.config.tools.copilot,
                    github_token=github_token,
                )
                self.tool_registry.register(CopilotDelegateTool(self._copilot_service))
                self.tool_registry.register(CopilotStatusTool(self._copilot_service))
                self.tool_registry.register(CopilotModelsTool(self._copilot_service))
                logger.debug("CopilotDelegate tools registered (github-copilot-sdk found)")
            except ImportError:
                self._copilot_service = None
                logger.debug("github-copilot-sdk not installed — github_copilot tool disabled")
        else:
            logger.debug("CopilotDelegate tools disabled by configuration")

        # Claude Code delegate tool (if enabled and SDK + CLI available)
        if getattr(self.config.tools.claude_code, "enabled", False):
            try:
                import shutil

                import claude_agent_sdk  # noqa: F401

                # Verify the claude CLI binary is reachable (SDK bundles it,
                # but PATH issues can make it unavailable).
                cli_path = getattr(self.config.tools.claude_code, "cli_path", None)
                if not cli_path and not shutil.which("claude"):
                    raise FileNotFoundError(
                        "claude binary not found on PATH (sdk installed but CLI missing)"
                    )

                from praestoclaw.agent.tools.claude_code import (
                    ClaudeCodeService,
                    ClaudeCodeStatusTool,
                    ClaudeCodeTool,
                )

                self._claude_code_service = ClaudeCodeService(
                    self.workspace,
                    self.bus,
                    config=self.config.tools.claude_code,
                )
                self.tool_registry.register(ClaudeCodeTool(self._claude_code_service))
                self.tool_registry.register(ClaudeCodeStatusTool(self._claude_code_service))
                logger.debug("ClaudeCode tools registered (claude-agent-sdk + CLI found)")
            except ImportError:
                self._claude_code_service = None
                logger.debug("claude-agent-sdk not installed — claude_code tool disabled")
            except FileNotFoundError as exc:
                self._claude_code_service = None
                logger.debug(f"claude CLI not found — claude_code tool disabled: {exc}")
            except Exception as exc:
                self._claude_code_service = None
                logger.debug(f"ClaudeCode tools setup failed: {exc}")
        else:
            logger.debug("ClaudeCode tools disabled by configuration")

        # MCP manager — on-demand server connection (no eager startup)
        if self.config.tools.mcp_servers:
            from praestoclaw.mcp.manager import MCPManager as _MCPManager

            self._mcp_manager = _MCPManager(
                configs=self.config.tools.mcp_servers,
                registry=self.tool_registry,
                security_profile=self.config.security.profile.value,
                on_tools_registered=self._on_mcp_tools_registered,
                providers=self.config.providers,
                risk_policy=self.config.tools.mcp_risk_policy or None,
                risk_variables=self._build_risk_variables(),
            )
            self.tool_registry.set_mcp_manager(self._mcp_manager)

        # ── Core: tools meta-tool (registered last — needs MCP manager ref) ──
        from praestoclaw.agent.tools.tools import ToolsTool

        self.tool_registry.register(
            ToolsTool(
                registry=self.tool_registry,
                mcp_manager=self._mcp_manager,
                skill_loader=self.skill_loader,
            )
        )

        logger.debug(f"Registered {len(self.tool_registry.list_tools())} tools")

    def _build_risk_variables(self) -> dict[str, str]:
        """Build ${var} placeholders for MCP risk rule patterns from USER.md identity."""
        variables: dict[str, str] = {}
        user_file = getattr(self.config.agents.default, "user_file", None)
        try:
            from praestoclaw.utils.identity import _resolve_user_md

            user_md = _resolve_user_md(user_file)
            if user_md.exists():
                import re as _re

                text = user_md.read_text(encoding="utf-8")
                email_m = _re.search(r"^- Email:\s*(.+)$", text, _re.MULTILINE)
                org_m = _re.search(r"^- Organization:\s*(.+)$", text, _re.MULTILINE)
                if email_m:
                    variables["user_email"] = email_m.group(1).strip()
                if org_m:
                    variables["user_org"] = org_m.group(1).strip()
        except Exception:
            pass
        return variables

    def _on_mcp_tools_registered(self, tool_names: list[str]) -> None:
        """Callback: MCPManager registered new tools — expose them to the agent loop.

        Updates both the live agent config and ``_all_agents`` so that
        sub-agents spawned later also see the new MCP tools.
        """
        # Only expand the live agent's tools if it opted into auto-population.
        # Agents with explicit allowlists are not modified.
        entry = self.config.entrypoint or "default"
        if entry not in self._auto_tools_agents:
            logger.debug("Entrypoint has explicit tools — MCP tools not auto-added")
            return
        current = list(self.agent._config.tools or [])
        new = [t for t in tool_names if t not in current]
        if new:
            updated = current + new
            self.agent._config = self.agent._config.model_copy(update={"tools": updated})
            # Keep _all_agents in sync for agents that opted into auto-populated
            # tools (had tools=None at startup). Agents with explicit allowlists
            # are NOT updated — MCP tools must be added to their config manually.
            for agent_name in self._auto_tools_agents:
                if agent_name in self._all_agents:
                    agent_cfg = self._all_agents[agent_name]
                    agent_tools = agent_cfg.tools or []
                    missing = [t for t in tool_names if t not in agent_tools]
                    if missing:
                        self._all_agents[agent_name] = agent_cfg.model_copy(
                            update={"tools": agent_tools + missing}
                        )
            logger.info(f"Agent tool list updated: +{len(new)} MCP tools")

    async def _spawn_agent(
        self,
        agent_name: str,
        prompt: str,
        *,
        _depth: int = 1,
        _parent_session: str = "cli:local",
        metadata: dict[str, Any] | None = None,
    ) -> str:
        """Spawn a sub-agent with scoped tools, permissions, and depth tracking."""
        # Look up agent from merged agents (cached on self)
        agent_config = self._all_agents.get(agent_name)
        if not agent_config:
            available = [k for k, v in self._all_agents.items() if not v.metadata.get("internal")]
            return f"Error: unknown agent '{agent_name}'. Available: {', '.join(available)}"

        # Spawn depth enforcement
        parent_config = self._all_agents.get("default", self.config.agents.default)
        max_depth = parent_config.max_spawn_depth
        if _depth > max_depth:
            return (
                f"Spawn depth limit reached (depth {_depth}, max {max_depth}). "
                "Cannot delegate further — handle this task directly."
            )

        # Exclude notify + cron always. Exclude spawn at max depth.
        _ALWAYS_EXCLUDED = {"notify", "cron"}
        excluded = _ALWAYS_EXCLUDED.copy()
        if _depth >= max_depth:
            excluded.add("spawn")
        scoped_tools = [t for t in (agent_config.tools or []) if t not in excluded]

        # Create scoped tool registry. If spawn is allowed (depth < max),
        # register a depth-incremented spawn callback for sub-sub-agents.
        scoped_registry = self.tool_registry.scoped_copy(scoped_tools)
        if "spawn" in scoped_tools and scoped_registry.get("spawn") is not None:
            from praestoclaw.agent.tools.spawn import SpawnTool

            next_depth = _depth + 1

            async def _child_spawn(
                name: str, p: str, *, metadata: dict[str, Any] | None = None
            ) -> str:
                return await self._spawn_agent(
                    name,
                    p,
                    _depth=next_depth,
                    _parent_session=_parent_session,
                    metadata=metadata,
                )

            scoped_registry.unregister("spawn")
            scoped_registry.register(SpawnTool(_child_spawn))

        # Fork session for tracking (linked to parent)
        forked_session = self.session_manager.fork(_parent_session)

        sub_agent = AgentLoopV2(
            config=agent_config,
            provider=self._build_failover_provider(agent_config),
            tool_registry=scoped_registry,
            bus=self.bus,
            session_store=self._session_store_v2,
            workspace=self.workspace,
            audit=self.audit,
            hooks=self.hook_manager,
            prompt_mode="minimal",
            memory=self._memory,
        )
        return await sub_agent.run_once(prompt, session_id=forked_session, metadata=metadata)

    # ── Dynamic workspace ────────────────────────────────────────────────

    def switch_workspace(self, new_workspace: Path) -> None:
        """Switch workspace root. Safe because tool calls are sequential."""
        resolved = new_workspace.resolve()
        if not resolved.is_dir():
            raise ValueError(f"Not a directory: {resolved}")
        self.workspace = resolved
        self.sandbox.switch_workspace(resolved)
        self.skill_loader._workspace = resolved
        self.skill_loader.load_all()
        # Update agent loop workspace (cached at init)
        if hasattr(self, "agent") and self.agent:
            self.agent._workspace = resolved
            if hasattr(self.agent, "_prompt_builder"):
                self.agent._prompt_builder._workspace = resolved
        # Update MemoryTool workspace (for relative user_file resolution)
        memory_tool = self.tool_registry.get("memory")
        if memory_tool and hasattr(memory_tool, "_workspace"):
            memory_tool._workspace = resolved

    # ── Run modes ─────────────────────────────────────────────────────────

    def _derive_a2a_display_name(self) -> str:
        """Compute the A2A local-party display name from the card seed."""
        try:
            from praestoclaw.a2a.card_seed import generate_card_seed

            seed = generate_card_seed(name=f"PraestoClaw ({self.config.name})")
            return str(seed.get("name", "")) or ""
        except Exception:
            return ""

    def _generate_a2a_card_seed(self) -> dict[str, Any]:
        """Generate A2A card seed from runtime config."""
        if not self.config.channels.a2a.enabled:
            return {}

        from praestoclaw.a2a.card_seed import generate_card_seed

        # Phase 1: basic card, no skills yet
        return generate_card_seed(
            name=f"PraestoClaw ({self.config.name})",
            description="Local enterprise coding and office agent",
            skills=[],
        )

    async def _start_cloud_if_enabled(self, *, interactive: bool = False) -> None:
        """Auto-connect the cloud channel on startup.

        interactive=False (default):
            Silent credentials only. Skips if no cached token so the user
            is not interrupted. Run `praestoclaw cloud` once first to cache a token.
            Called by run_web_server() only — run_chat() does NOT connect to cloud.

        interactive=True (run_web_server):
            Full login flow — triggers browser/device-code auth when needed,
            matching the behaviour of the explicit `praestoclaw cloud` command.
        """
        from praestoclaw.channels.cloud import CloudChannel

        cloud_cfg = self.config.channels.cloud
        if not cloud_cfg.enabled:
            return
        if not cloud_cfg.url or not cloud_cfg.tenant_id or not cloud_cfg.client_id:
            logger.warning("Cloud channel disabled — missing url/tenant_id/client_id in config")
            return
        if not cloud_cfg.scope:
            cloud_cfg.scope = f"{cloud_cfg.client_id}/.default"
        if self.channel_manager.get(ChannelType.CLOUD) is not None:
            return  # already registered (e.g. by `praestoclaw cloud` command)

        ch = CloudChannel(
            self.bus,
            url=cloud_cfg.url,
            tenant_id=cloud_cfg.tenant_id,
            client_id=cloud_cfg.client_id,
            scope=cloud_cfg.scope,
            transport_mode=cloud_cfg.transport_mode,
            negotiate_url=cloud_cfg.negotiate_url,
            negotiate_timeout_s=cloud_cfg.negotiate_timeout_s,
            client_url_refresh_skew_s=cloud_cfg.client_url_refresh_skew_s,
            login_method=cloud_cfg.login_method,
            login_port=cloud_cfg.login_port,
            allow_from=cloud_cfg.allow_from or None,
            auto_reconnect=cloud_cfg.auto_reconnect,
            reconnect_max=cloud_cfg.reconnect_max,
            bypass_token=cloud_cfg.bypass_token,
            # A2A Phase 1 parameters
            a2a_enabled=self.config.channels.a2a.enabled,
            a2a_instance_id=self._a2a_instance_id,
            # Only pass explicit overrides here. If Runtime fell back to an
            # anonymous instance id before cloud auth, CloudChannel must use
            # the authenticated token identity instead.
            a2a_user_id=self.config.channels.a2a.user_id or cloud_cfg.a2a_user_id,
            a2a_is_active_instance=self.config.channels.a2a.is_active_instance,
            a2a_protocol_version=self.config.channels.a2a.protocol_version,
            a2a_card_seed=self._generate_a2a_card_seed(),
            agent_id_override=cloud_cfg.agent_id_override,
        )
        # Wire the auth provider after construction (os_account/browser need
        # a channel reference for delegated MSAL plumbing).
        from praestoclaw.auth.factory import build_auth_provider

        ch._auth = build_auth_provider(cloud_cfg, channel=ch)
        if not interactive and not ch.has_cached_credentials():
            logger.info(
                "Cloud relay: no cached credentials — run `praestoclaw cloud` once to authenticate"
            )
            return

        ch.set_runtime(self)  # allow admin relay to query Runtime APIs
        # Wire A2A runtime to cloud channel for inbound request dispatch
        if self._a2a_runtime is not None:
            ch.set_a2a_runtime(self._a2a_runtime)
        self.channel_manager.add(ch)
        try:
            await ch.start()
            logger.info("Cloud channel connected automatically")
        except Exception as exc:
            logger.warning("Cloud auto-connect failed: {}", exc)
            try:
                await ch.stop()
            except Exception:
                pass
            self.channel_manager.remove(ChannelType.CLOUD)

    def _resolve_web_owner_oid(self) -> None:
        """Resolve owner_oid for local web JWT enforcement.

        Priority:
        1. Manual config (already set in praestoclaw.yaml)
        2. Cloud channel authenticated OID
        3. Shared Entra app MSAL cache
        4. Any other Entra app MSAL cache (primary, legacy)
        5. Skip and warn
        """
        web_cfg = self.config.channels.web
        if web_cfg.owner_oid:
            logger.debug("owner_oid from config: {}", web_cfg.owner_oid)
            return

        # 2. Cloud channel
        cloud_ch = self.channel_manager.get(ChannelType.CLOUD)
        _cloud_oid = getattr(cloud_ch, "_local_oid", None) if cloud_ch else None
        if _cloud_oid:
            web_cfg.owner_oid = _cloud_oid
            logger.debug("owner_oid from cloud channel: {}", _cloud_oid)
            return

        # 3-5. MSAL caches: shared app → primary/legacy → Teams sideload
        def _oid_from_msal_cache(client_id: str, cache_path: Path | None = None) -> str | None:
            """Extract OID from an MSAL token cache file."""
            try:
                import msal

                if cache_path is None:
                    from praestoclaw.mcp.auth import _load_msal_cache

                    cache, _ = _load_msal_cache(client_id)
                else:
                    from praestoclaw.security.secrets import decrypt_at_rest

                    cache = msal.SerializableTokenCache()
                    if cache_path.exists():
                        raw = decrypt_at_rest(cache_path.read_bytes())
                        if raw:
                            cache.deserialize(raw.decode("utf-8"))

                app = msal.PublicClientApplication(
                    client_id,
                    authority="https://login.microsoftonline.com/organizations",
                    token_cache=cache,
                )
                accounts = app.get_accounts()
                if accounts:
                    oid_val: str | None = accounts[0].get("local_account_id")
                    return oid_val
            except Exception:
                pass
            return None

        from praestoclaw.mcp.defaults import SHARED_ENTRA_CLIENT_ID
        from praestoclaw.utils.helpers import get_auth_dir

        # 3. Shared app
        oid = _oid_from_msal_cache(SHARED_ENTRA_CLIENT_ID)
        if oid:
            web_cfg.owner_oid = oid
            logger.debug("owner_oid from shared app cache: {}", oid)
            return

        # 4a. Primary and legacy client IDs
        candidates = [web_cfg.entra_client_id, *web_cfg.entra_client_id_legacy]
        for cid in candidates:
            if not cid or cid == SHARED_ENTRA_CLIENT_ID:
                continue
            oid = _oid_from_msal_cache(cid)
            if oid:
                web_cfg.owner_oid = oid
                logger.debug("owner_oid from app {} cache: {}", cid[:8], oid)
                return

        # 4b. Teams sideload cache (new path, then legacy fallback)
        oid = _oid_from_msal_cache(
            "7ea7c24c-b1f6-4a20-9d11-9ae12e9e7ac0",
            cache_path=get_auth_dir() / "token_cache_7ea7c24c.bin",
        ) or _oid_from_msal_cache(
            "7ea7c24c-b1f6-4a20-9d11-9ae12e9e7ac0",
            cache_path=get_auth_dir() / "teams_sideload.bin",
        )
        if oid:
            web_cfg.owner_oid = oid
            logger.debug("owner_oid from Teams sideload cache: {}", oid)
            return

        # 5. None found
        logger.warning("No owner_oid resolved — local web JWT will accept any valid tenant user")

    def _schedule_startup_update_check(self) -> None:
        """Fire-and-forget background update check on startup.

        Respects the same throttle as heartbeat: skips if checked within
        18 hours. Logs result at INFO (no user notification).

        Also runs :meth:`_notify_version_change_if_any` once on every
        startup, which compares the running version against the last
        value persisted to ``runtime_info.json`` and pushes a Teams
        notification when they differ (i.e. an upgrade has completed
        since the daemon was last running).
        """

        async def _check() -> None:
            import time

            logger.debug("[startup-check] task entered, sleeping 5s")
            await asyncio.sleep(5)  # let startup settle
            logger.debug("[startup-check] woke; running version-change notify")

            # Version-change notify runs every startup, independent of
            # the daily check-update throttle below.
            try:
                await self._notify_version_change_if_any()
                logger.debug("[startup-check] version-change notify returned")
            except Exception:
                logger.exception("version-change notify failed")

            try:
                from praestoclaw.utils.helpers import get_data_dir
                from praestoclaw.utils.update import check_update

                marker = get_data_dir() / ".last_update_check"
                if marker.exists():
                    age_hours = (time.time() - marker.stat().st_mtime) / 3600
                    if age_hours < 18:
                        return

                status = await asyncio.to_thread(check_update)
                # check_update() writes .last_update_check on success
                if not status.up_to_date:
                    logger.info("Update available: {}", status.summary.split("\n")[0])
            except Exception:
                pass  # best-effort, never block startup

        # Strong-ref the task in self._background_tasks so the event loop's
        # weak-ref behavior doesn't GC _check() mid-run. Without this, MCP
        # warm-up's heavy alloc churn during the await asyncio.sleep(5) above
        # was silently collecting the task before it could run the version
        # notify or update check (verified empirically — marker untouched
        # across full daemon startup).
        task = asyncio.create_task(_check(), name="startup-update-check")
        self._background_tasks.add(task)
        task.add_done_callback(self._background_tasks.discard)
        logger.debug(
            "[startup-check] scheduled startup-update-check task (id={}, bg_tasks={})",
            id(task),
            len(self._background_tasks),
        )

    async def _notify_version_change_if_any(self) -> None:
        """Push a Teams notification when this daemon was started by an update.

        Two-signal model — the forced marker covers cases the passive
        version-diff cannot:

        1. **Forced** — ``~/.praestoclaw/.update_pending`` exists. Written
           by ``cli/update._write_update_pending_marker`` on the bot
           self-update path right before the detached worker spawns.
           Always notify; marker is deleted only after a successful send.
           If the cloud channel is unavailable the marker is preserved so
           the next startup retries. If no ``owner_oid`` can be resolved
           the marker is dropped immediately so it doesn't loop forever.
           Catches mirror reinstalls (same version string) and the very
           first upgrade after this feature lands (no recorded version
           yet).
        2. **Passive** — no forced marker, but the running
           ``importlib.metadata`` version differs from the
           ``version`` field in ``~/.praestoclaw/runtime_info.json``.
           Notify once per real version change. Covers all non-bot
           upgrade paths (`pip install -U`, container rebuild, CI
           redeploy, etc.).

        Silent paths (no exception, no notify):

        * First-ever start (no marker, no version-change) — just record
          the current version in ``runtime_info.json``.
        * Cloud channel missing or not connected within 30s — log only;
          forced marker is preserved so the next startup retries.
        * No owner_oid resolved (no cloud auth, no manual override) —
          log only; forced marker is dropped so it doesn't fire forever
          on every restart.
        """
        import importlib.metadata

        from praestoclaw.bus.events import ChannelType
        from praestoclaw.utils.helpers import get_data_dir
        from praestoclaw.utils.runtime_info import (
            get_last_known_version,
            set_last_known_version,
        )

        try:
            current = importlib.metadata.version("praestoclaw")
        except Exception:
            return  # can't determine current — bail silently

        data_dir = get_data_dir()
        pending_marker = data_dir / ".update_pending"

        # Resolve "previous" version. Priority:
        #   1. ``.update_pending`` — written by the bot self-update path
        #      (cli/update._write_update_pending_marker). Forces a notify
        #      even when the version string is unchanged (mirror reinstall)
        #      AND on the very first upgrade after this feature lands
        #      (when no version is recorded yet).
        #   2. ``runtime_info.json[version]`` — passive version-diff
        #      fallback for any other upgrade path (`pip install -U`, CI
        #      redeploy, container rebuild, etc.).
        forced = pending_marker.exists()
        previous: str | None = None
        if forced:
            try:
                previous = pending_marker.read_text(encoding="utf-8").strip() or None
            except OSError:
                previous = None
        else:
            previous = get_last_known_version()

        # Always advance the persisted version so the passive path
        # converges on the new version even when no notify fires.
        try:
            set_last_known_version(current)
        except Exception as exc:
            logger.debug("Could not persist runtime_info.version: {}", exc)

        # Decide whether to notify. With the forced marker we ALWAYS notify
        # (even previous == current — that's the mirror-reinstall case);
        # without it we fall back to the version-diff rule.
        if forced:
            logger.info(
                "Forced version-update notify via .update_pending (v{} -> v{})",
                previous or "?",
                current,
            )
        elif not previous or previous == current:
            return  # first run or no change, no forced signal

        if not forced:
            logger.info("Detected version change: {} -> {}", previous, current)

        cloud = self.channel_manager.get(ChannelType.CLOUD)
        if cloud is None:
            logger.debug("No cloud channel registered; skipping version-update notify")
            # Forced marker stays on disk so the next startup (with cloud
            # available) still fires the notification.
            return

        # Cloud channel may still be connecting when the startup hook fires
        # (5s settle delay before this runs). Wait up to ~30s for the WSS
        # handshake. If it never completes, leave the forced marker in
        # place so the next startup can still notify.
        for _ in range(30):
            if getattr(cloud, "is_connected", False):
                break
            await asyncio.sleep(1)
        if not getattr(cloud, "is_connected", False):
            logger.info(
                "Cloud channel not connected within 30s; skipping version-update notify "
                "(v{} -> v{})",
                previous or "?",
                current,
            )
            return

        # Resolve the single notification target — the daemon's owner.
        # Priority:
        #   1. cloud channel's authenticated _local_oid (most authoritative;
        #      derived from the MSAL token claims)
        #   2. config.channels.web.owner_oid (manual override)
        # We deliberately do NOT fall back to fre_state.user_activity (which
        # holds *all* OIDs that ever sent a message — including stale test
        # fixtures and other people who DM'd the bot). Broadcasting an update
        # message to that whole set is both noisy and a privacy bug.
        owner_oid = getattr(cloud, "_local_oid", None) or self.config.channels.web.owner_oid
        if not owner_oid:
            logger.info(
                "No owner_oid resolved; skipping version-update notify (v{} -> v{})",
                previous or "?",
                current,
            )
            # Drop the forced marker — without an owner we can never deliver
            # this and would otherwise loop forever on every restart.
            if forced:
                try:
                    pending_marker.unlink()
                except OSError:
                    pass
            return

        if forced and previous and previous != current:
            msg = f"✅ PraestoClaw updated: v{previous} → v{current}"
        elif forced:
            msg = f"✅ PraestoClaw reinstalled: v{current}"
        else:
            msg = f"✅ PraestoClaw updated: v{previous} → v{current}"

        any_sent = False
        try:
            await cloud.send(
                f"system:version-update:{owner_oid}",
                msg,
                push_target="teams",
                keep_context=True,
            )
        except Exception as exc:
            logger.warning("Version-update notify failed for owner={}: {}", owner_oid, exc)
        else:
            any_sent = True
            logger.info(
                "Notified version update (v{} -> v{}) to owner={}",
                previous or "?",
                current,
                owner_oid,
            )

        # Consume the forced marker only after at least one successful
        # send — otherwise leave it for the next startup.
        if forced and any_sent:
            try:
                pending_marker.unlink()
            except OSError as exc:
                logger.debug("Could not remove .update_pending marker: {}", exc)

    async def _ensure_v2_store_initialized(self) -> None:
        """Initialize v2 SQLite session store + auto-migrate from JSONL if needed."""
        store = self._session_store_v2
        if store._db is not None:
            return  # already initialized
        await store.initialize()
        # Auto-migrate JSONL on first v2 startup
        jsonl_dir = get_data_dir() / "sessions"
        marker = get_data_dir() / ".migrated_to_sqlite"
        if jsonl_dir.exists() and not marker.exists():
            from praestoclaw.session.migration import migrate_jsonl_to_sqlite

            result = await migrate_jsonl_to_sqlite(jsonl_dir, store)
            logger.info("Session migration: {}", result)
            marker.touch()

    async def run_prompt(self, prompt: str, session_id: str | None = None) -> str:
        """Run a single prompt and return the response."""
        await self._ensure_v2_store_initialized()
        return await self.agent.run_once(prompt, session_id)

    async def run_chat(
        self,
        *,
        local: bool = True,
        target_agent_id: str | None = None,
    ) -> None:
        """Start interactive TUI chat."""
        if not local:
            cloud_cfg = self.config.channels.cloud
            if not cloud_cfg.url or not cloud_cfg.tenant_id or not cloud_cfg.client_id:
                raise RuntimeError(
                    "Cloud channel not configured. Set url, client_id, and tenant_id "
                    "under channels.cloud in your config."
                )
            if not cloud_cfg.scope:
                cloud_cfg.scope = f"{cloud_cfg.client_id}/.default"

            backend = CloudTuiBackend.from_cloud_config(
                cloud_cfg,
                client_version=__version__,
                target_agent_id=target_agent_id,
            )

            async def conversation_id_factory() -> str:
                return await backend.current_conversation_id()

            shell = TuiShell(
                backend=backend,
                conversation_id_factory=conversation_id_factory,
                prompt=self.config.channels.cli.prompt,
            )
            await shell.run()
            return
        await self._ensure_v2_store_initialized()

        # Warm-up MCP servers in background (non-blocking)
        if self._mcp_manager:
            asyncio.create_task(self._mcp_manager.warm_up())

        self._schedule_startup_update_check()

        from praestoclaw.channels.turn.kernel import ChannelTurnKernel

        kernel = ChannelTurnKernel(
            agent_id=self.config.agents.default.name,
            runtime=AgentLoopRuntimeAdapter(self.agent),
        )

        async def ensure_session(session_key: str, logical_channel: str, sender_id: str) -> None:
            await self._session_store_v2.ensure_session(session_key, logical_channel, sender_id)

        backend_local = HostBackedTuiBackend(kernel=kernel, ensure_session=ensure_session)

        async def local_conversation_id_factory() -> str:
            return str(uuid.uuid4())

        shell = TuiShell(
            backend=backend_local,
            conversation_id_factory=local_conversation_id_factory,
            prompt=self.config.channels.cli.prompt,
        )

        try:
            await shell.run()
        finally:
            await self.agent.stop()
            await _quiet_stop(self._session_store_v2.close(), "session_store")

    async def run_web_server(self, on_started: Callable[[int], None] | None = None) -> None:
        """Start Web Server Mode (multi-channel HTTP server)."""
        await self._ensure_v2_store_initialized()
        from praestoclaw.channels.web import WebChannel
        from praestoclaw.web.server import WebServer

        # Create and register WebChannel with the bus
        web_channel = WebChannel(self.bus)
        self.channel_manager.add(web_channel)
        await web_channel.start()
        await self._start_cloud_if_enabled(interactive=True)

        # Resolve owner_oid for local web JWT enforcement.
        # Priority: 1) manual config  2) cloud channel  3) shared app cache
        #           4) other Entra app caches  5) skip + warn
        self._resolve_web_owner_oid()

        self._web_server = WebServer(self.config.channels.web, self, on_started=on_started)
        self._web_server.set_web_channel(web_channel)

        # Warm-up MCP servers in background (non-blocking)
        if self._mcp_manager:
            asyncio.create_task(self._mcp_manager.warm_up())

        agent_task = asyncio.create_task(self.agent.start())
        self._schedule_startup_update_check()

        if self.scheduler:
            self.scheduler.set_agent_loop(self.agent)  # type: ignore[arg-type]
            await self.scheduler.start()

        try:
            await self._web_server.start()
        finally:
            if self.scheduler:
                await _quiet_stop(self.scheduler.stop(), "scheduler")
            # NOTE: stop_all() below also stops web_channel since it was added
            # to channel_manager — don't double-stop here.
            await _quiet_stop(self.agent.stop(), "agent")
            if self._mcp_manager:
                await _quiet_stop(self._mcp_manager.disconnect_all(), "mcp")
            await _quiet_stop(self.channel_manager.stop_all(), "channels")
            agent_task.cancel()
            try:
                await asyncio.wait_for(agent_task, timeout=_SHUTDOWN_TIMEOUT)
            except (asyncio.CancelledError, TimeoutError):
                pass
            await _quiet_stop(self._session_store_v2.close(), "session_store")

    run_gateway = run_web_server  # deprecated alias

    async def run_cloud(self) -> None:
        """Cloud relay mode — cloud channel already started by the CLI command.

        Starts the agent loop and keeps the process alive until interrupted.
        The CloudChannel (registered via channel_manager.add before this call)
        handles WebSocket reconnection and message routing autonomously.
        """
        await self._ensure_v2_store_initialized()
        agent_task = asyncio.create_task(self.agent.start(), name="agent-loop")
        self._schedule_startup_update_check()

        if self.scheduler:
            self.scheduler.set_agent_loop(self.agent)  # type: ignore[arg-type]
            await self.scheduler.start()

        logger.info("Agent loop running — waiting for messages from Cloud Gateway…")

        try:
            # Block until cancelled (Ctrl+C)
            await asyncio.Event().wait()
        except (asyncio.CancelledError, KeyboardInterrupt):
            pass
        finally:
            if self.scheduler:
                await _quiet_stop(self.scheduler.stop(), "scheduler")
            await _quiet_stop(self.agent.stop(), "agent")
            if self._mcp_manager:
                await _quiet_stop(self._mcp_manager.disconnect_all(), "mcp")
            await _quiet_stop(self.channel_manager.stop_all(), "channels")
            agent_task.cancel()
            try:
                await asyncio.wait_for(agent_task, timeout=_SHUTDOWN_TIMEOUT)
            except (asyncio.CancelledError, TimeoutError):
                pass
            await _quiet_stop(self._session_store_v2.close(), "session_store")

    async def shutdown(self) -> None:
        """Graceful shutdown of all subsystems."""
        await self.agent.stop()
        await self.channel_manager.stop_all()
        if self._web_server:
            await self._web_server.stop()
        # Disconnect MCP servers
        if self._mcp_manager:
            await self._mcp_manager.disconnect_all()
        if self._copilot_service:
            await self._copilot_service.stop()
        if self._claude_code_service:
            await self._claude_code_service.stop()
        if self._memory:
            self._memory.close()
        # Close v2 session store (aiosqlite keeps a background thread alive)
        await self._session_store_v2.close()
        logger.info("PraestoClaw runtime shut down")
