"""Local store for Teams conversation references.

Stores {oid: {service_url, conversation_id}} as a single JSON secret
via the existing SecretStore backend.
"""

from __future__ import annotations

import json
from urllib.parse import urlparse

from loguru import logger

from praestoclaw.security.secrets import get_secret, set_secret

_SECRET_KEY = "teams_conv_refs"

_KNOWN_SUFFIXES = (
    ".microsoft.com",
    ".microsoft.us",
    ".microsoft",
    ".skype.com",
    ".botframework.com",
    ".trafficmanager.net",
)


class ConvRefStore:
    """In-memory cache backed by SecretStore for Teams conversation references."""

    def __init__(self) -> None:
        self._cache: dict[str, dict[str, str]] | None = None

    def _load(self) -> dict[str, dict[str, str]]:
        if self._cache is not None:
            return self._cache
        try:
            raw = get_secret(_SECRET_KEY)
            if raw:
                parsed = json.loads(raw)
                if isinstance(parsed, dict):
                    self._cache = {
                        k: v
                        for k, v in parsed.items()
                        if isinstance(v, dict) and "service_url" in v and "conversation_id" in v
                    }
                    return self._cache
        except Exception as exc:
            logger.warning("Failed to load conv_ref store: {}", exc)
        self._cache = {}
        return self._cache

    def get(self, oid: str) -> dict[str, str] | None:
        """Return stored conv_ref for *oid*, or ``None``."""
        return self._load().get(oid)

    def upsert(self, oid: str, service_url: str, conversation_id: str) -> None:
        """Store or update a conv_ref. Only writes when values change."""
        if not self._is_known_host(service_url):
            logger.warning(
                "conv_ref service_url has unknown host: {} — storing anyway, "
                "server will validate or fallback",
                service_url,
            )

        data = self._load()
        existing = data.get(oid)
        if (
            existing
            and existing.get("service_url") == service_url
            and existing.get("conversation_id") == conversation_id
        ):
            return  # unchanged — skip write

        data[oid] = {
            "service_url": service_url,
            "conversation_id": conversation_id,
        }
        self._persist()
        logger.debug("conv_ref updated for oid={}", oid)

    @staticmethod
    def _is_known_host(url: str) -> bool:
        """Check if service_url host matches known Microsoft domains."""
        try:
            host = urlparse(url).hostname or ""
            return any(host.endswith(s) for s in _KNOWN_SUFFIXES)
        except Exception:
            return False

    def remove(self, oid: str) -> None:
        """Remove a conv_ref (e.g. on 403 blocked/uninstalled)."""
        data = self._load()
        if data.pop(oid, None) is not None:
            self._persist()
            logger.debug("conv_ref removed for oid={}", oid)

    def _persist(self) -> None:
        if self._cache is None:
            return
        try:
            set_secret(_SECRET_KEY, json.dumps(self._cache, ensure_ascii=False))
        except Exception as exc:
            logger.error("Failed to persist conv_ref store: {}", exc)
