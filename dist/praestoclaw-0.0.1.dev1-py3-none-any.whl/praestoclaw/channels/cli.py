"""
CLI channel — interactive REPL for local terminal use.
"""

from __future__ import annotations

import asyncio
import sys
from typing import Any

from prompt_toolkit.completion import Completer, Completion
from prompt_toolkit.document import Document
from rich.console import Console

from praestoclaw.bus.events import EventType, OutboundMessage, StreamingChunk
from praestoclaw.bus.queue import MessageBus
from praestoclaw.channels.base import BaseChannel
from praestoclaw.config.schema import ChannelType

console = Console()

_SLASH_COMMANDS = [
    ("/new", "Clear session, start fresh"),
    ("/help", "Show all available commands"),
    ("/status", "Show agent status and session info"),
    ("/memory", "Show MEMORY.md content"),
    ("/tools", "List available tools"),
    ("/skills", "List loaded skills"),
    ("/history", "Show last 10 messages in session"),
    ("/history 20", "Show last 20 messages in session"),
    ("/model", "Show current model"),
    ("/exit", "Exit the REPL"),
]


class _SlashCompleter(Completer):
    def get_completions(self, document: Document, complete_event: Any):  # type: ignore[override]
        text = document.text_before_cursor
        if not text.startswith("/"):
            return
        for cmd, desc in _SLASH_COMMANDS:
            if cmd.startswith(text):
                yield Completion(cmd[len(text) :], display=cmd, display_meta=desc)


class CLIChannel(BaseChannel):
    """Terminal-based interactive channel."""

    def __init__(self, bus: MessageBus, prompt: str = "you> ") -> None:
        super().__init__(bus)
        self._prompt = prompt
        self._running = False
        self._in_repl = False
        self._streaming = False

    @property
    def name(self) -> str:
        return ChannelType.CLI

    @property
    def is_connected(self) -> bool:
        """True only when the interactive REPL is running."""
        return self._in_repl

    async def start(self) -> None:
        self._running = True

    async def stop(self) -> None:
        self._running = False

    async def send(self, channel_id: str, content: str, **kwargs: Any) -> None:
        # Use prompt_toolkit's print_formatted_text so that coloring works on
        # Windows via Win32Output (WinAPI), not raw ANSI bytes which break when
        # patch_stdout is active and ESC appears as '?'.
        try:
            import html as _html

            from prompt_toolkit.formatted_text import HTML
            from prompt_toolkit.shortcuts import print_formatted_text

            # Escape HTML special chars so agent output isn't misinterpreted as tags.
            safe = _html.escape(content)
            print_formatted_text(HTML(f"\n<b><green>assistant&gt;</green></b> {safe}\n"))
        except (ImportError, ValueError):
            # prompt_toolkit unavailable or output incompatibility — plain fallback.
            sys.stdout.write(f"\nassistant> {content}\n\n")
            sys.stdout.flush()

    async def _handle_outbound(self, msg: OutboundMessage | StreamingChunk) -> None:
        """Handle both full messages and streaming chunks from the bus."""
        if isinstance(msg, StreamingChunk) and msg.channel == self.name:
            if msg.done:
                if self._streaming:
                    sys.stdout.write("\n\n")
                    sys.stdout.flush()
                    self._streaming = False
            else:
                if not self._streaming:
                    sys.stdout.write("\nassistant> ")
                    self._streaming = True
                sys.stdout.write(msg.content)
                sys.stdout.flush()

    async def run_repl(self) -> None:
        """Run the interactive read-eval-print loop."""
        self._running = True
        self._in_repl = True
        try:
            await self._run_repl_inner()
        finally:
            self._in_repl = False

    async def _run_repl_inner(self) -> None:
        """Inner REPL loop — separated so run_repl can use try/finally."""
        self._bus.on_outbound(self._handle_outbound)
        self._bus.events.emit(EventType.CHANNEL_CONNECTED, {"channel": self.name})
        console.print("[bold]PraestoClaw Chat[/bold] — type /exit to quit, /new to reset\n")

        # Try prompt_toolkit for rich input (autocomplete, history).
        # Fall back to plain input() on incompatible terminals (Git Bash, Cygwin, etc.).
        use_prompt_toolkit = True
        session: Any = None
        try:
            import os as _os

            from prompt_toolkit import PromptSession
            from prompt_toolkit.history import FileHistory
            from prompt_toolkit.key_binding import KeyBindings
            from prompt_toolkit.patch_stdout import patch_stdout as _patch_stdout

            from praestoclaw.utils.helpers import get_data_dir

            _kb = KeyBindings()

            @_kb.add("escape", "enter")  # Alt+Enter → newline
            def _newline(event: Any) -> None:
                event.current_buffer.insert_text("\n")

            _history_path = get_data_dir() / "cli_history"
            if _os.name == "posix":
                try:
                    if not _history_path.exists():
                        fd = _os.open(_history_path, _os.O_CREAT | _os.O_WRONLY, 0o600)
                        _os.close(fd)
                    else:
                        _os.chmod(_history_path, 0o600)
                except OSError:
                    pass

            session = PromptSession(
                self._prompt,
                completer=_SlashCompleter(),
                complete_while_typing=True,
                history=FileHistory(str(_history_path)),
                key_bindings=_kb,
                multiline=False,
            )
            # Probe compatibility with a dry-run (catches xterm-256color on Windows)
            import prompt_toolkit.output

            prompt_toolkit.output.create_output()
        except Exception:
            use_prompt_toolkit = False
            console.print("[dim](basic input mode — autocomplete unavailable)[/dim]\n")

        while self._running:
            try:
                if use_prompt_toolkit and session is not None:
                    try:
                        with _patch_stdout():
                            text = await asyncio.get_event_loop().run_in_executor(
                                None, lambda: session.prompt()
                            )
                    except Exception:
                        # Runtime failure (e.g. terminal resized to incompatible type)
                        use_prompt_toolkit = False
                        console.print("[dim](switching to basic input mode)[/dim]\n")
                        continue

                else:
                    text = await asyncio.get_event_loop().run_in_executor(
                        None, lambda: input(self._prompt)
                    )
            except (EOFError, KeyboardInterrupt):
                break

            text = text.strip()
            if not text:
                continue
            if text in ("/exit", "/quit"):
                break

            await self._handle_message(
                channel_id="terminal",
                sender_id="local",
                sender_name="User",
                content=text,
            )

            # Wait for the response to be sent (give agent time)
            await asyncio.sleep(0.1)
