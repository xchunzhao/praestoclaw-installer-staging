from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol

from agent_gateway_protocol.agent_link.v1 import InitiatedBy, LogicalChannel

from praestoclaw.channels.turn.admission import (
    AdmissionDecision,
    AdmissionKind,
    AdmissionPolicy,
    AllowAllAdmissionPolicy,
)
from praestoclaw.channels.turn.context import (
    ChannelTurnEnvelope,
    ConversationFacts,
    MessageFacts,
    ReplyPlanFacts,
    RouteFacts,
    SenderFacts,
    SourceFacts,
    SupervisionFacts,
    TurnContext,
)
from praestoclaw.host.hook_runner import HookRunner, NoopHookRunner
from praestoclaw.host.runtime_contracts import (
    AgentRuntimeProtocol,
    AgentRuntimeRequest,
    AgentRuntimeResult,
    TurnProvenanceSummary,
)


class SessionResolver(Protocol):
    def resolve_session_key(self, envelope: ChannelTurnEnvelope) -> str: ...


class DefaultSessionResolver:
    def resolve_session_key(self, envelope: ChannelTurnEnvelope) -> str:
        return ":".join(
            [
                envelope.logical_channel,
                envelope.sender_id,
                envelope.conversation_id,
            ]
        )


@dataclass(frozen=True, slots=True)
class ChannelTurnResult:
    admission: AdmissionDecision
    context: TurnContext | None = None
    runtime_request: AgentRuntimeRequest | None = None
    runtime_result: AgentRuntimeResult | None = None


class ChannelTurnKernel:
    def __init__(
        self,
        *,
        agent_id: str,
        runtime: AgentRuntimeProtocol,
        admission_policy: AdmissionPolicy | None = None,
        session_resolver: SessionResolver | None = None,
        hooks: HookRunner | None = None,
    ) -> None:
        self._agent_id = agent_id
        self._runtime = runtime
        self._admission_policy = admission_policy or AllowAllAdmissionPolicy()
        self._session_resolver = session_resolver or DefaultSessionResolver()
        self._hooks = hooks or NoopHookRunner()

    async def process(self, envelope: ChannelTurnEnvelope) -> ChannelTurnResult:
        await self._hooks.observe("turn.received", envelope)

        admission = await self._admission_policy.decide(envelope)
        await self._hooks.gate("turn.preflight", admission)
        if admission.kind != AdmissionKind.DISPATCH:
            return ChannelTurnResult(admission=admission)

        context = self._resolve_context(envelope)
        context = await self._hooks.modify("supervision.plan", context)
        await self._hooks.observe("turn.recorded", context)

        claimed = await self._hooks.claim("turn.before_dispatch", context)
        if claimed is not None:
            return ChannelTurnResult(
                admission=AdmissionDecision.handled("claimed", claimed), context=context
            )

        runtime_request = self._build_runtime_request(context)
        runtime_result = await self._runtime.run_once(runtime_request)
        await self._hooks.observe("turn.finalized", context)

        return ChannelTurnResult(
            admission=admission,
            context=context,
            runtime_request=runtime_request,
            runtime_result=runtime_result,
        )

    def _resolve_context(self, envelope: ChannelTurnEnvelope) -> TurnContext:
        session_key = self._session_resolver.resolve_session_key(envelope)
        human_channels = {
            LogicalChannel.LOCAL_WEBCHAT.value,
            LogicalChannel.LOCAL_TUI.value,
        }
        human_initiated = envelope.logical_channel in human_channels
        initiated_by = InitiatedBy.HUMAN.value if human_initiated else InitiatedBy.SYSTEM.value
        source_scope = "local" if human_initiated else "system"
        requires_human_visibility = not human_initiated
        return TurnContext(
            trace_id=envelope.trace_id,
            source=SourceFacts(
                physical_ingress=envelope.physical_ingress,
                logical_channel=envelope.logical_channel,
                source_scope=source_scope,
            ),
            sender=SenderFacts(sender_id=envelope.sender_id),
            conversation=ConversationFacts(conversation_id=envelope.conversation_id),
            route=RouteFacts(
                agent_id=self._agent_id,
                session_key=session_key,
                route_identity=str(envelope.metadata.get("connection_id") or session_key),
            ),
            message=MessageFacts(
                normalized_content=envelope.content,
                attachments=envelope.attachments,
            ),
            reply_plan=ReplyPlanFacts(
                delivery_adapter=envelope.physical_ingress,
                logical_channel=envelope.logical_channel,
                supports_streaming=bool(envelope.metadata.get("supports_streaming", False)),
                supports_cards=bool(envelope.metadata.get("supports_cards", False)),
            ),
            supervision=SupervisionFacts(
                initiated_by=initiated_by,
                human_initiated=human_initiated,
                requires_human_visibility=requires_human_visibility,
            ),
            metadata={"envelope_metadata": dict(envelope.metadata)},
        )

    @staticmethod
    def _build_runtime_request(context: TurnContext) -> AgentRuntimeRequest:
        return AgentRuntimeRequest(
            agent_id=context.route.agent_id,
            session_id=context.route.session_key,
            user_content=context.message.normalized_content,
            attachments=context.message.attachments,
            runtime_policy={"route_identity": context.route.route_identity},
            turn_provenance=TurnProvenanceSummary(
                initiated_by=InitiatedBy(context.supervision.initiated_by),
                human_initiated=context.supervision.human_initiated,
                logical_channel=context.source.logical_channel,
                trust_boundary=context.source.source_scope,
                supervision_required=context.supervision.requires_human_visibility,
                reply_constraints={
                    "supports_streaming": context.reply_plan.supports_streaming,
                    "supports_cards": context.reply_plan.supports_cards,
                },
            ),
            supervision_policy={
                "requires_human_visibility": context.supervision.requires_human_visibility,
                "supervisor_route": context.supervision.supervisor_route,
            },
            memory_context={},
            cancellation_token=None,
            stream_sink=None,
        )
