from __future__ import annotations

from typing import Protocol

from praestoclaw.channels.turn.context import ChannelTurnEnvelope, TurnContext


class ChannelTurnAdapter(Protocol):
    logical_channel: str
    physical_ingress: str

    async def ingest(self, raw_event: object) -> ChannelTurnEnvelope: ...


class DeliveryAdapter(Protocol):
    async def deliver(self, reply: object, context: TurnContext) -> None: ...
