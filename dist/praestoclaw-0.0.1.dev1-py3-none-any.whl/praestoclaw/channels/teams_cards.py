"""
Adaptive Card builders for the Teams First Run Experience.

Every card is a plain dict that the Cloud Gateway will wrap into a
``{"type": "message", "attachments": [...]}`` Bot Framework activity
(see ``security/approval_format.py:TeamsApprovalFormatter`` for the
canonical wrapper). Keeping the builders pure dict-returning functions
means they're trivial to unit-test and easy to inspect in code review.

Naming discipline (see design doc):

* The product name is **PraestoClaw** \u2014 *not* "Praesto" alone.
* The mascot in user-facing copy is **\u9f99\u867e** (not \u9ccc\u867e).
* The welcome greeting is in Chinese; everything else stays bilingual
  on a per-line basis where it helps clarity.
"""

from __future__ import annotations

from typing import Any

# Bot Framework Adaptive Card content type \u2014 used by the gateway.
ADAPTIVE_CARD_CONTENT_TYPE = "application/vnd.microsoft.card.adaptive"

# Schema version. v1.4 is the floor we test against in Teams desktop /
# web / mobile; v1.5+ has features (e.g. ``Action.Execute``) that older
# Teams clients ignore silently.
ADAPTIVE_CARD_SCHEMA = "http://adaptivecards.io/schemas/adaptive-card.json"
ADAPTIVE_CARD_VERSION = "1.4"


def _card_envelope(
    body: list[dict[str, Any]], actions: list[dict[str, Any]] | None = None
) -> dict[str, Any]:
    """Wrap *body* and *actions* into a v1.4 Adaptive Card document."""
    card: dict[str, Any] = {
        "type": "AdaptiveCard",
        "$schema": ADAPTIVE_CARD_SCHEMA,
        "version": ADAPTIVE_CARD_VERSION,
        "body": body,
    }
    if actions:
        card["actions"] = actions
    return card


def wrap_for_teams(card: dict[str, Any]) -> dict[str, Any]:
    """Wrap an Adaptive Card dict in the Bot Framework activity envelope.

    The cloud channel sends the result as ``json.dumps(...)`` content
    via ``CloudChannel.send(..., push_target='teams', keep_context=...)``,
    matching the path used by ``TeamsApprovalFormatter``.
    """
    return {
        "type": "message",
        "attachments": [
            {
                "contentType": ADAPTIVE_CARD_CONTENT_TYPE,
                "content": card,
            }
        ],
    }


# ---------------------------------------------------------------------------
# Welcome card  \u2014  shown on the user's very first message in Teams.
# ---------------------------------------------------------------------------


def build_welcome_card(first_name: str | None = None) -> dict[str, Any]:
    """Greet the user in Chinese and offer two next actions.

    Two buttons only \u2014 we removed "\u6211\u7684\u8bbe\u7f6e" because the user's Teams client
    might run on a different machine than their PraestoClaw daemon
    (``localhost:3004`` deep links would 404).
    """
    name = (first_name or "").strip() or "\u540c\u5b66"
    body: list[dict[str, Any]] = [
        {
            "type": "TextBlock",
            "text": f"\u4f60\u597d {name}\uff0c\u6211\u662f PraestoClaw",
            "weight": "Bolder",
            "size": "Large",
            "wrap": True,
        },
        {
            "type": "TextBlock",
            # 你的自主 AI 队友，很高兴和你一起工作。
            "text": "\u4f60\u7684\u81ea\u4e3b AI \u961f\u53cb\uff0c\u5f88\u9ad8\u5174\u548c\u4f60\u4e00\u8d77\u5de5\u4f5c\u3002",
            "isSubtle": True,
            "spacing": "Small",
            "wrap": True,
        },
    ]
    actions: list[dict[str, Any]] = [
        {
            "type": "Action.Submit",
            "title": "\U0001f4da \u6211\u80fd\u505a\u4ec0\u4e48",
            # ``msteams.imBack`` makes Teams treat the click as if the user
            # typed ``value`` into the compose box and sent it. No consent
            # dialog, no Activity.Value JSON \u2014 the bot just sees a regular
            # text message and the agent's FRE dispatcher matches on the
            # text content.
            "data": {
                "msteams": {
                    "type": "imBack",
                    "value": "\u4ecb\u7ecd\u4e00\u4e0b\u4f60\u80fd\u505a\u4ec0\u4e48",
                },
            },
        },
        {
            "type": "Action.Submit",
            "title": "\U0001f99e \u8bd5\u8bd5 A2A",
            "data": {
                "msteams": {
                    "type": "imBack",
                    "value": "\u5e26\u6211\u770b\u4e00\u4e0b A2A \u600e\u4e48\u7528",
                },
            },
        },
    ]
    return _card_envelope(body, actions)


# ---------------------------------------------------------------------------
# Capability card  \u2014  "what can you do?"
# ---------------------------------------------------------------------------


def build_capability_card(starter_prompts: list[dict[str, Any]] | None = None) -> dict[str, Any]:
    """Quick capability tour rendering whichever starter prompts the caller passes.

    The per-channel cap (web = uncapped, teams = 6) lives in
    ``praestoclaw.defaults.starter_prompts._CHANNEL_DEFAULT_LIMITS``;
    this card is intentionally a dumb renderer so the same builder can
    serve future channels with different limits.
    """
    body: list[dict[str, Any]] = [
        {
            "type": "TextBlock",
            "text": "\u6211\u80fd\u5e2e\u4f60\u505a\u4ec0\u4e48",
            "weight": "Bolder",
            "size": "Medium",
            "wrap": True,
        },
        {
            "type": "TextBlock",
            "text": (
                "\u2022 \u67e5\u770b ADO bug / PR / pipeline\n"
                "\u2022 \u8bfb\u90ae\u4ef6\u3001\u770b\u65e5\u5386\u3001\u53d1 Teams \u6d88\u606f\n"
                "\u2022 \u4ee3\u7801\u641c\u7d22\u3001\u5199 commit \u4fe1\u606f\n"
                "\u2022 \u59d4\u6258 Copilot / Claude Code \u8dd1\u957f\u4efb\u52a1\n"
                "\u2022 \u4ece MS Learn \u62c9\u6587\u6863\u3001\u8df3\u8f6c\u8d44\u6e90"
            ),
            "wrap": True,
        },
        {
            "type": "TextBlock",
            "text": "\u70b9\u4e0b\u9762\u4efb\u610f\u4e00\u4e2a\u6309\u94ae\u8bd5\u8bd5\u770b\uff1a",
            "isSubtle": True,
            "spacing": "Medium",
            "wrap": True,
        },
    ]
    # The starter-prompts loader is the single source of truth for both
    # *which* prompts to surface and *how many* per channel (Teams = 6,
    # web = uncapped). The card just renders whatever it's handed.
    prompts = list(starter_prompts or [])
    actions: list[dict[str, Any]] = []
    for p in prompts:
        label = p.get("label") or p.get("id") or ""
        prompt_text = p.get("prompt") or label
        icon = p.get("icon") or ""
        if not label or not prompt_text:
            continue
        title = f"{icon} {label}".strip()
        actions.append(
            {
                "type": "Action.Submit",
                "title": title,
                "data": {
                    "msteams": {"type": "imBack", "value": prompt_text},
                },
            }
        )
    return _card_envelope(body, actions)


# ---------------------------------------------------------------------------
# A2A mini-tour — single card showing example A2A sentences (the previous
# three-stage walkthrough was collapsed; see build_a2a_tour_card docstring).
# ---------------------------------------------------------------------------


def build_a2a_tour_card() -> dict[str, Any]:
    """A2A onboarding card \u2014 a single \u201c\u53ef\u4ee5\u8fd9\u4e48\u8bd5\u8bd5\u201d card.

    Triggered by the welcome card's \u201c\u8bd5\u8bd5 A2A\u201d button. Lists example
    sentences the user can type to invoke A2A; deliberately does **not**
    auto-trigger any A2A call.

    The previous three-stage walkthrough (intro \u2192 examples \u2192 deep-dive)
    was collapsed because the intermediate \u201c\u4e0b\u4e00\u6b65 \u2192\u201d /
    \u201cA2A \u5de5\u4f5c\u539f\u7406\u201d clicks distracted from the actionable
    examples users actually wanted to copy.
    """
    body = [
        {
            "type": "TextBlock",
            "text": "\u53ef\u4ee5\u8fd9\u4e48\u8bd5\u8bd5",
            "weight": "Bolder",
            "size": "Medium",
            "wrap": True,
        },
        {
            "type": "TextBlock",
            "text": (
                "\u76f4\u63a5\u5728\u4e0b\u9762\u8f93\u4e00\u53e5\u8bdd\u7ed9\u6211\uff0c"
                "\u6211\u4f1a\u4ee5\u4f60\u7684\u540d\u4e49\u8c03\u7528 A2A \u8054\u7cfb\u540c\u4e8b\u7684 PraestoClaw\u3002"
            ),
            "wrap": True,
        },
        {
            "type": "TextBlock",
            "text": "\u793a\u4f8b\uff1a",
            "weight": "Bolder",
            "spacing": "Medium",
            "wrap": True,
        },
        {
            "type": "TextBlock",
            "text": (
                "\u2022 \u201c\u5e2e\u6211\u5217\u4e00\u4e0b\u6211\u540d\u4e0b\u8fd8\u6709\u54ea\u4e9b PraestoClaw\u201d\n"
                "\u2022 \u201c\u67e5\u4e00\u4e0b alice@contoso.com \u7684 PraestoClaw \u80fd\u505a\u4ec0\u4e48\u201d\n"
                "\u2022 \u201c\u8ba9 alice@contoso.com \u7684 PraestoClaw \u68c0\u7d22\u5979\u540d\u4e0b\u7684 P0 bug\u201d\n"
                "\u2022 \u201c\u901a\u8fc7 a2a \u7ed9 bob@contoso.com \u7684 PraestoClaw \u53d1\u4e2a\u6d88\u606f\u95ee\u4ed6\u4eca\u5929\u6709\u7a7a\u5417\u201d"
            ),
            "wrap": True,
        },
        {
            "type": "TextBlock",
            "text": (
                "\u5982\u679c\u5bf9\u65b9\u73b0\u5728\u4e0d\u5728\u7ebf\uff0c"
                "Gateway \u4f1a\u544a\u8bc9\u4f60\u6ca1\u627e\u5230 \u2014 A2A \u4e0d\u4f1a\u6392\u961f\u79bb\u7ebf\u6d88\u606f\u3002"
            ),
            "isSubtle": True,
            "wrap": True,
            "spacing": "Small",
        },
    ]
    return _card_envelope(body)


# ---------------------------------------------------------------------------
# Optional progressive seeds (used by PR-5 cron handlers)
# ---------------------------------------------------------------------------


def build_first_approval_tip_card() -> dict[str, Any]:
    """Educational tip shown after the user's first approval interaction."""
    body = [
        {
            "type": "TextBlock",
            "text": "\u5173\u4e8e\u5ba1\u6279",
            "weight": "Bolder",
            "size": "Medium",
            "wrap": True,
        },
        {
            "type": "TextBlock",
            "text": (
                "\u9047\u5230\u6709\u98ce\u9669\u7684\u64cd\u4f5c\u65f6\uff0cPraestoClaw \u4f1a\u5728\u8fd9\u91cc\u53d1\u4e00\u5f20\u5361\u8ba9\u4f60\u62cd\u677f\u3002"
                "\u4f60\u53ef\u4ee5\u9009\uff1a\u540c\u610f\u3001\u62d2\u7edd\u3001\u6216\u8005\u201c\u4ee5\u540e\u90fd\u540c\u610f\u201d\u3002"
            ),
            "wrap": True,
        },
        {
            "type": "TextBlock",
            "text": "\u8bbe\u7f6e \u2192 Security Profile \u91cc\u53ef\u4ee5\u8c03\u4e25\u5bbd\u3002",
            "isSubtle": True,
            "wrap": True,
            "spacing": "Small",
        },
    ]
    return _card_envelope(body)


def build_memory_promo_card() -> dict[str, Any]:
    """Encourage the user to seed long-term memory."""
    body = [
        {
            "type": "TextBlock",
            "text": "\u6559\u6211\u70b9\u4e1c\u897f",
            "weight": "Bolder",
            "size": "Medium",
            "wrap": True,
        },
        {
            "type": "TextBlock",
            "text": (
                "\u7ed9\u6211\u8bb2\u4e00\u4e0b\u4f60\u7684\u9879\u76ee\u3001\u540c\u4e8b\u3001\u504f\u597d\uff0c"
                "\u6211\u4f1a\u8bb0\u5230\u957f\u671f\u8bb0\u5fc6\u91cc\uff0c\u4e0b\u6b21\u4e0d\u7528\u91cd\u590d\u544a\u8bc9\u6211\u3002"
            ),
            "wrap": True,
        },
    ]
    actions = [
        {
            "type": "Action.Submit",
            "title": "\U0001f4dd \u8bb0\u4e00\u70b9\u4f60\u7684\u4e8b",
            "data": {
                "msteams": {
                    "type": "imBack",
                    "value": "\u8bb0\u4e0b\uff1a\u6211\u662f \u4ee3\u53f7 \u7684 \u804c\u4f4d\uff0c\u6240\u5728\u7684\u9879\u76ee\u662f \u9879\u76ee\u540d\u3002",
                },
            },
        }
    ]
    return _card_envelope(body, actions)


def build_capability_tip_card(title: str, tip: str) -> dict[str, Any]:
    """Generic 'did you know?' card for the 7-day-cadence cron handler."""
    body = [
        {
            "type": "TextBlock",
            "text": title or "\u4f60\u77e5\u9053\u5417\uff1f",
            "weight": "Bolder",
            "size": "Medium",
            "wrap": True,
        },
        {
            "type": "TextBlock",
            "text": tip,
            "wrap": True,
        },
    ]
    return _card_envelope(body)


__all__ = [
    "ADAPTIVE_CARD_CONTENT_TYPE",
    "ADAPTIVE_CARD_SCHEMA",
    "ADAPTIVE_CARD_VERSION",
    "build_a2a_tour_card",
    "build_capability_card",
    "build_capability_tip_card",
    "build_first_approval_tip_card",
    "build_memory_promo_card",
    "build_welcome_card",
    "wrap_for_teams",
]
