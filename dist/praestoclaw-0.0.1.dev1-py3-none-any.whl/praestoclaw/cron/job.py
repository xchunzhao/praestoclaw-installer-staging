"""Job dataclass and schedule utility functions for the cron subsystem."""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any

from loguru import logger

from praestoclaw.config.schema import ChannelType


@dataclass
class Job:
    """Internal representation of a scheduled job."""

    name: str
    schedule: str | int  # cron expr, interval seconds, or event type
    agent: str
    prompt: str
    message: str | None = None  # static text mode (zero execution)
    tool: str | None = None
    arguments: dict[str, Any] | None = None
    session_mode: str = "isolated"
    notify_channels: list[str] = field(default_factory=lambda: ["*"])
    exclude_tools: list[str] = field(default_factory=list)
    enabled: bool = True
    description: str | None = None  # free-text label shown in UI
    last_run_at: str | None = None  # ISO8601 UTC, set by SchedulerService after each run
    last_status: str | None = None  # "success" | "error" | None (never run)
    last_error: str | None = None  # truncated error message (≤500 chars), None on success
    dynamic: bool = False  # True if added via CronTool/CLI (persisted to jobs.json)
    failure_count: int = 0
    channel: ChannelType | None = None  # originating channel (e.g. "cloud")
    channel_id: str | None = None  # originating channel_id
    created_at: str | None = None  # ISO timestamp
    updated_at: str | None = None  # ISO timestamp (set on replace)
    timezone: str | None = None  # IANA name; None → server tzlocal() at trigger time
    _running: bool = field(default=False, repr=False)  # guard against concurrent execution


def safe_filename(name: str) -> str:
    """Sanitize job name for use in file paths."""
    return re.sub(r"[^\w\-.]", "_", name)[:100]


def parse_at_schedule(schedule: str) -> datetime | None:
    """Parse 'at' schedule into target datetime.

    Formats:
      'at'                            → None (immediate)
      'at:+60'                        → now + 60 seconds (relative)
      'at:2026-03-04T15:00:00'        → absolute ISO datetime (assumes UTC)
      'at:2026-03-04T15:00:00+08:00'  → absolute ISO with timezone
    """
    from datetime import timedelta

    s = str(schedule).strip()
    # "at" with nothing after → immediate
    if len(s) <= 2 or s[2:3] != ":":
        return None
    value = s[3:]  # everything after "at:"
    if not value:
        return None
    if value.startswith("+"):
        try:
            seconds = int(value[1:])
        except ValueError:
            logger.error("Invalid relative 'at' schedule {!r}; expected integer after '+'", value)
            return None
        return datetime.now(UTC) + timedelta(seconds=seconds)
    # Absolute ISO datetime
    try:
        dt = datetime.fromisoformat(value)
    except ValueError:
        logger.error("Invalid absolute 'at' schedule {!r}; expected ISO 8601 datetime", value)
        return None
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=UTC)
    return dt


def detect_trigger_type(schedule: str | int) -> str:
    """Auto-detect trigger type from schedule value.

    Supports: cron expressions, interval seconds, event types,
    and 'at' one-shot (immediate, relative delay, or absolute ISO datetime).
    """
    if isinstance(schedule, str):
        s = schedule.strip().lower()
        if s == "at" or s.startswith("at:"):
            return "at"
    if isinstance(schedule, int):
        return "interval"
    # JSON may deserialize 3600 as string — check if it's a numeric string
    if isinstance(schedule, str) and schedule.isdigit():
        return "interval"
    if (
        isinstance(schedule, str)
        and "." in schedule
        and schedule.replace(".", "").replace("_", "").isalpha()
    ):
        return "event"
    return "cron"
