"""MCP setup — authenticate & verify with live animated status display.

Live display never stops. Auth menus are rendered inline. MSAL runs in
a background thread so spinners keep animating.
"""

from __future__ import annotations

import threading
import time
from dataclasses import dataclass, field
from enum import Enum, auto
from pathlib import Path
from typing import Any

from rich.console import Group as RenderGroup
from rich.spinner import Spinner
from rich.table import Table as RichTable
from rich.text import Text

from praestoclaw.cli.commands import _load_config_safe, console
from praestoclaw.utils.input import is_tty, read_key_nonblocking

# ── Data model ───────────────────────────────────────────────────────────────


class ServerPhase(Enum):
    QUEUED = auto()
    TESTING = auto()
    OK = auto()
    FAIL = auto()
    SKIPPED = auto()


class AuthGroupState(Enum):
    PENDING = auto()
    CACHED = auto()
    MENU_ACTIVE = auto()
    SIGNING_IN = auto()
    DONE = auto()
    FAILED = auto()


class AuthGroup(Enum):
    NONE = "no-auth"
    ENTRA = "Microsoft 365"


class InlineMenu:
    """Menu state rendered inside the Live display."""

    def __init__(
        self,
        title: str,
        options: list[tuple[str, str]],
        default: int = 0,
        error: str = "",
        hint: str = "",
    ) -> None:
        self.title = title
        self.options = options
        self.selected = default
        self.result: str | None = None
        self.dismissed = False
        self.error: str = error
        self.hint: str = hint

    def handle_key(self, key: str) -> None:
        if self.dismissed:
            return
        if key == "up":
            self.selected = (self.selected - 1) % len(self.options)
        elif key == "down":
            self.selected = (self.selected + 1) % len(self.options)
        elif key == "enter":
            self.result = self.options[self.selected][0]
            self.dismissed = True
        elif key == "esc":
            self.result = self.options[-1][0]
            self.dismissed = True

    def render(self) -> Text:
        lines: list[str] = []
        if self.error:
            lines.append(f"  [red]Sign-in failed:[/red] {self.error}")
        lines.append(f"  [bold]{self.title}[/bold]")
        for i, (_, label) in enumerate(self.options):
            marker = ">" if i == self.selected else " "
            if i == self.selected:
                lines.append(f"  [bold cyan]{marker} {label}[/bold cyan]")
            else:
                lines.append(f"  [white]{marker} {label}[/white]")
        if self.hint:
            lines.append(f"  [dim]{self.hint}[/dim]")
        lines.append("  [dim]Up/Down switch  Enter confirm  Esc skip[/dim]")
        return Text.from_markup("\n".join(lines))


@dataclass
class AuthGroupStatus:
    group: AuthGroup
    state: AuthGroupState
    servers: list[str] = field(default_factory=list)
    menu: InlineMenu | None = None
    auth_thread: threading.Thread | None = None
    auth_result: str | None = None  # token set by background thread
    auth_error: str = ""
    signing_in_method: str = ""  # "browser" or "native"


# ── Pure render function ─────────────────────────────────────────────────────

_spinner = Spinner("dots")


def render_table(
    selected: list[str],
    server_phase: dict[str, ServerPhase],
    server_msg: dict[str, str],
    groups: dict[AuthGroup, AuthGroupStatus],
    active_group: AuthGroup | None,
) -> RenderGroup:
    """Build the Rich renderable from state snapshots. No side effects."""
    tbl = RichTable(box=None, show_header=False, padding=(0, 1))
    tbl.add_column(width=3)
    tbl.add_column(min_width=20)
    tbl.add_column()

    for name in selected:
        phase = server_phase.get(name, ServerPhase.QUEUED)
        msg = server_msg.get(name, "")
        if phase == ServerPhase.OK:
            tbl.add_row("  [green]+[/green]", f"[bold]{name}[/bold]", Text(msg))
        elif phase == ServerPhase.FAIL:
            tbl.add_row("  [yellow]x[/yellow]", f"[bold]{name}[/bold]", Text(msg))
        elif phase == ServerPhase.TESTING:
            tbl.add_row(_spinner, Text(name, style="bold"), Text("connecting...", style="dim"))
        elif phase == ServerPhase.SKIPPED:
            tbl.add_row("  [dim]-[/dim]", f"[dim]{name}[/dim]", Text("skipped", style="dim"))
        elif phase == ServerPhase.QUEUED:
            # Show signing-in status for queued servers in active auth group.
            grp = _find_group(name, groups)
            if grp and grp.state == AuthGroupState.SIGNING_IN:
                method = grp.signing_in_method or "..."
                tbl.add_row(
                    _spinner,
                    f"[dim]{name}[/dim]",
                    Text(f"signing in ({method})...", style="dim"),
                )
            elif grp and grp.state == AuthGroupState.FAILED:
                tbl.add_row(
                    "  [red]![/red]",
                    f"[dim]{name}[/dim]",
                    Text(f"needs {grp.group.value} login", style="dim"),
                )
            else:
                grp_label = grp.group.value if grp else "auth"
                tbl.add_row(
                    "  [dim]o[/dim]",
                    f"[dim]{name}[/dim]",
                    Text(f"needs {grp_label} login", style="dim"),
                )

    parts: list[Any] = [tbl]

    # Active auth group: show menu or device code info.
    if active_group:
        ag = groups.get(active_group)
        if ag:
            if ag.state == AuthGroupState.MENU_ACTIVE and ag.menu:
                parts.append(Text(""))
                parts.append(ag.menu.render())
            elif ag.state == AuthGroupState.SIGNING_IN and ag.group == AuthGroup.ENTRA:
                method = ag.signing_in_method or "..."
                if method == "native":
                    hint = (
                        "  [dim]An OS account picker should appear.\n"
                        "  If you don't see it, check behind this terminal window.[/dim]"
                    )
                else:
                    hint = (
                        "  [dim]A browser window should open.\n"
                        "  Please complete sign-in in the browser, then return here.[/dim]"
                    )
                parts.append(Text.from_markup(hint))

    return RenderGroup(*parts)


def _find_group(name: str, groups: dict[AuthGroup, AuthGroupStatus]) -> AuthGroupStatus | None:
    for ag in groups.values():
        if name in ag.servers:
            return ag
    return None


# ── Auth workers (background threads) ────────────────────────────────────────


def _entra_auth_worker(
    ag: AuthGroupStatus,
    client_id: str,
    scopes: list[str],
    use_wam: bool,
) -> None:
    """Run MSAL login in background thread. Sets ag.auth_result / ag.auth_error."""
    try:
        token = _direct_entra_login(client_id, scopes, use_wam=use_wam, quiet=True)
        ag.auth_result = token
        if not token:
            ag.auth_error = "login failed or cancelled"
    except Exception as exc:
        ag.auth_error = str(exc)


# ── Main entry point ─────────────────────────────────────────────────────────


def auth_and_verify(
    selected: list[str],
    merged_servers: dict[str, Any],
    config_dir: Path,
    *,
    quick: bool = False,
) -> list[str]:
    """Authenticate and verify servers with live animated status.

    Live display runs continuously. Auth menus are rendered inline.
    MSAL runs in a background thread.
    """
    from rich.live import Live

    from praestoclaw.mcp.auth import has_msal_browser_session
    from praestoclaw.mcp.defaults import SHARED_ENTRA_CLIENT_ID

    cfg = _load_config_safe(str(config_dir))

    # ── Classify servers ─────────────────────────────────────────────
    groups: dict[AuthGroup, AuthGroupStatus] = {}
    for name in selected:
        srv = merged_servers.get(name)
        if srv and srv.url and srv.auth.client_id and srv.auth.type in ("oauth", "implicit"):
            groups.setdefault(
                AuthGroup.ENTRA, AuthGroupStatus(AuthGroup.ENTRA, AuthGroupState.PENDING)
            )
            groups[AuthGroup.ENTRA].servers.append(name)
        else:
            groups.setdefault(AuthGroup.NONE, AuthGroupStatus(AuthGroup.NONE, AuthGroupState.DONE))
            groups[AuthGroup.NONE].servers.append(name)

    # ── Server-level state ───────────────────────────────────────────
    lock = threading.Lock()
    server_phase: dict[str, ServerPhase] = {}
    server_msg: dict[str, str] = {}
    for name in selected:
        grp = _find_group(name, groups)
        if grp and grp.group == AuthGroup.NONE:
            server_phase[name] = ServerPhase.TESTING
        else:
            server_phase[name] = ServerPhase.QUEUED

    threads: list[threading.Thread] = []

    def _verify_one(name: str) -> None:
        with lock:
            server_phase[name] = ServerPhase.TESTING
        try:
            from praestoclaw.cli.mcp import _test_one_sync

            ok, msg, _ = _test_one_sync(name, cfg)
        except Exception as exc:
            ok, msg = False, str(exc)
        with lock:
            server_phase[name] = ServerPhase.OK if ok else ServerPhase.FAIL
            server_msg[name] = msg

    def _start_verify(names: list[str]) -> None:
        for n in names:
            if not cfg.tools.mcp_servers.get(n):
                with lock:
                    server_phase[n] = ServerPhase.FAIL
                    server_msg[n] = "not in config"
                continue
            t = threading.Thread(target=_verify_one, args=(n,), daemon=True)
            t.start()
            threads.append(t)

    def _mark_skipped(names: list[str]) -> None:
        with lock:
            for n in names:
                server_phase[n] = ServerPhase.SKIPPED

    def _snap() -> tuple[dict[str, ServerPhase], dict[str, str]]:
        with lock:
            return dict(server_phase), dict(server_msg)

    # ── Resolve cached auth (no menu needed) ─────────────────────────
    # No-auth: start immediately.
    if AuthGroup.NONE in groups:
        _start_verify(groups[AuthGroup.NONE].servers)

    # Entra: check cached session.
    if AuthGroup.ENTRA in groups:
        en_ag = groups[AuthGroup.ENTRA]
        if has_msal_browser_session(SHARED_ENTRA_CLIENT_ID):
            en_ag.state = AuthGroupState.CACHED
            _start_verify(en_ag.servers)
        elif quick:
            en_ag.state = AuthGroupState.DONE
            _mark_skipped(en_ag.servers)
            selected = [n for n in selected if n not in en_ag.servers]

    # ── Build auth queue (groups still PENDING) ──────────────────────
    auth_queue = [
        g for g in [AuthGroup.ENTRA] if g in groups and groups[g].state == AuthGroupState.PENDING
    ]
    active_group: AuthGroup | None = None

    def _activate_next() -> None:
        nonlocal active_group
        while auth_queue:
            ag_key = auth_queue.pop(0)
            ag = groups[ag_key]
            if ag.state != AuthGroupState.PENDING:
                continue
            active_group = ag_key
            if ag.group == AuthGroup.ENTRA:
                _activate_entra(ag)
            return
        active_group = None

    # Build Entra menu options.
    # WAM broker does not return refresh_token for agent365 scopes,
    # so silent token renewal and cross-scope requests fail.
    # Always use Browser for MCP servers.
    entra_options: list[tuple[str, str]] = [
        ("browser", "Browser sign-in"),
        ("skip", "Skip for now"),
    ]

    def _activate_entra(ag: AuthGroupStatus) -> None:
        ag.menu = InlineMenu(
            "Microsoft 365 sign-in (for Teams, Calendar, Mail, etc.):",
            entra_options,
            error=ag.auth_error,
            hint="Sign in with your work account to verify MCP server connectivity.",
        )
        ag.state = AuthGroupState.MENU_ACTIVE

    def _start_entra_login(ag: AuthGroupStatus, choice: str) -> None:
        """Spawn background thread for MSAL login."""
        use_wam = choice == "native"
        ag.signing_in_method = "native" if use_wam else "browser"
        ag.state = AuthGroupState.SIGNING_IN
        first_scope: list[str] = ["openid"]
        for name in ag.servers:
            _srv = merged_servers.get(name)
            if _srv and _srv.url and _srv.auth.scopes:
                first_scope = _srv.auth.scopes
                break
        t = threading.Thread(
            target=_entra_auth_worker,
            args=(ag, SHARED_ENTRA_CLIENT_ID, first_scope, use_wam),
            daemon=True,
        )
        t.start()
        ag.auth_thread = t

    # ── Non-TTY fast path ────────────────────────────────────────────
    if not is_tty():
        # No interactive menus. Skip all pending auth groups.
        for _skip_key in list(auth_queue):
            _skip_ag = groups[_skip_key]
            _skip_ag.state = AuthGroupState.DONE
            _mark_skipped(_skip_ag.servers)
            selected = [n for n in selected if n not in _skip_ag.servers]
        auth_queue.clear()

    # Activate first pending group.
    _activate_next()

    # ── Live loop ────────────────────────────────────────────────────
    live = Live(
        render_table(selected, *_snap(), groups, active_group),
        console=console,
        refresh_per_second=8,
    )
    live.start()

    try:
        while True:
            key: str | None = None
            try:
                key = read_key_nonblocking()
            except KeyboardInterrupt:
                break

            ag: AuthGroupStatus | None = groups.get(active_group) if active_group else None

            if ag:
                # ── MENU_ACTIVE: handle key input ────────────────────
                if ag.state == AuthGroupState.MENU_ACTIVE and ag.menu:
                    if key:
                        ag.menu.handle_key(key)
                    if ag.menu.dismissed:
                        choice = ag.menu.result or "skip"
                        ag.menu = None
                        if choice == "skip":
                            ag.state = AuthGroupState.DONE
                            _mark_skipped(ag.servers)
                            selected = [n for n in selected if n not in ag.servers]
                            _activate_next()
                        else:
                            _start_entra_login(ag, choice)

                # ── SIGNING_IN: check if thread finished ─────────────
                elif ag.state == AuthGroupState.SIGNING_IN:
                    if ag.auth_thread and not ag.auth_thread.is_alive():
                        if ag.auth_result:
                            ag.state = AuthGroupState.DONE
                            _start_verify(ag.servers)
                            _activate_next()
                        else:
                            ag.state = AuthGroupState.FAILED

                # ── FAILED: transition back to menu ──────────────────
                elif ag.state == AuthGroupState.FAILED:
                    if ag.group == AuthGroup.ENTRA:
                        _activate_entra(ag)

            # Update display.
            phases, msgs = _snap()
            live.update(render_table(selected, phases, msgs, groups, active_group))

            # All done?
            if active_group is None:
                alive = [t for t in threads if t.is_alive()]
                if not alive:
                    break

            time.sleep(0.1)

    except KeyboardInterrupt:
        pass
    finally:
        phases, msgs = _snap()
        live.update(render_table(selected, phases, msgs, groups, active_group))
        live.stop()

    return selected


# ── Direct MSAL login (called from background thread) ────────────────────────


def _direct_entra_login(
    client_id: str,
    scopes: list[str],
    *,
    use_wam: bool = False,
    quiet: bool = False,
) -> str | None:
    """Perform a direct MSAL interactive login (browser or WAM).

    When *quiet* is True, suppresses all console output (for background threads).
    """
    import msal

    from praestoclaw.utils.auth import _broker_kwargs, _persist_cache
    from praestoclaw.utils.helpers import get_auth_dir

    cache_path = get_auth_dir() / f"token_cache_{client_id[:8]}.bin"
    cache = msal.SerializableTokenCache()
    if cache_path.exists():
        try:
            from praestoclaw.security.secrets import decrypt_at_rest

            raw = decrypt_at_rest(cache_path.read_bytes())
            if raw:
                cache.deserialize(raw.decode("utf-8"))
        except Exception:
            pass

    bkw = _broker_kwargs() if use_wam else {}
    app = msal.PublicClientApplication(
        client_id,
        authority="https://login.microsoftonline.com/organizations",
        token_cache=cache,
        **bkw,
    )

    wam_kwargs: dict[str, Any] = {}
    if use_wam and bkw:
        from praestoclaw.utils.auth import _get_foreground_window_handle

        wam_kwargs["parent_window_handle"] = _get_foreground_window_handle(app)

    # WAM broker must use empty scopes — custom scopes prevent
    # refresh_token from being returned. Browser PKCE can use scopes.
    interactive_scopes = [] if (use_wam and bkw) else scopes

    result = app.acquire_token_interactive(
        scopes=interactive_scopes, prompt="select_account", **wam_kwargs
    )

    # WAM failed — fallback to browser.
    # Not passing parent_window_handle → MSAL uses browser PKCE.
    if use_wam and result and "error" in result:
        if not quiet:
            console.print(
                f"  [dim]Native failed ({result.get('error', '')}), trying browser...[/dim]"
            )
        result = app.acquire_token_interactive(scopes=scopes, prompt="select_account")

    token = (result.get("access_token") or result.get("id_token")) if result else None
    if token and "error" not in (result or {}):
        _persist_cache(cache, cache_path)
        if not quiet:
            claims = result.get("id_token_claims", {})
            name = claims.get("name") or claims.get("preferred_username", "unknown")
            console.print(f"  [green]+[/green] Authenticated as [bold]{name}[/bold]")
        return str(token)

    return None
