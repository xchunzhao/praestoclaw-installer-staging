"""Import skills and MCP servers from Claude Code, VS Code Copilot, and Copilot CLI.

Scans well-known config locations on macOS/Linux/Windows, discovers
skills (SKILL.md dirs) and MCP server configs, then copies/converts
them into PraestoClaw's format.

Two flavours of Claude config are recognised:

* **User-level** — ``~/.claude/`` (personal, machine-local).
* **Repo-level** — ``<repo>/.claude/`` (team-maintained, checked into
  git). Discovered for every repo the project detector saw plus the
  current working directory, so a teammate doing ``git clone`` + ``pc
  init`` automatically picks up the team's skills and MCP servers.

Called by ``praestoclaw init`` step [6/7] and by init background workers via
``run_import_setup()``.
"""

from __future__ import annotations

import json
import os
import platform
import re
import shutil
import subprocess
import time
from collections.abc import Iterable, Iterator
from contextlib import contextmanager
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from loguru import logger
from rich.console import Console

console = Console()

_GITHUB_REMOTE_CLAUDE_ORG = "infinity-microsoft"
_GITHUB_REMOTE_CLAUDE_REPO_LIMIT = 10
_GITHUB_REMOTE_CLAUDE_TIMEOUT_S = 20.0
_GITHUB_REMOTE_CLAUDE_TOTAL_BUDGET_S = 60.0
_GITHUB_REMOTE_CLAUDE_CACHE_TTL_S = 6 * 60 * 60
_GITHUB_REPO_SLUG_RE = re.compile(r"^[a-zA-Z0-9_.-]+/[a-zA-Z0-9_.-]+$")
_REMOTE_GITHUB_IMPORT_PROJECTS = frozenset({"copilot"})


# ── Data models ──────────────────────────────────────────────────────────────


@dataclass
class ExternalSkill:
    """A skill discovered from an external tool."""

    name: str
    path: str  # absolute path to the skill directory
    source_tool: str  # "claude-code" | "copilot-cli" | "vscode-copilot"
    has_skill_md: bool = True


@dataclass
class ExternalMCP:
    """An MCP server discovered from an external tool."""

    name: str
    source_tool: str
    command: str | None = None
    args: list[str] = field(default_factory=list)
    env: dict[str, str] = field(default_factory=dict)
    server_type: str = "stdio"  # "stdio" | "http"
    url: str | None = None


@dataclass
class DiscoveryResult:
    """Combined discovery result from all external sources."""

    skills: list[ExternalSkill] = field(default_factory=list)
    mcps: list[ExternalMCP] = field(default_factory=list)
    sources_checked: list[str] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)


# ── Path discovery ───────────────────────────────────────────────────────────


def _claude_code_paths() -> dict[str, Path]:
    """Return Claude Code config paths for the current platform."""
    home = Path.home()
    return {
        "skills_dir": home / ".claude" / "skills",
        "settings": home / ".claude" / "settings.json",
        "settings_local": home / ".claude" / "settings.local.json",
    }


def _repo_claude_paths(repo_path: Path) -> dict[str, Path]:
    """Return per-repo ``.claude/`` paths for ``repo_path``.

    These are the conventions Claude Code uses for *team-maintained*
    config that lives inside a git repo:

    * ``<repo>/.claude/skills/`` — committed team skills.
    * ``<repo>/.claude/settings.json`` — committed team settings (incl.
      ``mcpServers``).
    * ``<repo>/.claude/settings.local.json`` — gitignored per-user
      overrides; we still read it because PraestoClaw runs against
      whatever's already on disk for this user.
    """
    base = repo_path / ".claude"
    return {
        "root": base,
        "skills_dir": base / "skills",
        "settings": base / "settings.json",
        "settings_local": base / "settings.local.json",
    }


def _remote_github_claude_cache_root() -> Path:
    """Return the cache root for sparse GitHub ``.claude/`` checkouts."""
    from praestoclaw.utils.helpers import get_data_dir

    return get_data_dir() / "imports" / "github-claude"


def _copilot_cli_paths() -> dict[str, Path]:
    """Return Copilot CLI config paths."""
    home = Path.home()
    return {
        "skills_dir": home / ".copilot" / "skills",
        "mcp_config": home / ".copilot" / "mcp-config.json",
    }


def _vscode_mcp_path() -> Path | None:
    """Return VS Code user-level mcp.json path for the current platform."""
    home = Path.home()
    system = platform.system()
    if system == "Darwin":
        return home / "Library" / "Application Support" / "Code" / "User" / "mcp.json"
    elif system == "Linux":
        return home / ".config" / "Code" / "User" / "mcp.json"
    elif system == "Windows":
        appdata = os.environ.get("APPDATA", str(home / "AppData" / "Roaming"))
        return Path(appdata) / "Code" / "User" / "mcp.json"
    return None


# ── Discovery ────────────────────────────────────────────────────────────────


def _load_json_safe(path: Path) -> dict[str, object] | None:
    """Load a JSON file, returning None on any error."""
    if not path.is_file():
        return None
    try:
        result: dict[str, object] = json.loads(path.read_text(encoding="utf-8"))
        return result
    except Exception:
        return None


def _discover_skills_from_dir(skills_dir: Path, source_tool: str) -> list[ExternalSkill]:
    """Scan a directory for skill subdirs containing SKILL.md."""
    results: list[ExternalSkill] = []
    if not skills_dir.is_dir():
        return results
    for child in sorted(skills_dir.iterdir()):
        if not child.is_dir():
            continue
        # Look for SKILL.md (case-insensitive)
        skill_md = child / "SKILL.md"
        if not skill_md.is_file():
            skill_md = child / "skill.md"
        if not skill_md.is_file():
            continue
        results.append(
            ExternalSkill(
                name=child.name,
                path=str(child),
                source_tool=source_tool,
                has_skill_md=True,
            )
        )
    return results


def _discover_mcps_from_json(
    data: dict, source_tool: str, *, key: str = "servers"
) -> list[ExternalMCP]:
    """Extract MCP server entries from a JSON config dict."""
    servers = data.get(key, data.get("mcpServers", {}))
    if not isinstance(servers, dict):
        return []
    results: list[ExternalMCP] = []
    for name, cfg in servers.items():
        if not isinstance(cfg, dict):
            continue
        srv_type = cfg.get("type", "stdio")
        mcp = ExternalMCP(
            name=name,
            source_tool=source_tool,
            command=cfg.get("command"),
            args=cfg.get("args", []),
            env=cfg.get("env", {}),
            server_type=srv_type if srv_type else "stdio",
            url=cfg.get("url"),
        )
        # Skip entries with no command and no url
        if not mcp.command and not mcp.url:
            continue
        results.append(mcp)
    return results


def _append_repo_claude_assets(
    result: DiscoveryResult,
    repo: Path,
    *,
    repo_label: str | None = None,
    source_tool: str | None = None,
) -> None:
    """Append skills and MCPs from one repo-level ``.claude/`` directory."""
    rp = _repo_claude_paths(repo)
    if not rp["root"].is_dir():
        return

    label = repo_label or repo.name or str(repo)
    tool = source_tool or f"claude-code-repo:{label}"
    if rp["skills_dir"].is_dir():
        result.sources_checked.append(f"{label}/.claude/skills")
        result.skills.extend(_discover_skills_from_dir(rp["skills_dir"], tool))
    for settings_file in [rp["settings"], rp["settings_local"]]:
        data = _load_json_safe(settings_file)
        if data and data.get("mcpServers"):
            result.sources_checked.append(f"{label}/.claude/{settings_file.name}")
            result.mcps.extend(_discover_mcps_from_json(data, tool, key="mcpServers"))


def _is_relative_to(path: Path, other: Path) -> bool:
    try:
        path.relative_to(other)
        return True
    except ValueError:
        return False


def _remove_tree(path: Path) -> None:
    """Remove a tree, clearing read-only bits when Git cache files require it."""
    if not path.exists():
        return

    def onerror(func: Any, failing_path: str, _exc_info: object) -> None:
        os.chmod(failing_path, 0o700)
        func(failing_path)

    shutil.rmtree(path, onerror=onerror)


def _safe_github_repo_slug(slug: str) -> str | None:
    normalized = slug.strip().lower()
    if not _GITHUB_REPO_SLUG_RE.fullmatch(normalized):
        return None
    owner, repo = normalized.split("/", 1)
    if owner != _GITHUB_REMOTE_CLAUDE_ORG:
        return None
    if repo in (".", ".."):
        return None
    if repo.endswith(".git"):
        return None
    return normalized


def _github_slug_from_source_tool(source_tool: str) -> str | None:
    prefix = "claude-code-github:"
    if not source_tool.startswith(prefix):
        return None
    return _safe_github_repo_slug(source_tool[len(prefix) :])


def _github_org_source_metadata(owner: str) -> tuple[str, str]:
    label = (
        "Copilot GitHub .claude"
        if owner.lower() == _GITHUB_REMOTE_CLAUDE_ORG
        else f"GitHub .claude: {owner}"
    )
    return (
        f"import:claude-code-github:{owner}",
        label,
    )


def _install_source_metadata(skill: ExternalSkill) -> tuple[str, str]:
    """Return ``(source, label)`` for marketplace metadata."""
    slug = _github_slug_from_source_tool(skill.source_tool)
    if slug is not None:
        owner, _repo = slug.split("/", 1)
        return _github_org_source_metadata(owner)
    return (
        f"import:{skill.source_tool}",
        f"Imported from {skill.source_tool}",
    )


def _install_marketplace_name(skill: ExternalSkill) -> str:
    """Return the Marketplace skill name to persist in install metadata."""
    slug = _github_slug_from_source_tool(skill.source_tool)
    if slug is None:
        return skill.name
    _owner, repo = slug.split("/", 1)
    return f"{repo}/{skill.name}"


def _install_destination_name(skill: ExternalSkill) -> str:
    """Return the local install directory name for an external skill."""
    name = _install_marketplace_name(skill)
    if name == skill.name:
        return skill.name
    from praestoclaw.skills.marketplace import _safe_skill_dirname

    return _safe_skill_dirname(name)


def _update_legacy_github_install_metadata(
    dest: Path,
    *,
    legacy_name: str,
    marketplace_name: str,
    source: str,
    source_label: str,
) -> None:
    """Align metadata for pre-namespace GitHub imports that were installed by skill name."""
    meta_file = dest / ".marketplace.json"
    if not meta_file.is_file():
        return
    try:
        meta = json.loads(meta_file.read_text(encoding="utf-8"))
    except Exception:
        return
    if not isinstance(meta, dict):
        return
    meta_source = meta.get("source")
    if meta.get("name") != legacy_name or not (
        meta_source == source
        or (isinstance(meta_source, str) and meta_source.startswith(f"{source}/"))
    ):
        return
    meta["name"] = marketplace_name
    meta["source"] = source
    meta["source_label"] = source_label
    meta_file.write_text(json.dumps(meta, indent=2, ensure_ascii=False), encoding="utf-8")


def _ensure_upper_skill_md(dest: Path) -> None:
    skill_md_upper = dest / "SKILL.md"
    skill_md_lower = dest / "skill.md"
    if not skill_md_upper.is_file() and skill_md_lower.is_file():
        shutil.copy2(skill_md_lower, skill_md_upper)


def _register_remote_github_marketplaces(
    local_config: dict[str, Any],
    skills: Iterable[ExternalSkill],
) -> int:
    """Register discovered remote GitHub ``.claude/skills`` dirs as marketplaces."""
    sources: dict[str, Path] = {}
    legacy_sources: dict[str, tuple[str, Path]] = {}
    for skill in skills:
        slug = _github_slug_from_source_tool(skill.source_tool)
        if slug is None:
            continue
        skills_dir = Path(skill.path).parent
        if not skills_dir.is_dir():
            continue
        owner, _repo = slug.split("/", 1)
        source_id, _label = _github_org_source_metadata(owner)
        # skills_dir is <owner>/<repo>/.claude/skills in the sparse-clone cache.
        sources[source_id] = skills_dir.parents[2]
        legacy_sources[f"import:claude-code-github:{slug}"] = (slug, skills_dir)

    if not sources:
        return 0

    mp_section = local_config.setdefault("skills", {}).setdefault("marketplaces", {})
    registered = 0
    for source_id, org_root in sorted(sources.items()):
        owner = source_id.rsplit(":", 1)[-1]
        if source_id in mp_section:
            continue
        _source_id, label = _github_org_source_metadata(owner)
        mp_section[source_id] = {
            "label": label,
            "path": str(org_root),
            "format": "github-org",
        }
        registered += 1

    for legacy_id, (slug, skills_dir) in legacy_sources.items():
        existing = mp_section.get(legacy_id)
        if existing != {
            "label": f"GitHub .claude: {slug}",
            "path": str(skills_dir),
            "format": "flat",
        }:
            continue
        del mp_section[legacy_id]
    return registered


def _remote_github_import_enabled(subscribed_projects: Iterable[str] | None) -> bool:
    """Return whether selected project profiles should scan remote GitHub skills."""
    if subscribed_projects is None:
        # Direct/manual import keeps the historic behavior. Init passes the
        # selected project list so first-run imports are profile-gated.
        return True
    selected = {project_id.strip().lower() for project_id in subscribed_projects if project_id}
    return bool(selected & _REMOTE_GITHUB_IMPORT_PROJECTS)


def _path_key(path: Path) -> str:
    try:
        return str(path.resolve())
    except OSError:
        return str(path)


def _repo_matches_subscribed_profiles(
    repo: Path,
    subscribed_projects: Iterable[str] | None,
) -> bool:
    if subscribed_projects is None:
        return True
    selected = {
        project_id.strip().lower()
        for project_id in subscribed_projects
        if project_id and project_id.strip().lower() != "default"
    }
    if not selected:
        return False

    try:
        from praestoclaw.projects.detector import detect_projects, detection_env_for_repo

        env = detection_env_for_repo(repo)
        if env is None:
            return False
        matches = detect_projects(env)
    except Exception as exc:
        logger.debug("Profile-gated .claude repo check failed for {} ({})", repo, exc)
        return False

    return any(matches.get(project_id) for project_id in selected)


@contextmanager
def _repo_cache_lock(
    root: Path, owner: str, repo: str, *, deadline: float | None = None
) -> Iterator[None]:
    """Serialize refreshes of one sparse-clone cache directory."""
    lock_dir = root / owner
    lock_path = lock_dir / f".{repo}.lock"
    lock_deadline = deadline or (time.monotonic() + _GITHUB_REMOTE_CLAUDE_TIMEOUT_S)
    lock_dir.mkdir(parents=True, exist_ok=True)

    def wait_or_timeout() -> None:
        remaining = lock_deadline - time.monotonic()
        if remaining <= 0:
            raise TimeoutError(f"{owner}/{repo}: cache lock timed out")
        time.sleep(min(0.1, remaining))

    with lock_path.open("a+b") as lock_file:
        if os.name == "nt":
            import msvcrt  # type: ignore[import-not-found]

            lock_file.seek(0)
            lock_file.write(b"\0")
            lock_file.flush()
            lock_file.seek(0)
            while True:
                try:
                    msvcrt.locking(  # type: ignore[attr-defined]
                        lock_file.fileno(),
                        msvcrt.LK_NBLCK,  # type: ignore[attr-defined]
                        1,
                    )
                    break
                except OSError:
                    wait_or_timeout()
            try:
                yield
            finally:
                lock_file.seek(0)
                msvcrt.locking(  # type: ignore[attr-defined]
                    lock_file.fileno(),
                    msvcrt.LK_UNLCK,  # type: ignore[attr-defined]
                    1,
                )
        else:
            import fcntl  # type: ignore[import-not-found]

            while True:
                try:
                    fcntl.flock(  # type: ignore[attr-defined]
                        lock_file.fileno(),
                        fcntl.LOCK_EX | fcntl.LOCK_NB,  # type: ignore[attr-defined]
                    )
                    break
                except OSError:
                    wait_or_timeout()
            try:
                yield
            finally:
                fcntl.flock(lock_file.fileno(), fcntl.LOCK_UN)  # type: ignore[attr-defined]


def _run_git(
    args: list[str],
    *,
    cwd: Path | None = None,
    timeout: float | None = None,
) -> subprocess.CompletedProcess[str]:
    env = {
        **os.environ,
        # Never hang init waiting for terminal credentials. Git Credential
        # Manager can still satisfy already-cached credentials silently.
        "GIT_TERMINAL_PROMPT": "0",
        "GCM_INTERACTIVE": "Never",
    }
    return subprocess.run(
        ["git", *args],
        cwd=str(cwd) if cwd else None,
        env=env,
        capture_output=True,
        text=True,
        timeout=timeout or _GITHUB_REMOTE_CLAUDE_TIMEOUT_S,
        check=False,
    )


def _safe_owner_cache_dir(root: Path, owner: str) -> tuple[Path | None, str | None]:
    """Create/return the owner cache directory without following escapes."""
    owner_dir = root / owner
    try:
        if owner_dir.exists():
            owner_resolved = owner_dir.resolve()
            if not _is_relative_to(owner_resolved, root):
                return None, f"{owner}: cache path escaped import root"
            if not owner_resolved.is_dir():
                return None, f"{owner}: cache path is not a directory"
        else:
            owner_dir.mkdir(parents=True, exist_ok=True)
            owner_resolved = owner_dir.resolve()
            if not _is_relative_to(owner_resolved, root):
                return None, f"{owner}: cache path escaped import root"
        return owner_dir, None
    except OSError as exc:
        return None, f"{owner}: {exc.__class__.__name__}"


def _cache_is_fresh(repo_dir: Path) -> bool:
    claude_dir = repo_dir / ".claude"
    if not claude_dir.is_dir():
        return False
    try:
        age_s = time.time() - claude_dir.stat().st_mtime
    except OSError:
        return False
    return age_s < _GITHUB_REMOTE_CLAUDE_CACHE_TTL_S


def _clone_github_claude_repo(
    repo_slug: str,
    *,
    cache_root: Path | None = None,
    deadline: float | None = None,
) -> tuple[Path | None, str | None]:
    """Sparse-clone only ``.claude/`` from a GitHub repo into the import cache."""
    slug = _safe_github_repo_slug(repo_slug)
    if slug is None:
        return None, f"{repo_slug}: invalid or unsupported GitHub repo slug"

    owner, repo = slug.split("/", 1)
    root = (cache_root or _remote_github_claude_cache_root()).resolve()
    dest = root / owner / repo
    partial = root / owner / f".{repo}.partial"

    try:
        root.mkdir(parents=True, exist_ok=True)
        owner_dir, owner_error = _safe_owner_cache_dir(root, owner)
        if owner_error:
            return None, f"{slug}: {owner_error}"
        if owner_dir is None:
            return None, f"{slug}: cache path unavailable"

        with _repo_cache_lock(root, owner, repo, deadline=deadline):
            dest_resolved = dest.resolve()
            partial_resolved = partial.resolve()
            if not _is_relative_to(dest_resolved, root) or not _is_relative_to(
                partial_resolved, root
            ):
                return None, f"{slug}: cache path escaped import root"
            if _cache_is_fresh(dest):
                return dest, None
            if deadline is not None and time.monotonic() >= deadline:
                return None, f"{slug}: remote .claude scan budget exceeded"
            if partial.exists():
                _remove_tree(partial)
            if dest.exists():
                _remove_tree(dest)

            remaining = (
                _GITHUB_REMOTE_CLAUDE_TIMEOUT_S
                if deadline is None
                else max(0.5, min(_GITHUB_REMOTE_CLAUDE_TIMEOUT_S, deadline - time.monotonic()))
            )
            clone = _run_git(
                [
                    "clone",
                    "--depth",
                    "1",
                    "--filter=blob:none",
                    "--sparse",
                    f"https://github.com/{slug}.git",
                    str(partial),
                ],
                timeout=remaining,
            )
            if clone.returncode != 0:
                detail = (clone.stderr or clone.stdout or "").strip().splitlines()
                suffix = f": {detail[-1][:160]}" if detail else ""
                return None, f"{slug}: git clone failed{suffix}"

            if deadline is not None and time.monotonic() >= deadline:
                return None, f"{slug}: remote .claude scan budget exceeded"
            remaining = (
                _GITHUB_REMOTE_CLAUDE_TIMEOUT_S
                if deadline is None
                else max(0.5, min(_GITHUB_REMOTE_CLAUDE_TIMEOUT_S, deadline - time.monotonic()))
            )
            sparse = _run_git(["sparse-checkout", "set", ".claude"], cwd=partial, timeout=remaining)
            if sparse.returncode != 0:
                detail = (sparse.stderr or sparse.stdout or "").strip().splitlines()
                suffix = f": {detail[-1][:160]}" if detail else ""
                return None, f"{slug}: sparse checkout failed{suffix}"

            partial.rename(dest)
        return dest, None
    except (OSError, subprocess.TimeoutExpired) as exc:
        return None, f"{slug}: {exc.__class__.__name__}"
    finally:
        if partial.exists():
            try:
                _remove_tree(partial)
            except OSError:
                shutil.rmtree(partial, ignore_errors=True)


def _discover_remote_github_claude_assets(
    repo_slugs: Iterable[str],
) -> DiscoveryResult:
    """Download and scan repo-level ``.claude/`` assets from GitHub candidates."""
    result = DiscoveryResult()
    seen: set[str] = set()
    deadline = time.monotonic() + _GITHUB_REMOTE_CLAUDE_TOTAL_BUDGET_S
    for repo_slug in repo_slugs:
        if len(seen) >= _GITHUB_REMOTE_CLAUDE_REPO_LIMIT:
            break
        if time.monotonic() >= deadline:
            result.errors.append("remote GitHub .claude scan budget exceeded")
            break
        slug = _safe_github_repo_slug(repo_slug)
        if slug is None or slug in seen:
            continue
        seen.add(slug)
        repo_path, error = _clone_github_claude_repo(slug, deadline=deadline)
        if error:
            result.errors.append(error)
            continue
        if repo_path is None:
            continue
        before = len(result.skills), len(result.mcps)
        _append_repo_claude_assets(
            result,
            repo_path,
            repo_label=slug,
            source_tool=f"claude-code-github:{slug}",
        )
        after = len(result.skills), len(result.mcps)
        if before == after:
            result.sources_checked.append(f"{slug}/.claude (none found)")
    return result


def discover_all(
    *,
    repo_paths: Iterable[Path] | None = None,
    remote_github_repos: Iterable[str] | None = None,
) -> DiscoveryResult:
    """Scan all known external tool locations and return discovered items.

    ``repo_paths`` is an optional iterable of git repo roots whose
    ``<repo>/.claude/`` should also be scanned for **team-maintained**
    skills and MCP servers. The project detector usually supplies this
    list via :func:`praestoclaw.projects.detector.get_detection_env`.

    ``remote_github_repos`` is an optional ranked list of GitHub repo slugs
    whose ``.claude/`` folders should be sparse-cloned into PraestoClaw's
    import cache and scanned the same way as local team repos.
    """
    result = DiscoveryResult()

    # ── Claude Code (user-level) ──
    cc = _claude_code_paths()
    if cc["skills_dir"].is_dir():
        result.sources_checked.append("Claude Code skills")
        result.skills.extend(_discover_skills_from_dir(cc["skills_dir"], "claude-code"))
    for settings_file in [cc["settings"], cc["settings_local"]]:
        data = _load_json_safe(settings_file)
        if data and data.get("mcpServers"):
            result.sources_checked.append(f"Claude Code MCP ({settings_file.name})")
            result.mcps.extend(_discover_mcps_from_json(data, "claude-code", key="mcpServers"))

    # ── Claude Code (per-repo, team-maintained) ──
    # Both user- and repo-level skills are surfaced here (so callers / UI
    # can display the full picture). Conflict resolution is enforced later
    # by ``install_external_skills()``: it iterates skills in discovery
    # order and skips any whose destination directory already exists, so
    # the user-level entry — discovered first above — wins, and personal
    # customisations in ~/.claude/skills are never silently overwritten by
    # the repo copy.
    seen_repos: set[str] = set()
    for repo in repo_paths or ():
        try:
            repo_key = str(repo.resolve())
        except OSError:
            repo_key = str(repo)
        if repo_key in seen_repos:
            continue
        seen_repos.add(repo_key)
        _append_repo_claude_assets(result, repo, repo_label=repo.name or repo_key)

    # ── Claude Code (remote GitHub, team-maintained) ──
    if remote_github_repos:
        github_result = _discover_remote_github_claude_assets(remote_github_repos)
        result.skills.extend(github_result.skills)
        result.mcps.extend(github_result.mcps)
        result.sources_checked.extend(github_result.sources_checked)
        result.errors.extend(github_result.errors)

    # ── Copilot CLI ──
    cp = _copilot_cli_paths()
    if cp["skills_dir"].is_dir():
        result.sources_checked.append("Copilot CLI skills")
        result.skills.extend(_discover_skills_from_dir(cp["skills_dir"], "copilot-cli"))
    mcp_data = _load_json_safe(cp["mcp_config"])
    if mcp_data:
        result.sources_checked.append("Copilot CLI MCP")
        result.mcps.extend(_discover_mcps_from_json(mcp_data, "copilot-cli", key="servers"))

    # ── VS Code Copilot ──
    vscode_mcp = _vscode_mcp_path()
    if vscode_mcp:
        mcp_data = _load_json_safe(vscode_mcp)
        if mcp_data:
            result.sources_checked.append("VS Code Copilot MCP")
            result.mcps.extend(_discover_mcps_from_json(mcp_data, "vscode-copilot", key="servers"))

    return result


# ── Installation ─────────────────────────────────────────────────────────────


def install_external_skills(
    skills: list[ExternalSkill],
    install_dir: Path,
) -> tuple[int, int, list[str]]:
    """Copy external skills into PraestoClaw's skill directory.

    Takes the **union**: if a skill with the same name already exists
    locally (from marketplace or user), it is **not** overwritten — the
    local version wins. Only new (previously absent) skills are installed.

    Returns (installed, skipped, errors).
    """
    install_dir.mkdir(parents=True, exist_ok=True)
    installed = 0
    skipped = 0
    errors: list[str] = []
    for skill in skills:
        src = Path(skill.path)
        if not src.is_dir():
            errors.append(f"{skill.name}: source not found")
            continue
        marketplace_name = _install_marketplace_name(skill)
        source, source_label = _install_source_metadata(skill)
        dest = install_dir / _install_destination_name(skill)
        legacy_dest = install_dir / skill.name
        if dest.exists():
            skipped += 1
            logger.debug("Skipping import of '{}' — already exists locally", skill.name)
            continue
        if marketplace_name != skill.name and legacy_dest.is_dir():
            _update_legacy_github_install_metadata(
                legacy_dest,
                legacy_name=skill.name,
                marketplace_name=marketplace_name,
                source=source,
                source_label=source_label,
            )
            _ensure_upper_skill_md(legacy_dest)
            skipped += 1
            logger.debug("Skipping import of '{}' — already exists locally", skill.name)
            continue
        try:
            shutil.copytree(
                src,
                dest,
                symlinks=True,
                ignore=shutil.ignore_patterns(".git", "__pycache__", "*.pyc", ".DS_Store", "*.zip"),
            )
            _ensure_upper_skill_md(dest)
            # Write marketplace metadata so uninstall works
            meta = {
                "name": marketplace_name,
                "source": source,
                "source_label": source_label,
                "installed_at": datetime.now(UTC).isoformat(),
            }
            (dest / ".marketplace.json").write_text(
                json.dumps(meta, indent=2, ensure_ascii=False),
                encoding="utf-8",
            )
            installed += 1
            logger.debug("Imported skill '{}' from {}", skill.name, skill.source_tool)
        except Exception as exc:
            errors.append(f"{skill.name}: {exc}")
    return installed, skipped, errors


def convert_mcps_to_config(
    mcps: list[ExternalMCP],
) -> dict[str, dict[str, Any]]:
    """Convert external MCP entries to PraestoClaw mcp_servers config format.

    Returns a dict ready to merge into local_config["tools"]["mcp_servers"].
    """
    result: dict[str, dict[str, Any]] = {}
    for mcp in mcps:
        # Normalize name: replace / with _ for cleaner YAML keys
        safe_name = mcp.name.replace("/", "_")
        entry: dict[str, Any] = {"enabled": True}
        if mcp.command:
            entry["command"] = mcp.command
            if mcp.args:
                entry["args"] = mcp.args
        if mcp.url:
            entry["url"] = mcp.url
        if mcp.env:
            entry["env"] = mcp.env
        # Add import provenance as description
        entry["description"] = f"Imported from {mcp.source_tool}"
        result[safe_name] = entry
    return result


# ── Init integration ─────────────────────────────────────────────────────────


def run_import_setup(
    local_config: dict[str, Any],
    *,
    quick: bool = False,
    subscribed_projects: Iterable[str] | None = None,
    step_number: int | None = 6,
    silent: bool = False,
) -> dict[str, Any]:
    """Discover and import external skills from Claude Code / Copilot CLI.

    MCP servers are shown for reference only (not auto-imported) because
    external MCPs often depend on tool-specific paths, extensions, or auth
    that don't carry over to PraestoClaw.

    Called by ``praestoclaw init`` as part of the profile-driven skills step.
    When ``subscribed_projects`` is provided, remote GitHub team skill scans
    are limited to GitHub-backed profiles such as Copilot. Returns a summary
    dict.

    When ``silent=True`` all user-facing console output is suppressed; counts
    are still propagated through the returned summary so callers (e.g. the
    background ``fire_external_import`` worker) can surface progress via the
    FRE pending state and the Portal status bar.
    """
    from praestoclaw.cli.init import _is_tty, _select, _step_auto, _step_done, _step_header
    from praestoclaw.skills.marketplace import get_install_dir

    # Pick a per-call console + step printers; never rebind the module-level
    # ``console`` global. The body receives ``console`` as a parameter so its
    # ``console.print(...)`` calls bind to this local value, even if other
    # threads concurrently call this function with a different ``silent``.
    if silent:
        active_console: Console = Console(quiet=True)
        noop = _noop_step
        return _run_import_setup_body(
            local_config,
            quick=quick,
            subscribed_projects=subscribed_projects,
            step_number=step_number,
            console=active_console,
            _is_tty=_is_tty,
            _select=_select,
            _step_auto=noop,
            _step_done=noop,
            _step_header=noop,
            get_install_dir=get_install_dir,
        )

    return _run_import_setup_body(
        local_config,
        quick=quick,
        subscribed_projects=subscribed_projects,
        step_number=step_number,
        console=console,
        _is_tty=_is_tty,
        _select=_select,
        _step_auto=_step_auto,
        _step_done=_step_done,
        _step_header=_step_header,
        get_install_dir=get_install_dir,
    )


def _noop_step(*_args: Any, **_kwargs: Any) -> None:
    """No-op step printer used by ``run_import_setup(silent=True)``."""
    return None


def _run_import_setup_body(
    local_config: dict[str, Any],
    *,
    quick: bool,
    subscribed_projects: Iterable[str] | None,
    step_number: int | None,
    console: Console,
    _is_tty: Any,
    _select: Any,
    _step_auto: Any,
    _step_done: Any,
    _step_header: Any,
    get_install_dir: Any,
) -> dict[str, Any]:
    # ``console`` is a function parameter that shadows the module-level
    # ``console`` global within this function's scope, so every
    # ``console.print(...)`` below routes through the per-call value
    # supplied by ``run_import_setup`` (silent or noisy) without any
    # cross-call global mutation.
    summary: dict[str, Any] = {"skills_imported": 0}
    remote_github_enabled = _remote_github_import_enabled(subscribed_projects)

    # Build the list of git repos whose ``<repo>/.claude/`` should also
    # be scanned for team-maintained assets. Reuse the detector's
    # already-walked repo list so this stays free; add cwd unconditionally
    # so a non-git workspace folder with ``.claude/`` is still discovered.
    repo_paths: list[Path] = []
    remote_github_repos: list[str] = []
    can_discover_remote_github = False
    try:
        from praestoclaw.projects.detector import get_detection_env

        env = get_detection_env()
        repo_paths.extend(Path(p) for p in env.repo_paths)
        if remote_github_enabled:
            remote_github_repos.extend(env.github_activity_repos)
            remote_github_repos.extend(env.github_candidate_repos)
            if subscribed_projects is not None:
                # Explicit profile subscription (e.g. ``copilot``) is the
                # signal we want to act on: enable discovery even when
                # ``env.github_repos`` is empty. That's the "I just
                # selected Copilot but haven't cloned anything yet" case
                # — the previous gate of ``bool(env.github_repos)`` made
                # that path unreachable. The discovery call itself is
                # best-effort and gracefully no-ops without a token /
                # contributions.
                can_discover_remote_github = True
            else:
                # Direct/manual import (``subscribed_projects is None``)
                # keeps the historic gating: only consider remote
                # discovery when the user already has GitHub repos
                # locally. Avoids surprising network calls for callers
                # that didn't pass a subscription list.
                can_discover_remote_github = bool(getattr(env, "github_repos", ()))
    except Exception as exc:  # pragma: no cover - detector failures are non-fatal
        logger.debug("Project detection unavailable for .claude scan ({})", exc)

    cwd = Path.cwd()
    current_repo_keys = {_path_key(cwd)}
    if cwd not in repo_paths:
        repo_paths.append(cwd)
    # If init was launched from a subdirectory of a git repo, the
    # team-maintained ``.claude/`` typically lives at the repo root,
    # not at cwd. Best-effort detect the toplevel and add it too so
    # nested invocations still pick up shared assets.
    try:
        from praestoclaw.projects.detector import _git_toplevel_for_cwd

        toplevel = _git_toplevel_for_cwd()
        if toplevel is not None and toplevel not in repo_paths:
            repo_paths.append(toplevel)
        if toplevel is not None:
            current_repo_keys.add(_path_key(toplevel))
    except Exception as exc:  # pragma: no cover - detector failures are non-fatal
        logger.debug("Git toplevel lookup failed for .claude scan ({})", exc)

    if subscribed_projects is not None:
        repo_paths = [
            repo
            for repo in repo_paths
            if _path_key(repo) in current_repo_keys
            or _repo_matches_subscribed_profiles(repo, subscribed_projects)
        ]

    # Discover local/user-level assets first. Remote GitHub discovery can run
    # git/network operations, so defer it until the user opts into importing.
    result = discover_all(repo_paths=repo_paths)
    if result.errors:
        summary["discovery_errors"] = len(result.errors)

    has_remote_candidates = bool(remote_github_repos) or can_discover_remote_github
    if not result.skills and not has_remote_candidates:
        if step_number is not None:
            _step_header(step_number, "Import from Claude / Copilot (optional)")
        if quick:
            _step_auto("external imports: no skills found")
        else:
            console.print("  [dim]No external skills found.[/dim]")
        for err in result.errors[:3]:
            console.print(f"      [dim]• {err[:120]}[/dim]")
        return summary

    if step_number is not None:
        _step_header(step_number, "Import from Claude / Copilot (optional)")
    else:
        console.print("  [dim]External imports from selected profile sources[/dim]")
    if quick:
        if result.skills:
            _step_auto(f"external imports: {len(result.skills)} skill(s) from external tools")
        else:
            _step_auto("external imports: scanning team GitHub repos")

    if result.skills:
        # Group by source for display
        skill_sources: dict[str, list[ExternalSkill]] = {}
        for s in result.skills:
            skill_sources.setdefault(s.source_tool, []).append(s)

        console.print(f"  [dim]Found {len(result.skills)} skill(s) from external tools:[/dim]")
        for tool, skills in skill_sources.items():
            names = ", ".join(s.name for s in skills[:5])
            more = f" +{len(skills) - 5} more" if len(skills) > 5 else ""
            console.print(f"    [cyan]{tool}[/cyan]: {names}{more}")
    elif has_remote_candidates:
        console.print(
            "  [dim]No local external skills found. Team GitHub repos can be scanned "
            "for .claude skills.[/dim]"
        )
    if remote_github_repos:
        console.print(
            f"  [dim]Remote GitHub scan candidates: {len(set(remote_github_repos))} repo(s).[/dim]"
        )
    elif can_discover_remote_github:
        console.print("  [dim]Team GitHub repo candidates can be discovered during import.[/dim]")

    if not quick and _is_tty():
        label = "Import all" if result.skills else "Scan and import"
        detail = "copy external skills into PraestoClaw"
        if has_remote_candidates:
            detail += " and scan team GitHub .claude folders"
        options = [
            (label, detail),
            ("Skip", "do not import"),
        ]
        choice = _select(options, default=1)
        if choice == 2:
            _step_done("skipped")
            return summary
    elif not quick and not _is_tty():
        console.print("  [dim]Non-interactive — skipping import.[/dim]")
        return summary
    # quick mode falls through to import

    if has_remote_candidates:
        if not remote_github_repos and can_discover_remote_github:
            try:
                from praestoclaw.projects.detector import (
                    GITHUB_ACTIVITY_ORG,
                    _collect_github_remote_repo_candidates,
                )

                activity_repos, candidate_repos, notes = _collect_github_remote_repo_candidates()
                remote_github_repos.extend(activity_repos)
                remote_github_repos.extend(candidate_repos)
                # Surface diagnostic notes (auth/rate-limit/budget) directly
                # to the user — these were previously logger.debug only,
                # which made silent empty-result failures impossible to
                # diagnose without re-running with verbose logging.
                # ``markup=False`` because note text is built from HTTP
                # error messages and other runtime data that may contain
                # ``[``/``]`` and would otherwise break Rich rendering
                # (or, worse, inject styling we didn't author).
                for note in notes:
                    console.print(f"  \u26a0 {note}", style="dim yellow", markup=False)
                if not activity_repos and not candidate_repos and not notes:
                    console.print(
                        "  [dim yellow]\u26a0 Team GitHub scan returned no "
                        "candidates. Likely causes: github.com sign-in not "
                        "cached, or no recent activity in the target "
                        f"org ({GITHUB_ACTIVITY_ORG}).[/dim yellow]"
                    )
            except Exception as exc:  # pragma: no cover - discovery failures are non-fatal
                # Include a sanitized + truncated reason so the diagnostic
                # is actionable without needing debug logs. ``markup=False``
                # because exception text can contain ``[``/``]`` that would
                # otherwise break Rich rendering.
                detail = str(exc).strip().replace("\n", " ")[:160]
                console.print(
                    f"  \u26a0 GitHub repo discovery failed: {type(exc).__name__}: {detail}",
                    style="dim yellow",
                    markup=False,
                )
                logger.debug("GitHub repo discovery unavailable for .claude scan ({})", exc)

        if not remote_github_repos:
            logger.debug("No remote GitHub .claude repositories discovered")
        else:
            console.print(
                f"  [dim]Remote GitHub scan candidates: {len(set(remote_github_repos))} repo(s).[/dim]"
            )
            github_result = _discover_remote_github_claude_assets(remote_github_repos)
            result.skills.extend(github_result.skills)
            result.mcps.extend(github_result.mcps)
            result.sources_checked.extend(github_result.sources_checked)
            result.errors.extend(github_result.errors)
            if result.errors:
                summary["discovery_errors"] = len(result.errors)
            if github_result.skills:
                console.print(
                    f"  [dim]Found {len(github_result.skills)} skill(s) from team GitHub repos.[/dim]"
                )
                registered = _register_remote_github_marketplaces(
                    local_config, github_result.skills
                )
                if registered:
                    summary["github_marketplaces_registered"] = registered
                    console.print(
                        "  [dim]Registered "
                        f"{registered} team GitHub repo skill source(s) in Marketplace.[/dim]"
                    )

    if not result.skills:
        if quick:
            _step_done("no external skills found")
        else:
            console.print("  [dim]No external skills found.[/dim]")
        for err in result.errors[:3]:
            console.print(f"      [dim]• {err[:120]}[/dim]")
        return summary

    # ── Import skills ──
    install_dir = get_install_dir()
    installed, skipped, errors = install_external_skills(result.skills, install_dir)
    summary["skills_imported"] = installed
    summary["skills_skipped"] = skipped
    summary["install_errors"] = len(errors)
    if errors:
        summary["install_error_samples"] = [err[:200] for err in errors[:3]]
    parts = [f"[green]imported:[/green] {installed}"]
    if skipped:
        parts.append(f"[dim]skipped (already local):[/dim] {skipped}")
    if errors:
        parts.append(f"[red]errors:[/red] {len(errors)}")
    if result.errors:
        parts.append(f"[yellow]discovery warnings:[/yellow] {len(result.errors)}")
    console.print(f"    {'  '.join(parts)}")
    for err in errors[:3]:
        console.print(f"      [dim]• {err[:120]}[/dim]")
    for err in result.errors[:3]:
        console.print(f"      [dim]• {err[:120]}[/dim]")

    _step_done(f"{installed} skill(s) imported, {skipped} skipped")
    return summary
