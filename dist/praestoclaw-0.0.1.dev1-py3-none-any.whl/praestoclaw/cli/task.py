"""CLI commands for the PraestoClaw Task protocol (Gateway v1).

Each command opens a short-lived ``CloudChannel`` against the configured
Gateway, performs exactly one task operation, prints the result, and
exits. This mirrors the long-lived ``pc cloud`` command but is
fire-and-forget so a human running two PraestoClaw instances against a
local Gateway can drive scenarios 1/2/6 of
``PraestoClawGateway/scripts/task_protocol_smoke.py`` by hand.
"""

from __future__ import annotations

import asyncio
import json
from typing import Any

import typer

from praestoclaw.cli.commands import (
    _load_config_safe,
    app,
    console,
)

task_app = typer.Typer(
    name="task",
    help="Task protocol (send/approve/deny/cancel/interrupt/undo)",
    context_settings={"help_option_names": ["-h", "--help"]},
    no_args_is_help=True,
)


# ── one-shot transport helper ─────────────────────────────────────────


async def _with_cloud_channel(cfg, cloud_cfg, action) -> Any:
    """Open a CloudChannel, wait for it to connect, run *action(ch)*, close.

    Re-uses the exact same construction the long-lived ``cloud`` command
    uses (auth, AWPS negotiation, dispatcher wiring) — only the lifetime
    differs: we await the first connection, run the caller's coroutine,
    then stop.
    """

    from praestoclaw.auth.factory import build_auth_provider as _build_auth
    from praestoclaw.channels.cloud import CloudChannel
    from praestoclaw.runtime import Runtime

    rt = Runtime(cfg)
    ch = CloudChannel(
        rt.bus,
        url=cloud_cfg.url,
        tenant_id=cloud_cfg.tenant_id,
        client_id=cloud_cfg.client_id,
        scope=cloud_cfg.scope,
        transport_mode=cloud_cfg.transport_mode,
        negotiate_url=cloud_cfg.negotiate_url,
        negotiate_timeout_s=cloud_cfg.negotiate_timeout_s,
        client_url_refresh_skew_s=cloud_cfg.client_url_refresh_skew_s,
        login_method=cloud_cfg.login_method,
        login_port=cloud_cfg.login_port,
        allow_from=cloud_cfg.allow_from or None,
        auto_reconnect=False,
        reconnect_max=1,
        bypass_token=cloud_cfg.bypass_token,
        open_browser_on_connect=False,
        a2a_enabled=cfg.channels.a2a.enabled,
        a2a_instance_id=rt._a2a_instance_id,
        a2a_user_id=cfg.channels.a2a.user_id or cloud_cfg.a2a_user_id,
        a2a_is_active_instance=cfg.channels.a2a.is_active_instance,
        a2a_protocol_version=cfg.channels.a2a.protocol_version,
        a2a_card_seed=rt._generate_a2a_card_seed(),
    )
    ch._auth = _build_auth(cloud_cfg, channel=ch)
    ch.set_runtime(rt)
    rt.channel_manager.add(ch)
    await ch.start()
    try:
        # Wait for the websocket to be live (up to 30s) so the first
        # outbound request doesn't race the dispatch loop.
        for _ in range(150):
            if getattr(ch, "_ws_connected", False) and ch._business is not None:
                break
            await asyncio.sleep(0.2)
        if not getattr(ch, "_ws_connected", False):
            raise RuntimeError("cloud gateway did not connect within 30s")
        return await action(ch)
    finally:
        try:
            await ch.stop()
        except Exception:  # noqa: BLE001
            pass


def _print_result(label: str, result: dict[str, Any]) -> None:
    if result.get("ok"):
        console.print(f"[green]{label} ok[/green]")
    else:
        console.print(f"[red]{label} failed[/red]")
    console.print(json.dumps(result, indent=2, ensure_ascii=False, default=str))


# ── task send ──────────────────────────────────────────────────────────


@task_app.command("send")
def task_send(
    peer: str = typer.Argument(..., help="Recipient user_id (or agent address)"),
    summary: str = typer.Option(..., "--summary", "-s", help="Human-readable intent.summary"),
    action: str | None = typer.Option(None, "--action", help="intent.action identifier"),
    hint_risk: str | None = typer.Option(
        None, "--hint-risk", help="Sender's risk hint: read|write|external"
    ),
    undoable: bool = typer.Option(
        False, "--undoable/--not-undoable", help="Sender opt-in for undo retention"
    ),
    agent_id: str | None = typer.Option(
        None, "--agent-id", help="Recipient agent_id (defaults to peer user_id)"
    ),
    task_id: str | None = typer.Option(None, "--task-id", help="Force a specific task_id"),
    soft_ms: int | None = typer.Option(None, "--soft-ms", help="deadlines.soft_ms"),
    hard_ms: int | None = typer.Option(None, "--hard-ms", help="deadlines.hard_ms"),
    config: str = typer.Option(".", "--config", "-c"),
    profile: str | None = typer.Option(None, "--profile", "-p"),
) -> None:
    """Send a task-bearing A2A request to *peer*.

    Phase-1 driver for ``task_protocol_smoke.py`` scenarios 2/3/6.
    """
    cfg = _load_config_safe(config, profile)
    cloud_cfg = cfg.channels.cloud

    async def _go(ch):
        return await ch.send_task_request(
            peer,
            summary,
            recipient_agent_id=agent_id,
            task_id=task_id,
            action=action,
            hint_risk=hint_risk,
            undoable=undoable,
            soft_ms=soft_ms,
            hard_ms=hard_ms,
        )

    result = asyncio.run(_with_cloud_channel(cfg, cloud_cfg, _go))
    _print_result("task send", result)
    raise typer.Exit(0 if result.get("ok") else 1)


# ── task <action> ──────────────────────────────────────────────────────


def _control_command(action: str, help_text: str):
    @task_app.command(action, help=help_text)
    def _cmd(
        task_id: str = typer.Argument(..., help="Target task_id"),
        reason: str | None = typer.Option(None, "--reason", help="Optional reason string"),
        config: str = typer.Option(".", "--config", "-c"),
        profile: str | None = typer.Option(None, "--profile", "-p"),
    ) -> None:
        cfg = _load_config_safe(config, profile)
        cloud_cfg = cfg.channels.cloud

        async def _go(ch):
            return await ch.send_task_control(task_id, action, reason=reason)

        result = asyncio.run(_with_cloud_channel(cfg, cloud_cfg, _go))
        _print_result(f"task {action}", result)
        raise typer.Exit(0 if result.get("ok") else 1)

    _cmd.__name__ = f"task_{action}"
    return _cmd


_control_command("approve", "Approve a waiting task")
_control_command("deny", "Deny a waiting task")
_control_command("cancel", "Cancel an in-flight task (sender)")
_control_command("interrupt", "Interrupt an executing task (either party)")
_control_command("undo", "Undo a completed task (receiver, requires sender opt-in)")


# ── Register sub-app on the main CLI ──────────────────────────────────

app.add_typer(task_app, name="task")
