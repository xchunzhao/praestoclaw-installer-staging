"""CLI helpers for local multi-instance cloud testing."""

from __future__ import annotations

from typing import TYPE_CHECKING

from loguru import logger

if TYPE_CHECKING:
    from praestoclaw.config.schema import AppConfig


def apply_local_dev_cloud_overrides(
    config: AppConfig,
    *,
    instance_id: str | None = None,
    cloud_url: str | None = None,
    a2a_enabled: bool | None = None,
    a2a_user_id: str | None = None,
    log_prefix: str = "cli",
) -> None:
    """Apply local E2E cloud/A2A identity overrides to an in-memory config."""

    cloud_cfg = config.channels.cloud
    a2a_cfg = config.channels.a2a
    if instance_id is not None:
        cloud_cfg.bypass_token = f"dev-{instance_id}"
        cloud_cfg.agent_id_override = instance_id
        a2a_cfg.instance_id = instance_id
        a2a_cfg.user_id = f"dev-user-{instance_id}"
        cloud_cfg.enabled = True
        logger.info(
            "[{}] Using dev instance: id={}, bypass_token=dev-{}, user=dev-user-{}",
            log_prefix,
            instance_id,
            instance_id,
            instance_id,
        )

    if cloud_url is not None:
        cloud_cfg.url = cloud_url
        cloud_cfg.enabled = True
        if cloud_cfg.transport_mode == "awps":
            from praestoclaw.gateway_protocol.v2.awps import negotiate_url_from_connect_url

            cloud_cfg.negotiate_url = negotiate_url_from_connect_url(cloud_url)
            logger.info(
                "[{}] Cloud AWPS endpoint overridden: negotiate_url={}",
                log_prefix,
                cloud_cfg.negotiate_url,
            )
            logger.debug(
                "[{}] Cloud AWPS URL hint (not opened directly): {}",
                log_prefix,
                cloud_url,
            )
        else:
            logger.info("[{}] Cloud direct URL overridden to {}", log_prefix, cloud_url)

    if a2a_enabled is None and a2a_user_id is None:
        return

    if a2a_enabled is not None:
        a2a_cfg.enabled = a2a_enabled
    if a2a_user_id is not None:
        a2a_cfg.user_id = a2a_user_id
    logger.info(
        "[{}] A2A overridden: enabled={}, user_id={}",
        log_prefix,
        a2a_cfg.enabled,
        a2a_cfg.user_id or "(not set)",
    )
