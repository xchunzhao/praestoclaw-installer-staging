---
name: bug-investigate
description: |
  Systematic bug investigation: reproduce → bisect → root cause → fix → regression test.
  Activates when the user reports a bug or asks you to investigate an error.
metadata:
  activation:
    keywords: [bug, investigate, repro, root cause, debug, 排查, 复现, 查 bug]
    patterns:
      - "(?i)\\b(why|how come)\\b.*\\b(fail|broken|error|crash)\\b"
      - "(?i)\\b(investigate|reproduce|debug)\\b"
  workflow:
    phases: [reproduce, bisect, root_cause, fix, regression]
    requires_user_confirm: [fix]
    max_turns: 150
---
## Bug Investigation SOP

### Step 0 — Plan first

```
plan(action="create", workflow="bug-investigate", items=[
  {title: "Reproduce reliably",
   acceptance: "Minimal reproducer + observed vs expected output"},
  {title: "Bisect / locate the failing component",
   acceptance: "Smallest code region that, when reverted, fixes the symptom"},
  {title: "Root cause explanation",
   acceptance: "One-paragraph causal chain from input to symptom"},
  {title: "Fix",
   acceptance: "Diff that addresses the root cause (not just the symptom)"},
  {title: "Regression test",
   acceptance: "New test that fails on old code and passes on new code"}
])
```

### Phases

1. **reproduce** — Don't theorize before you can reproduce. If you cannot reproduce in 3 attempts, `checkpoint(ask_user=true)` for more info.
2. **bisect** — Use `git bisect`, log diffs, or selective disabling to localize. Report your hypothesis and the minimum failing context.
3. **root_cause** — Distinguish *symptom* from *cause*. Write the causal chain explicitly.
4. **fix** — Smallest correct change. `checkpoint(ask_user=true)` before committing if the fix touches >10 files or any security-sensitive area.
5. **regression** — Add a test that would have caught it. Capture test output as evidence.

### Anti-patterns

- ❌ Patching the symptom without confirming the cause
- ❌ "It works on my machine" without a documented reproducer
- ❌ Marking `fix` done without a regression test
