---
name: doc-write
description: |
  Documentation / spec / RFC writing: outline → draft → examples → review → publish.
  Activates for "write a spec", "write docs", "draft an RFC".
metadata:
  activation:
    keywords: [write docs, write spec, draft rfc, documentation, 写文档, 写 spec, 写规范]
    patterns:
      - "(?i)\\b(write|draft|author)\\s+(a\\s+)?(spec|rfc|doc|documentation|design\\s+doc)\\b"
  workflow:
    phases: [outline, draft, examples, review, publish]
    requires_user_confirm: [outline]
    max_turns: 80
---
## Documentation Writing SOP

### Step 0 — Plan first

```
plan(action="create", workflow="doc-write", items=[
  {title: "Outline: target audience, sections, key decisions",
   acceptance: "Section list with one-line description per section"},
  {title: "Draft prose for each section",
   acceptance: "All sections drafted; transitions read smoothly"},
  {title: "Add concrete examples / diagrams / code blocks",
   acceptance: "Each abstract concept has at least one concrete example"},
  {title: "Self-review pass: clarity, jargon, completeness",
   acceptance: "Red-pen pass complete; no obvious gaps"},
  {title: "Publish / file location finalized",
   acceptance: "Doc committed at the correct path; cross-links updated"}
])
```

### Rules

1. **Confirm the outline before drafting.** `checkpoint(ask_user=true)` after outline — restructuring 3000 words is expensive.
2. **Examples are not optional.** Reject any "done" on a section that lacks at least one concrete example.
3. **Cross-link.** If the doc references other docs, update those docs' links back.
