# Common Classification Mistakes

Real examples of misclassification and how to avoid them. Always pair with `decision-guide.md` (and run the OUTPUT GATE).

---

## Mistake 1 — Cross-contamination (Controller ↔ Processor)

The single most common mistake: using **Enterprise** taxonomy terms (EUII / EUPI / OII) in a **Controller / MSA** scenario, or vice versa.

### Real example: Societas OneDrive attach (MSA / Controller scenario)

| Data element | ❌ Wrong classification | ✅ Correct classification | Why |
|---|---|---|---|
| Graph API access token | "EUPI" | **Credentials Data** (Controller) | EUPI is Enterprise taxonomy. An access token is an authentication credential. |
| driveId / itemId / webUrl | "OII" | **Product and Service Usage Data** (Controller) | OII is Enterprise taxonomy. These are system-generated resource identifiers. |

### Root cause
A general warning ("never mix") existed, but without a concrete allow-list or validation step, the model defaulted to familiar Enterprise terms.

### Prevention
Always run the OUTPUT GATE in `decision-guide.md`:
1. Confirm the side (Controller vs Processor)
2. Look up the allow-list for that side
3. Verify the chosen term is on the allow-list
4. If not → find the correct term

---

## Mistake 2 — Treating derived/aggregated/model data as less sensitive

### The temptation
"We only store aggregates, so it's not personal data."
"It's a model embedding, not the original content."
"We hash the user ID, so it's anonymous."

### The reality
- Derived / inferred data usually **keeps the source classification**
- Mixed datasets inherit the **highest** sensitivity level present
- Model training / inference may inherit the training data's classification
- Hashing or transformation **does not automatically remove sensitivity**

### Correct stance
Default to source classification. If you believe a downgrade is justified → escalate to Privacy Manager, don't self-approve.

---

## Mistake 3 — Using old workbooks as current guidance

- `Data Handling Standards.xlsx` → the `V5 (current)` tab is current
- `Controller Data Use Framework - old.xlsx` is explicitly historical

Using the old one for present-state recommendations → wrong obligations applied.

**Rule**: Prefer V5 / current. Use old only for historical / lineage explanations.

---

## Mistake 4 — Classifying the feature instead of each data element

### Wrong
"Our feature is a chat app → everything is Customer Content."

### Right
Each data element gets its own classification:
- Chat messages → Customer Content
- User identity → Account Data (Controller) or EUII (Processor)
- Access tokens → Credentials Data (Controller)
- Message delivery telemetry → Product and Service Performance Data (Controller)
- …

One feature → many data elements → many classifications.

---

## Mistake 5 — Skipping the side-determination for dual-identity features

Features that serve both MSA and AAD users need **per data flow** side determination, not one decision for the whole feature.

A single feature can produce both Controller-side and Processor-side classifications, depending on which identity the user authenticated with.

---

## Mistake 6 — Treating "taxonomy classification" as a replacement for privacy review

Classifying data correctly is a **prerequisite** to privacy review, not a substitute.

Classification tells you **what kind of data this is**.
Privacy review tells you **whether / how you're allowed to use it**.

Both are required.

---

## Quick self-check before you emit a classification

- [ ] I confirmed Controller vs Processor side
- [ ] I'm filling only the correct field (#7 or #8, not both)
- [ ] My chosen term is in the allow-list for that side
- [ ] I classified each data element separately, not the feature as a whole
- [ ] I didn't downgrade derived data without escalation
- [ ] I used V5 / current guidance, not old workbooks

If all checked → emit. If not → fix and re-check.
