# Data Scout Complete Reference (Auto-extracted via M365 Copilot)
> Source: M365TrustPrivacy SharePoint — Champs 110 Guide + Controller Data Use Framework + Quick Glossary
> Extracted: 2026-04-13

## 1. Data Scout Fields (31 fields + Comments)

All fields from Champs 110 - Data Scout Guide, organized by the 7 Data Scout Groups:

### Group 1: Data Information (Description, classification, and origin of the data)

| # | Field Name | "i" Description | Detailed Guidance |
|---|-----------|----------------|-------------------|
| 1 | **Data Name** | Enter the individual data element being processed for this service or feature | The name of the data element so that it can be located in the code or data base. |
| 2 | **Description of Data** | Provide the brief description of the data element and how it is used for this release | A human readable description of the data that indicates what the data is. Example: "Tenant ID — a unique identifier assigned by Microsoft for identifying Tenants" |
| 3 | **Usage of AIML/LLM** | (none) | Is this data element used for AI/ML/LLM processing? Scenarios: 1. used as input into the model 2. used for model training 3. is the output from the LLM |
| 4 | **Enter the name of the AIML/LLM model** | (none) | Provide exact name of new or existing AI/ML/LLM model. References: substrate-ai-platform-overview, Substrate LLM API available models |
| 5 | **Select the Data Scope** | (none) | Feature / Telemetry / Diagnostic / Both? Telemetry = measuring the product from a distance; Diagnostic = using the data to troubleshoot issues (neither is a data type, but a usage) |
| 6 | **In what capacity is Microsoft acting on this data?** | Select all that apply | Data Controller / Data Processor / Data Sub-Processor (rare). Definitions at M365TrustPrivacy/SitePages/Microsoft's-Role-as-a-Data-Processer-Vs.-a-Data-Controller.aspx |
| 7 | **Data Classification - Enterprise** | Select the data type(s) for this data element | Use https://aka.ms/O365AssetClassification for specific examples and extended definitions |
| 8 | **Data Classification - Consumer/Controller** | Select the data type(s) for this data element | Use https://aka.ms/taxonomy for specific examples and extended definitions |
| 9 | **Data Classification - Data Transformation Process** | (conditional) | If data is moving from one Data Classification to another. Approved processes documented in Trust Decision Logs. Note: cannot transform Customer Content to System Metadata in Government Cloud |
| 10 | **Origin of Data** | From where did we get this data element? Select all that apply | Options: collected from customer (Admin or End-User), pulled from another Microsoft service (1st party), shared from another entity (3rd party), coming from Outlook add-ins or connectors |
| 11 | **Was this a single purchase with rights for Microsoft to use this data (i.e. Research)** | (none) | If 3rd party data, was it purchased? May need CELA review of purchase agreement |

### Group 2: Data Use (What the data will be used for)

| # | Field Name | "i" Description | Detailed Guidance |
|---|-----------|----------------|-------------------|
| 12 | **Select the applicable Processor / LBO / Controller uses of data** | (none) | Processor uses = contractual agreements; Controller uses = Microsoft as controller; LBO = Legitimate Business Operations per M365TrustPrivacy/SitePages/LBO_Req.aspx |

### Group 3: Data Storage (Where the data will be stored and for how long)

| # | Field Name | "i" Description | Detailed Guidance |
|---|-----------|----------------|-------------------|
| 13 | **Select the applicable data retention / deletion timeline** | (none) | Specific duration for how long data will be held |
| 14 | **Select which IDs may be associated with this data in storage** | (none) | Specific identifiers stored with this data |
| 15 | **Select the data store(s) for data storage/data at rest** | (none) | Which data stores will hold the data. Choose all that apply |
| 16 | **Which Data Subject Rights (DSRs) can be exercised on this data?** | Indicate which DSR signals are in place | Processor: enable Controller/Enterprise to fulfill DSRs. Controller: per GDPR Business Requirements. Public: right to view, correct, export, delete |

#### Known ID Types (from Guide):
- **Most common:** MSA (Microsoft Account — consumer: BillyBob@hotmail.com/live.com/outlook.com), AAD (Azure Active Directory — being rebranded Entra)
- **Frequently used:** Advertising ID (Windows/iOS/Android), ANID (Anonymous ID — not truly anonymous, most often for cookies)
- **Other IDs:** Apple or Android Device ID (3rd party), Facebook ID (3rd party), Google ID (3rd party), IMEI (International Mobility Equipment ID, 3rd Party), LinkedIn ID (still 3rd Party), MAC Address, MUID or Client ID (Microsoft User ID — web client cookie, persists across Microsoft properties), OPID (can be associated to MSA or AAD), Skype ID (legacy 3rd party), XUID (Xbox User ID), Windows 10 Global Device ID, Other Persistent GUID associated to a User

### Group 4: Data Sharing (Whether shared with other Microsoft services or Third Parties)

| # | Field Name | "i" Description | Detailed Guidance |
|---|-----------|----------------|-------------------|
| 17 | **Is there 1st or 3rd Party Access to this data?** | Select all that apply | None / 1st Party (another Microsoft service) / 3rd Party (supplier or sub-processor) |

### Group 5: Internal Data Sharing (What other Microsoft services have access)

| # | Field Name | "i" Description | Detailed Guidance |
|---|-----------|----------------|-------------------|
| 18 | **Which other Microsoft services(s) have access?** | (none) | If answered 1st Party in Data Sharing, list all Microsoft services |

### Group 6: Third Party Information

| # | Field Name | "i" Description | Detailed Guidance |
|---|-----------|----------------|-------------------|
| 19 | **Which 3rd Party has access?** | (none) | List all 3rd parties with access |
| 20 | **Provide the Supplier ID from SSPA** | (none) | Go to https://aka.ms/MyOrder, search supplier, ID is number in parenthesis after supplier name |
| 21 | **Is the Supplier SSPA status approved?** | Review the supplier information in SSPA | Check SSPA Compliant status, verify Supplier Data Processing table |
| 22 | **Link to your SSPA exception** | (none) | If not approved, provide SSPA exception link (rare, requires SSPA team help) |
| 23 | **How does the 3rd Party handle data deletion for GDPR?** | Confirm DSRs are enabled for supplier | Delete processor (listens to Microsoft delete signal) or Variant (own process documented in NGP Variant) |
| 24 | **Is this supplier listed in the Trust Center?** | Check the Trust Center | Go to servicetrust.microsoft.com, download supplier list, verify for applicable Online Service, Sub-processing Activity, Processing Location |
| 25 | **Will the 3rd Party sell or rent this data?** | (none) | Sell (give to others) / Rent (allow others to access) |
| 26 | **How is data transferred to the supplier?** | Select all that apply | Encrypted Excel / Secure API / Other method — must be transferred securely |

### Group 7: Diagnostic Data (Details of events captured)

| # | Field Name | "i" Description | Detailed Guidance |
|---|-----------|----------------|-------------------|
| 27 | **Is this for a Client application?** | (none) | Client application (e.g. Word) vs Online Service (e.g. SharePoint, Teams) |
| 28 | **Select the proposed event type** | (none) | Optional (user can shut off) / Required |
| 29 | **Describe what takes place for this event to be logged** | (none) | Describe the trigger event for Required events |
| 30 | **Provide the full and exact Event Name** | (none) | Event Name found in Code — exact full name |
| 31 | **Provide list of all Field Names for this event** | (none) | All field names for this event |
| 32 | **Comments** | (none) | Additional info, e.g. controls that may suppress it |

---

## 2. Controller Data Use Framework (MPS 3.0)

### Key — Legal Basis Codes

| Code | Meaning |
|------|---------|
| 1 | Discoverable Notice |
| 2 | Prominent Notice |
| 3 | Legitimate Interest |
| 4 | Opt Out Consent |
| 5 | Opt in Consent |
| 6 | Consent per Country Matrix |
| A | Customer controls not required |
| B | Customer controls required |
| X | Not permitted |

### Controller Use Categories (11 categories)

1. Provide (Secure, Safe, UptoDate, Functioning as Expected)
2. Improve
3. Personalize
4. Recommend
5. Upsell/Offer Upgrades
6. Market Microsoft Product or Service
7. Market Third Party Product
8. Market Microsoft on Third Party
9. Sharing with Third Parties (providing service to MS)
10. Sharing with Third Parties (using data for own purpose)
11. Research

### Data Types and Permitted Uses Matrix

Format: Notice-LegalBasis-Controls per use category

#### Identified Data — Customer Content

| Provide | Improve | Personalize | Recommend | Upsell | Market MS | Market 3P | Market MS on 3P | Share 3P(Svc) | Share 3P(Own) | Research |
|---------|---------|-------------|-----------|--------|-----------|-----------|-----------------|---------------|---------------|----------|
| 1-3-A | 1-3-A | 1-3-A | 1-3-A | X | X | X | X | 1-3-A | 2-5-B | 2-5-B |

#### Credentials Data (N1: biometric credentials = 2-5-B)

| 1-3-A | X | X | X | X | X | X | X | 1-3-A | 2-5-B | 2-5-B |

#### Customer Contact List Data

| 1-3-A | 1-3-A | 1-3-A | 1-3-A | 1-3-A | — | — | — | — | 2-5-B | 2-5-B |

#### Biometric Data

| X across all uses |

#### Device Connectivity and Configuration Data

| 1-3-A | 1-3-A | 1-3-A | 1-3-A | 2-5-B | 2-5-B | 2-5-B | 2-5-B | 1-3-A | 2-5-B | 2-5-B |

#### Product and Service Usage Data

| 1-3-A | 1-3-A | 1-3-A | 1-3-A | 2-5-B | 2-5-B | 2-5-B | 2-5-B | 1-3-A | 2-5-B | 2-5-B |

#### Product and Service Performance Data

| 1-3-A | 1-3-A | 1-3-A | 1-3-A | 2-5-B | 2-5-B | 2-5-B | 2-5-B | 1-3-A | 2-5-B | 2-5-B |

#### Account Data / Customer Contact Data

| 1-3-A | 1-3-A | 1-3-A | 1-3-A | 2-6-B | 2-6-B | X | X | 1-3-A | 2-5-B | 2-5-B |

#### Payment Instrument Data

| 1-3-A | X | X | X | X | X | X | X | 1-3-A | 2-5-B | 2-5-B |

#### Other Captured/Generated Data types (all same pattern: 1-3-A for Provide/Improve/Personalize/Recommend, 2-5-B for marketing/sharing)
- Support Interaction Data
- Support Content Data
- Feedback and Ratings Data
- Software Setup and Inventory Data
- Demographic Information Data
- Interests and Favorites Data
- Content Consumption Data (N2: some platforms require opt-in)
- Inking, Typing and Speech Utterance Data
- Social Data
- Fitness and Activity Data
- Environmental Sensor Data
- Licensing and Purchase Data

#### Special cases:
- **Browsing History Data**: 2-5-B across all uses (more restrictive)
- **Search Requests and Query Data**: 2-3-A for Provide/Improve/Personalize/Recommend
- **Third Party Search Results Data**: X across ALL uses
- **Precise User Location Data**: 2-5-B across all uses (more restrictive)

### Notes

| Note | Description |
|------|-------------|
| N1 | Biometric credentials data = 2-5-B |
| N2 | Some communications platforms require opt-in for content consumption |
| N3 | Research = 2-5-B unless scientific research verified (GDPR recital 159 / Article 89) |
| N4 | Individual services must honor varying compliance obligations |
| N5 | Third Party Search Results in some countries 2-4-B may be sufficient |

---

## 3. Quick Glossary

| Acronym | Definition |
|---------|------------|
| LBO | Legitimate Business Operations |
| DPA | MS Online Services Data Protection Addendum |
| SSPA | Supplier and Security Assurance Program |
| FTI | Federal Tax Info (IRS publication 1075) |
| EUPI | End User Pseudonymous Identifiers |
| OII | Organization Identifiable Info |
| MAU | Monthly Active Users |
| AADC | Age-Appropriate Design Code |
| DHS | Data Handling Standards |
| GDPR | General Data Protection Regulation |
| MPS | Microsoft Privacy Standard |
| DPIA | Data Protection Impact Assessment |
| Eligibilities | Torus secure access groups for O365 production resources |

---

## 4. FAQ Summary (Privacy Reviews and 1CS Assessments)

- When to create Privacy Review: see aka.ms/M365TrustPrivacyWhenandHow
- Previews/internal releases: YES, need Privacy Review
- Schedule Privacy Review: see aka.ms/M365TrustPrivacyManager
- 1CS Assessment types: Trust Data Access Request vs Privacy Review
- Access to 1CS: add yourself via aka.ms/Add-yourself-to-M365-1CS (VPN required, 2-4 hours to replicate)
- Submit issues: ensure all questions answered, check "Go to next unanswered question" link
- Questions: ogrc-priv@microsoft.com (1CS Trust Data Access Request), pradatatax@microsoft.com (Data Use Framework)

---

## 5. Key Reference URLs

| Resource | URL |
|----------|-----|
| Controller Data Taxonomy | https://aka.ms/taxonomy |
| Enterprise Data Classification | https://aka.ms/O365AssetClassification |
| Data Use Framework | Controller Data Use Framework.xlsx on privacy SharePoint |
| LBO Requirements | M365TrustPrivacy/SitePages/LBO_Req.aspx |
| Microsoft Role (Processor vs Controller) | M365TrustPrivacy/SitePages/Microsoft's-Role-as-a-Data-Processer-Vs.-a-Data-Controller.aspx |
| SSPA Supplier Lookup | https://aka.ms/MyOrder |
| Trust Center Supplier List | https://servicetrust.microsoft.com/DocumentPage/298b6d98-b8e8-4a8e-b3c2-3b3fc45e295c |
| Privacy Review Process | M365TrustPrivacy/SitePages/M365-Privacy-Review-Process.aspx |
| Privacy Review When/How | aka.ms/M365TrustPrivacyWhenandHow |
| Data Scout FAQ | microsoft.sharepoint.com/teams/DataScout/SitePages/Frequently-asked-questions.aspx |
| Trust Decision Logs | docs.substrate.microsoft.net/docs/Office-365-compliance/Trust-Office-Hours/Trust-OH-DecisionLogs.html |
| Data Use Framework Contact | pradatatax@microsoft.com |
