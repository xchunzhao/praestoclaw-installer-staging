# Enterprise Data Taxonomy (Asset Classification Standard)
> Source: Enterprise Data Taxonomy (Asset Classification Standard).pdf, v3.94, April 30, 2025
> Scope: Microsoft Online Services Enterprise — when Microsoft acts as **Data Processor**
> Does NOT apply where Microsoft is acting as the Controller.

## Core Classification Rules

### Mandatory Classification
All data elements MUST be classified according to this taxonomy. After classification, data must be protected according to its classification-level Data Handling requirements.

### Mixed Datasets
If a dataset contains mixed classifications → protect using the **highest classification level present**.

### Inference Rule
Any inferred data produced through analytics must inherit the **same classification as its source data**.
- Example: Calendar data = Customer Content → inference "user dislikes 4 PM meetings" → still **Customer Content**.

### Contamination Model (Sensitivity Hierarchy)
```
Access Control Data (highest)
  > Customer Content
    > EUII
      > EUPI
        > OII
          > System Metadata (lowest)
```
Sensitivity can only be reduced by **removing** higher-classification data.

### Hashing/Salting Rules
- Encryption of EUII → still EUII
- Salted hash of EUII (salt internal) → becomes EUPI
- Hashed/salted Customer Content → still Customer Content

## Contractual Mapping
| Contractual Term | Taxonomy Types |
|---|---|
| Customer Data | Customer Content, EUII |

## Role Model
| Role | Description |
|---|---|
| C1 Admin | Customer tenant admin |
| C1 User | Licensed enterprise user |
| C2 User | Customer's customer |

## Data Types

### Access Control Data
**Classification:** Restricted Data
**Definition:** Data used to manage access to administrative roles and sensitive functions.
**Examples:** Microsoft-owned secrets (passwords, certificates, encryption keys, storage keys), partner-hosted cloud operator credentials.

### Customer Content
**Classification:** Customer Data / Restricted Data / Personal Data
**Definition:** Data provided or processed by C1 Admin, C1 User, or C2 User within Microsoft Online Services.
**Examples:** Customer-provided secrets, blob/structured storage data, tenant-specific ML models, biometric identifiers, email body/attachments, Teams chats/IM/voice, SharePoint file contents, uploaded images, user search queries, PHI, personal tax info, free-text meeting locations, tenant-associated application usage data.
**Note:** Hashed or salted+hashed customer content remains Customer Content.

### End User Identifiable Information (EUII)
**Classification:** Personal Data
**Definition:** Data that directly identifies an authenticated C1 user or C2 user (not C1 admin).
**Examples:** IPv4 user IP, IPv6 Interface ID, UPN, email subject line, username, display name, employee ID, address book data, lat/long location, machine name, SIP URI, IMEI/ICCID, document file name, GAL data, browser fingerprint.

### Support Data
**Classification:** Personal Data
**Definition:** Customer-provided data used during support engagements.
**Examples:** Support chats, phone conversations, remote assistance sessions, case notes, ticket-related artifacts.
**Note:** Case ID = System Metadata; Case title = Support Data.

### Feedback
**Classification:** Personal Data
**Definition:** User-submitted product feedback containing personal data.
**Examples:** Product reviews, surveys, DSAT interactions, ratings, suggest-a-feature submissions, crash feedback dialogs, screenshots/attachments.

### Account Data
**Classification:** Personal Data
**Definition:** Enterprise tenant billing/licensing/provisioning info.
**Examples:** Tenant provisioning info, billing data, admin contact details, licensing/purchase information.

### Public Personal Data
**Classification:** Personal Data
**Definition:** Publicly available personal data from external sources.
**Examples:** Public tweets, Facebook posts, YouTube videos, Instagram data, public LinkedIn profiles.

### End User Pseudonymous Identifiers (EUPI)
**Classification:** Personal Data
**Definition:** Microsoft-created identifiers tied to a user.
**Examples:** GUID, PUID, Machine ID, Device ID, Session ID, salted-hashed EUII leaving compliance boundary.

### Managed Service Data
**Classification:** Personal Data
**Definition:** Customer data accessed or exported for Managed Service engagements.
**Examples:** Support transcripts, remote assistance recordings, engagement artifacts.

### Organization Identifiable Information (OII)
**Definition:** Identifies tenant/organization. NOT linkable to a user. Contains no Customer Content.
**Examples:** Tenant ID, tenant usage data, tenant firewall IP, IPv6 subnet prefix, domain portion of email, org-GUID mappings, Azure resource names, Power BI report names, Entra displayName (Tenant/App/SP).

### System Metadata
**Definition:** Service-generated data not linkable to user or tenant.
**Examples:** Event logs, access logs, server names/IPs, usage telemetry, patch data, service config data, SQM data, Internet Message IDs.
**Note:** May contain employee personal data exempted from GDPR DSRs.

### Public Non-Personal Data
**Definition:** External public information containing no personal data.
**Examples:** Weather data, non-personal news, corporate earnings announcements.
