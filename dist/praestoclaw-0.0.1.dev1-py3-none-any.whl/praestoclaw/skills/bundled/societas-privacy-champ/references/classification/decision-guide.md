# Classification Decision Guide

Use this BEFORE classifying any data element in Data Scout or elsewhere. This file contains the two iron rules that govern the entire classification path.

---

## Rule 1 — Controller vs Processor FIRST

Every data element belongs to exactly **one side**. Never mix the two.

| | Controller (MSA) | Processor (AAD / Entra ID) |
|---|---|---|
| Who is Microsoft? | Data **controller** | Data **processor** (on behalf of enterprise customer) |
| User auth | MSA (Microsoft Account, consumer) | AAD / Entra ID |
| Taxonomy to use | **Controller Data Taxonomy** (`controller-taxonomy.md`) | **Enterprise Data Taxonomy** (`enterprise-taxonomy.md`) |
| Framework | **Controller Data Use Framework** (`data-scout-reference.md`) | **Data Handling Standards V5** (`data-handling-v5.md`) |
| Data Scout field | **#8 Consumer/Controller** | **#7 Enterprise** |

**Decision rules:**
- MSA → Controller
- AAD / Entra ID → Processor
- Dual-identity feature → decide **per data flow**, not once for the whole feature
- Unclear → stop and ask the user / champ

---

## Rule 2 — Allow-lists (use ONLY these terms)

### Controller side (field #8 only)

```
Customer Content · Credentials Data · Customer Contact List Data ·
Biometric Data · Device Connectivity and Configuration Data ·
Product and Service Usage Data · Product and Service Performance Data ·
Account Data / Customer Contact Data · Payment Instrument Data ·
Support Interaction Data · Support Content Data · Feedback and Ratings Data ·
Software Setup and Inventory Data · Demographic Information Data ·
Interests and Favorites Data · Content Consumption Data ·
Inking, Typing and Speech Utterance Data · Social Data ·
Fitness and Activity Data · Environmental Sensor Data ·
Licensing and Purchase Data · Browsing History Data ·
Search Requests and Query Data · Third Party Search Results Data ·
Precise User Location Data
```

Full definitions → `controller-taxonomy.md`.

### Processor side (field #7 only)

```
EUII · EUPI · OII · Customer Content · Account Data ·
Support Data · System Metadata · Public Personal Data
```

Full definitions → `enterprise-taxonomy.md`.

---

## OUTPUT GATE — run before producing any classification

For **each** data element, verify in order:

1. **What side?** Controller or Processor? Unknown → STOP, re-confirm.
2. **Which field?** #7 (Processor) or #8 (Controller). The other field = **N/A**.
3. **Term in the correct allow-list?** If using a Controller term in a Processor field (or vice versa) → **cross-contamination error**, fix.
4. **Semantic sanity:**
   - token / password / secret → **Credentials Data** (Controller) / appropriate Processor category
   - resource ID (driveId, itemId, webUrl) → **Product and Service Usage Data** (Controller)
   - user-created content → **Customer Content**
   - account/profile info → **Account Data** (Controller) / **EUII** (Processor)

If any step fails → correct before outputting. **Do not emit a classification that hasn't passed this gate.**

---

## Quick reference — same concept, different sides

| Concept | Controller term (MSA) | Processor term (AAD) |
|---|---|---|
| Identified end user | Account Data / Customer Contact Data | EUII |
| Pseudonymous end-user ID | (rare in Controller taxonomy — usually Product and Service Usage Data) | EUPI |
| Organization identifier | — | OII |
| User-created content | Customer Content | Customer Content |
| Auth secret | Credentials Data | (classify per specific term; often treated as EUII or similar — check) |
| System-generated resource ID | Product and Service Usage Data | OII (only if tied to customer org) or System Metadata |

When in doubt → go to the specific taxonomy file for examples.

---

## See also

- `common-mistakes.md` — real examples of misclassification and how to avoid them
- `data-scout-reference.md` — authoritative field-by-field guidance
- `controller-taxonomy.md` — full Controller definitions
- `enterprise-taxonomy.md` — full Processor definitions
- `data-handling-v5.md` — V5 handling obligations (Processor)
