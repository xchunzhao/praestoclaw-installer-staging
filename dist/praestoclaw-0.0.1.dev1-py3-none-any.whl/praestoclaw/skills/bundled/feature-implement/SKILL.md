---
name: feature-implement
description: |
  End-to-end SOP for implementing a non-trivial feature: scope → design → code → test → PR.
  Activates when the user asks to add, build, or implement a feature.
metadata:
  activation:
    keywords: [implement feature, add feature, build feature, 实现, 加一个, 新功能]
    patterns:
      - "(?i)\\b(implement|add|build|create)\\b.*\\b(feature|功能)\\b"
  workflow:
    phases: [scope, design, code, test, pr]
    requires_user_confirm: [scope, pr]
    max_turns: 200
---
## Feature Implementation SOP

When you recognize this is a feature-implementation task, follow this protocol **strictly**.

### Step 0 — Plan first

Before doing **anything else**, call:

```
plan(action="create", workflow="feature-implement", items=[
  {title: "Define scope: in-scope, out-of-scope, acceptance",
   acceptance: "Bullet list of what's in / out, with measurable acceptance criteria"},
  {title: "Design: data model, interfaces, file changes",
   acceptance: "List of files to add/modify and the public surface change"},
  {title: "Implement code changes",
   acceptance: "All listed files modified; lints clean"},
  {title: "Tests written and passing",
   acceptance: "pytest output shows new tests pass; relevant suite green"},
  {title: "PR draft: title, summary, rollback note",
   acceptance: "PR title + body + rollback paragraph ready to paste"}
])
```

### Phases

1. **scope** — Read existing code to ground yourself. Then write the scope item's acceptance bullets and call `plan(action="checkpoint", summary="Scope drafted: ...", next_step="awaiting confirmation", ask_user=true)`. **Do not write code yet.**
2. **design** — Sketch interfaces, file list, data flow. Update the design item with evidence (file list + interface signatures).
3. **code** — Make the actual edits. Group commits logically. Run lints/builds locally if possible.
4. **test** — Add or update tests. Capture the test command output as `evidence` for the test item.
5. **pr** — Compose PR title + body + rollback. Call `plan(action="checkpoint", summary="Ready to push", ask_user=true)` before any push.

### Reporting

- Every 5 tool calls or whenever you switch phase, call `plan(action="report", summary="...")`.
- On any blocked item, call `plan(action="update", id=..., status="blocked", note="why")`.
- Never mark `done` without `evidence` — the plan tool will reject it.
