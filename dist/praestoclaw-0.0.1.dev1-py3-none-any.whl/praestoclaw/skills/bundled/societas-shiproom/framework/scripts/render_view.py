"""Deterministic renderer for Societas Shiproom current/view.html.

This module intentionally hard-codes the page structure and CSS so different
agents cannot invent different dashboard layouts during /sr-prep.
"""

from __future__ import annotations

import datetime as dt
import html
import re
from dataclasses import dataclass

SECTION_SOURCES = {
    "todo": "current/updates/1-todo.md",
    "data": "current/updates/2-data.md",
    "ocv": "current/updates/3-ocv.md",
    "release": "current/updates/4-release.md",
    "gdpval": "current/updates/5-gdpval.md",
    "deep_worker": "current/updates/6-deep-worker.md",
    "others": "current/updates/7-others.md",
    "prep_summary": "current/updates/0-meeting-prep-summary.md",
    "loop": "current/currentloop.md",
}


@dataclass
class ViewInput:
    texts: dict[str, str]
    generated_at: dt.datetime | None = None
    archive_cutoff: dt.datetime | None = None  # set by render-view CLI from current/.last-archive


CSS = """
body{margin:0;background:#fff;color:#17212b;font:14px/1.55 "Segoe UI",Arial,sans-serif}
.page{max-width:1180px;margin:0 auto;padding:28px 32px 56px}
.toc{position:sticky;top:0;background:#fff;border-bottom:1px solid #c9d6e4;padding:10px 0;z-index:2}
.toc a{color:#0969da;text-decoration:none;margin-right:10px;white-space:nowrap}
h1{font-size:32px;margin:32px 0 8px}.meta{font-size:12px;color:#5f6b7a;border-bottom:1px solid #c9d6e4;padding-bottom:16px}
.top-risk{border:1px solid #f3c38c;background:#fff8f0;border-radius:6px;padding:16px 18px;margin:24px 0 34px}.top-risk h2{font-size:24px;margin:0 0 10px}
.section{border-top:3px solid #0969da;margin-top:36px;padding-top:24px}.section h2{background:#0969da;color:#fff;border-radius:4px;padding:10px 14px;margin:0 0 18px;font-size:24px}
h3{font-size:18px;margin:22px 0 10px;color:#0969da}
table{width:100%;border-collapse:collapse;margin:14px 0 22px}th,td{border:1px solid #d0d7de;padding:8px 10px;vertical-align:top}th{background:#f6f8fa;text-align:left}
.compact th,.compact td{font-size:13px;padding:5px 8px}
ul,ol{padding-left:24px}li{margin:6px 0}.warn{color:#b54708;font-weight:600}.bad{color:#cf222e;font-weight:600}.done,.good{color:#1a7f37;font-weight:600}.small{font-size:12px;color:#5f6b7a}.note{background:#f6f8fa;border-left:4px solid #8c959f;padding:10px 12px;margin:12px 0 18px}
.grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:14px;margin:14px 0}
.metric{border:1px solid #d0d7de;border-radius:8px;padding:10px 12px;background:#fbfcfe}
.metric h4{margin:0 0 8px;font-size:14px;color:#0969da}
.metric table{margin:0}
code{background:#eff1f3;padding:1px 5px;border-radius:3px;font-size:13px}
@media (max-width:780px){.grid{grid-template-columns:1fr}.toc{position:static}}
""".strip()


def render_view(payload: ViewInput) -> str:
    """Top-level wrapper. Per project policy: NEVER raise. If anything breaks
    we fall back to dumping the raw markdown so the user at least sees the
    real source content rather than a template page."""
    try:
        return _render_view_impl(payload)
    except Exception as exc:  # pragma: no cover - safety net
        return _render_view_fallback(payload, exc)


def _render_view_impl(payload: ViewInput) -> str:
    generated_at = payload.generated_at or dt.datetime.now().astimezone()
    texts = payload.texts
    title_date = generated_at.date().isoformat()
    cutoff = payload.archive_cutoff or _this_week_start()
    # Stash on a module global so legacy call sites (extract_manual_entries)
    # can read it without changing every signature.
    global _ACTIVE_CUTOFF
    _ACTIVE_CUTOFF = cutoff
    top_risk = render_top_risk(texts.get("prep_summary", ""), texts)
    body = f"""<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Shiproom {title_date}</title>
<style>{CSS}</style>
</head>
<body>
<main class="page">
<nav class="toc">
  <a href="#risk">Top Risk</a>
  <a href="#todo">①Todo</a>
  <a href="#data">②Data</a>
  <a href="#ocv">③OCV</a>
  <a href="#release">④Release</a>
  <a href="#deep-worker">⑤Deep Worker</a>
  <a href="#gdpval">⑥GDPVal</a>
  <a href="#others">⑦Others</a>
</nav>

<h1>Shiproom {html.escape(title_date)}</h1>
<p class="meta">Source: current Loop / Data / OCV files under SharePoint current/. Generated {html.escape(generated_at.isoformat(timespec="minutes"))}.</p>

<section id="risk" class="top-risk">
  <h2>Top Risk</h2>
  {top_risk}
</section>

{render_section("todo", "1. Todo", render_todo(texts.get("todo", ""), texts.get("prep_summary", "")))}
{render_section("data", "2. Data", render_data(texts.get("data", ""), texts.get("prep_summary", "")))}
{render_section("ocv", "3. OCV", render_ocv(texts.get("ocv", ""), texts.get("prep_summary", "")))}
{render_section("release", "4. Release", render_release(texts.get("release", ""), texts.get("prep_summary", "")))}
{render_section("deep-worker", "5. Deep Worker", render_deep_worker(texts.get("deep_worker", ""), texts.get("prep_summary", "")))}
{render_section("gdpval", "6. GDPVal", render_gdpval(texts.get("gdpval", ""), texts.get("others", ""), texts.get("prep_summary", "")))}
{render_section("others", "7. Others", render_others(texts.get("others", ""), texts.get("prep_summary", "")))}

</main>
</body>
</html>
"""
    return body


def _render_view_fallback(payload: ViewInput, exc: Exception) -> str:
    """Last-resort renderer used only if _render_view_impl raises. Dumps every
    raw source markdown verbatim. The user sees real content, not template
    waste text."""
    generated_at = payload.generated_at or dt.datetime.now().astimezone()
    title_date = generated_at.date().isoformat()
    sections = []
    for key, path in SECTION_SOURCES.items():
        raw = (payload.texts or {}).get(key, "") or ""
        if not raw.strip():
            continue
        sections.append(
            f'<section class="section"><h2>{html.escape(key)} ({html.escape(path)})</h2>'
            f'<pre style="white-space:pre-wrap;font:13px/1.45 Consolas,monospace;">'
            f"{html.escape(raw)}</pre></section>"
        )
    return (
        f'<!doctype html><html><head><meta charset="utf-8"><title>Shiproom {title_date} (raw)</title>'
        f'<style>{CSS}</style></head><body><main class="page">'
        f'<h1>Shiproom {html.escape(title_date)} <span class="small">(raw fallback)</span></h1>'
        f'<p class="note">Structured renderer failed: <code>{html.escape(type(exc).__name__)}: {html.escape(str(exc))}</code>. '
        f"Showing raw source markdown so the meeting can still proceed.</p>"
        + "".join(sections)
        + "</main></body></html>"
    )


def render_section(anchor: str, title: str, content: str) -> str:
    return f'<section id="{anchor}" class="section">\n<h2>{html.escape(title)}</h2>\n{content}\n</section>'


def render_top_risk(summary: str, texts: dict[str, str]) -> str:
    # Prep summary heading is e.g. "## 🚨 Top Risks (...)"; older variants used
    # "Top callout". Try both, fall back to generic guidance.
    items = extract_list_after_heading(summary, "Top Risks", limit=6)
    if not items:
        items = extract_list_after_heading(summary, "Top callout", limit=6)
    if has_current_data_report(texts.get("data", "")):
        items = [item for item in items if not is_stale_data_missing_risk(item)]
    if not items:
        # No matchable Top Risk heading. Rather than emit template waste text,
        # surface whatever bullets exist at the top of prep_summary so the user
        # at least sees real content. If even that is empty, return raw dump.
        items = _first_bullets_anywhere(summary, limit=6)
    if not items:
        if summary.strip():
            return f'<pre style="white-space:pre-wrap;font:13px/1.5 Consolas,monospace;">{html.escape(summary[:2000])}</pre>'
        return '<p class="note">prep_summary 为空，跑 <code>/sr-prep</code> 后再渲染。</p>'
    return "<ol>" + "".join(f"<li>{inline_md(item)}</li>" for item in items[:6]) + "</ol>"


def _first_bullets_anywhere(text: str, limit: int = 6) -> list[str]:
    out: list[str] = []
    for line in text.splitlines():
        m = re.match(r"\s*(?:\d+\.|[-*])\s+(.*)", line)
        if m:
            item = m.group(1).strip()
            if item:
                out.append(item)
                if len(out) >= limit:
                    break
    return out


def has_current_data_report(data_md: str) -> bool:
    return "Executive Overview" in data_md and "Key Takeaways" in data_md


def is_stale_data_missing_risk(item: str) -> bool:
    lowered = item.lower()
    return (
        "2-data 缺失" in item
        or "data 缺失" in item
        or "尚未上传" in item
        or "还没贴 usage" in item
        or "has not uploaded" in lowered
        or "missing data" in lowered
    )


def render_todo(todo_md: str, summary: str) -> str:
    text = clean_markdown(todo_md)
    intro = section_summary(summary, "1")
    rows = parse_todo_rows(text)
    if rows:
        table = table_html(["#", "Item", "Owner", "ETA", "Progress", "Notes / meeting ask"], rows)
    else:
        table = markdown_to_html(text)
    manual = extract_manual_entries(todo_md)
    return _intro_html(intro) + table + manual


def render_data(data_md: str, summary: str = "") -> str:
    intro = section_summary(summary, "2")
    overview = extract_between(data_md, r"##\s*.*Executive Overview", r"\n##\s+Slide\s+2\b")
    if not overview.strip():
        # No Executive Overview block — dump raw data_md so user sees real content.
        raw = clean_markdown(data_md)
        if raw.strip():
            return _intro_html(intro) + markdown_to_html(raw)
        return _intro_html(intro) + '<p class="note">2-data.md 为空。</p>'
    overview = re.sub(r"<!--\s*TAKEAWAYS:START\s*-->|<!--\s*TAKEAWAYS:END\s*-->", "", overview)
    grid_html = render_data_grid(overview)
    takeaways = extract_between(overview, r"###?\s+.*Key Takeaways", r"\n##\s+|\Z")
    takeaways_html = ""
    if takeaways.strip():
        takeaways_html = "<h3>Key Takeaways</h3>" + markdown_to_html(takeaways)
    if grid_html:
        return _intro_html(intro) + f"<h3>Executive Overview</h3>{grid_html}{takeaways_html}"
    return _intro_html(intro) + markdown_to_html(overview)


def render_data_grid(overview_md: str) -> str:
    """Pick out the 4 'COLUMN N: <name>' tables and lay them out as a 2x2 grid
    of metric cards. Returns empty string if the layout cannot be detected."""
    col_pat = re.compile(
        r"COLUMN\s+\d+[:：]\s*([^\n]+?)\n(.*?)(?=COLUMN\s+\d+[:：]|##\s|\Z)", re.S | re.I
    )
    cards: list[str] = []
    for m in col_pat.finditer(overview_md):
        title = re.sub(r"^[^A-Za-z\u4e00-\u9fa5]+", "", m.group(1).strip()).strip()
        body_md = m.group(2).strip()
        # Drop ad-hoc notes lines (start with ⚠ / NOTE) before the table.
        body_md = re.sub(r"^[^\n|]*$\n", "", body_md, count=1, flags=re.M)
        table = first_markdown_table(body_md)
        if not table:
            continue
        headers, rows = table
        # Re-render the table compactly with status-colored cell where possible.
        thead = "<tr>" + "".join(f"<th>{html.escape(h)}</th>" for h in headers) + "</tr>"
        body_rows = []
        for row in rows:
            # Color the WoW cell based on the row's Status emoji (🔴 / 🟢),
            # because for negative metrics (failure rates) a "+" is BAD.
            row_text = " ".join(row)
            row_cls = ""
            if "🔴" in row_text or re.search(r"\bdown\b", row_text, re.I):
                row_cls = "bad"
            elif "🟢" in row_text or re.search(r"\bup\b|goal|completed", row_text, re.I):
                row_cls = "good"
            cells_html = []
            for idx, cell_val in enumerate(row):
                hl = headers[idx].lower() if idx < len(headers) else ""
                cls = ""
                if hl in {"wow", "status"} and row_cls:
                    cls = f' class="{row_cls}"'
                cells_html.append(f"<td{cls}>{html.escape(cell_val)}</td>")
            body_rows.append("<tr>" + "".join(cells_html) + "</tr>")
        compact_table = (
            f'<table class="compact"><thead>{thead}</thead>'
            f"<tbody>{''.join(body_rows)}</tbody></table>"
        )
        cards.append(f'<div class="metric"><h4>{html.escape(title)}</h4>{compact_table}</div>')
    if len(cards) < 2:
        return ""
    return '<div class="grid">' + "".join(cards) + "</div>"


def render_ocv(ocv_md: str, summary: str = "") -> str:
    intro = section_summary(summary, "3")
    text = clean_markdown(ocv_md)
    table = first_markdown_table(text)
    rows_html = ""
    if table:
        headers, rows = table
        col = {name.lower(): idx for idx, name in enumerate(headers)}
        wanted = []
        for row in rows:
            row_type = cell(row, col, "type")
            title = cell(row, col, "title")
            if "problem" in row_type.lower() or "error" in title.lower() or "busy" in title.lower():
                wanted.append(
                    [
                        cell(row, col, "items"),
                        cell(row, col, "trend"),
                        title,
                        f"{cell(row, col, 'type')} / {cell(row, col, 'state')}",
                        cell(row, col, "bugs") or cell(row, col, "comments"),
                    ]
                )
        rows_html = table_html(
            ["Items", "Trend", "Title", "Type / State", "Bug ID / note"], wanted[:8]
        )
    if not rows_html:
        rows_html = markdown_to_html(text)
    return _intro_html(intro) + rows_html


def render_release(release_md: str, summary: str = "") -> str:
    intro = section_summary(summary, "4")
    text = clean_markdown(release_md)
    consumer = extract_between(text, r"###\s+Consumer Release", r"\n###\s+")
    lab_intro = extract_between(text, r"###\s+Lab Release plan", r"\n###\s+|\Z")
    pending_marks = list(re.finditer(r"###\s+Pending release[^\n]*\n", text, re.I))
    lab_pending = ""
    if len(pending_marks) >= 2:
        lab_pending = text[pending_marks[1].end() :]
    html_parts = [_intro_html(intro)]
    consumer_html = render_consumer_release(consumer)
    if consumer_html:
        html_parts.append("<h3>Consumer Release Status</h3>" + consumer_html)
    lab_html = render_lab_release(lab_intro, lab_pending)
    if lab_html:
        html_parts.append("<h3>Lab Release Plan (Rick Yang)</h3>" + lab_html)
    # If neither structured block parsed, fall back to raw release_md so the
    # user still sees real content rather than only the intro.
    if not consumer_html and not lab_html and text.strip():
        html_parts.append(markdown_to_html(text))
    return "".join(html_parts)


def render_consumer_release(text: str) -> str:
    text = text.strip()
    if not text:
        return ""
    bug_pat = re.compile(r"Bug\s+(\d+):\s*(.+)", re.I)
    bugs = bug_pat.findall(text)
    status_match = re.search(r"Status:\s*([^\n]+)", text, re.I)
    release_match = re.search(r"Release\s+(\S+)", text)
    feature_match = re.search(r"Feature list:\s*([^\n]+)", text, re.I)
    status = status_match.group(1).strip() if status_match else "-"
    release = release_match.group(1).strip() if release_match else "-"
    feature = feature_match.group(1).strip() if feature_match else "-"
    summary = (
        f"<p>Consumer Release <strong>{html.escape(release)}</strong> 当前 <strong>{html.escape(status)}</strong>；"
        f"主 feature: {html.escape(feature)}。下列 bug 待收口，需在会上确认是否阻塞发版。</p>"
    )
    if not bugs:
        return summary
    rows = "".join(
        f"<tr><td>Bug {html.escape(bid)}</td><td>Open</td><td>{html.escape(desc.strip())}</td></tr>"
        for bid, desc in bugs
    )
    table = (
        "<table><thead><tr><th>Bug</th><th>Status</th><th>Title</th></tr></thead>"
        f"<tbody>{rows}</tbody></table>"
    )
    return summary + table


def render_lab_release(intro_text: str, pending_text: str) -> str:
    intro_text = intro_text.strip()
    parts: list[str] = []
    if intro_text:
        cleaned = re.sub(r"_\(from Loop[^_]*\)_", "", intro_text)
        cleaned = re.sub(r"\s+", " ", cleaned).strip()
        if cleaned:
            parts.append(f"<p>{html.escape(cleaned)}</p>")
    rows = parse_pending_release_blocks(pending_text)
    if rows:
        body = "".join(
            "<tr>"
            f"<td>{html.escape(r['num'])}</td>"
            f"<td>{html.escape(r['feature'])}</td>"
            f"<td>{html.escape(r['owner'])}</td>"
            f"<td>{html.escape(r['status'])}</td>"
            f"<td>{html.escape(r['timeline'])}</td>"
            f"<td>{html.escape(r['comments'])}</td>"
            "</tr>"
            for r in rows
        )
        parts.append(
            "<table><thead><tr><th>#</th><th>Feature</th><th>Owner</th>"
            "<th>Status</th><th>Timeline</th><th>Comments</th></tr></thead>"
            f"<tbody>{body}</tbody></table>"
        )
    return "".join(parts)


def parse_pending_release_blocks(text: str) -> list[dict]:
    text = text.strip()
    if not text:
        return []
    paras = [p.strip() for p in re.split(r"\n\s*\n", text) if p.strip()]
    rows: list[dict] = []
    i = 0
    # Skip leading column headers (Features / Owner / Status / Timeline / Comments)
    while i < len(paras) and not re.fullmatch(r"\d+", paras[i]):
        i += 1
    while i < len(paras):
        if not re.fullmatch(r"\d+", paras[i]):
            i += 1
            continue
        num = paras[i]
        j = i + 1
        chunks: list[str] = []
        while j < len(paras) and not re.fullmatch(r"\d+", paras[j]):
            chunks.append(paras[j])
            j += 1
        feature = squash(chunks[0]) if chunks else ""
        owner = collapse_owner(chunks[1]) if len(chunks) > 1 else ""
        status = ""
        timeline = ""
        comments_parts: list[str] = []
        for c in chunks[2:]:
            cs = squash(c)
            if not status and re.match(r"progress\s*:", cs, re.I):
                status = re.sub(r"^progress\s*:\s*", "", cs, flags=re.I)
            elif not timeline and re.search(
                r"ETA|Branch|Graph API|Tech investigation|spec confirmed|In testing", cs, re.I
            ):
                timeline = cs
            else:
                comments_parts.append(cs)
        rows.append(
            {
                "num": num,
                "feature": feature,
                "owner": owner,
                "status": status or "-",
                "timeline": timeline or "-",
                "comments": " · ".join(comments_parts) or "-",
            }
        )
        i = j
    return rows


def squash(text: str) -> str:
    return re.sub(r"\s+", " ", text).strip()


def collapse_owner(text: str) -> str:
    # Loop alias dumps owners as initials + full name interleaved on separate lines.
    # Keep just the full names.
    lines = [ln.strip() for ln in text.splitlines() if ln.strip()]
    names: list[str] = []
    for ln in lines:
        if re.fullmatch(r"[A-Z]{2,3}", ln):
            continue
        names.append(ln)
    seen = []
    for n in names:
        if n not in seen:
            seen.append(n)
    return ", ".join(seen)


def render_deep_worker(deep_md: str, summary: str = "") -> str:
    text = clean_markdown(deep_md)
    manual = extract_manual_entries(deep_md)
    intro = section_summary(summary, "6")
    return _intro_html(intro) + markdown_to_html(text) + manual


def render_gdpval(gdp_md: str, others_md: str, summary: str = "") -> str:
    text = clean_markdown(gdp_md)
    excel = extract_heading_block(clean_markdown(others_md), "Excel agent")
    if excel:
        text = text.rstrip() + "\n\n### Excel Agent\n" + excel.strip() + "\n"
    intro = section_summary(summary, "5")
    return _intro_html(intro) + markdown_to_html(text)


def render_others(others_md: str, summary: str = "") -> str:
    text = clean_markdown(others_md)
    text = remove_heading_block(text, "Excel agent")
    intro = section_summary(summary, "7")
    if not text.strip():
        return _intro_html(intro) + "<p><em>本周无其他更新。</em></p>"
    return _intro_html(intro) + markdown_to_html(text)


def _intro_html(intro: str) -> str:
    """Emit intro markup. Never emit template waste.
    - empty/whitespace → nothing
    - already-built `<ul>...</ul>` (multi-bullet case from section_summary) → passthrough
    - single-line text → wrap as `<p>`
    """
    if not intro or not intro.strip():
        return ""
    if intro.lstrip().startswith("<ul>"):
        return intro
    return f"<p>{inline_md(intro)}</p>"


def clean_markdown(text: str) -> str:
    # Strip everything after the LOOP-SYNC end marker — that region is owned by
    # extract_manual_entries() (which applies a freshness filter). Keeping it
    # here would double-render manual updates AND bypass the freshness filter.
    if "<!-- END LOOP-SYNC -->" in text:
        text = text.split("<!-- END LOOP-SYNC -->", 1)[0]
    lines = []
    for line in text.replace("\r\n", "\n").split("\n"):
        stripped = line.strip()
        if stripped in {"<!-- BEGIN LOOP-SYNC -->", "<!-- END LOOP-SYNC -->"}:
            continue
        if stripped.startswith("<!--") or stripped.startswith("_Source:"):
            continue
        if stripped.startswith("# "):
            continue
        lines.append(line)
    return "\n".join(lines).strip()


def extract_manual_entries(text: str) -> str:
    """Pull entries written after the LOOP-SYNC block (these come from
    `/sr-update`). Filters out blocks dated before this ISO week's Monday so
    last-week notes don't bleed into this week's view (this is the carry-forward
    archive safety net — see prep.md / archive.md)."""
    if "<!-- END LOOP-SYNC -->" not in text:
        return ""
    tail = text.split("<!-- END LOOP-SYNC -->", 1)[1].strip()
    if not tail:
        return ""
    fresh = _filter_fresh_manual_blocks(tail)
    if not fresh.strip():
        return ""
    return "<h3>Manual updates</h3>" + markdown_to_html(fresh)


def _this_week_start() -> dt.datetime:
    today = dt.date.today()
    monday = today - dt.timedelta(days=today.weekday())
    return dt.datetime.combine(monday, dt.time.min)


# Set by _render_view_impl before any extract_manual_entries call. Defaults to
# this week's Monday so unit tests / legacy callers still work.
_ACTIVE_CUTOFF: dt.datetime = _this_week_start()


_MANUAL_HEAD_RE = re.compile(r"^###\s+@\S+\s+·\s+(\S+)\s*$", re.M)


def _filter_fresh_manual_blocks(text: str) -> str:
    """Split tail on `### @user · ISO` headings; keep only blocks whose ISO
    timestamp is >= the active cutoff (last `/sr-archive` time, or this week's
    Monday if no archive marker exists). Blocks without a parseable timestamp
    are kept (conservative — prefer showing too much over hiding fresh content).
    """
    cutoff = _ACTIVE_CUTOFF
    cutoff_naive = cutoff.replace(tzinfo=None) if cutoff.tzinfo else cutoff
    matches = list(_MANUAL_HEAD_RE.finditer(text))
    if not matches:
        return text
    kept_chunks: list[str] = []
    if matches[0].start() > 0:
        preamble = text[: matches[0].start()].strip()
        if preamble:
            kept_chunks.append(preamble)
    for idx, m in enumerate(matches):
        ts_raw = m.group(1)
        end = matches[idx + 1].start() if idx + 1 < len(matches) else len(text)
        block = text[m.start() : end].rstrip()
        try:
            ts = dt.datetime.fromisoformat(ts_raw.replace("Z", "+00:00"))
            ts_naive = ts.replace(tzinfo=None) if ts.tzinfo else ts
            if ts_naive < cutoff_naive:
                continue  # stale: older than the last archive cutoff — drop
        except ValueError:
            pass  # unparseable — keep, don't silently lose content
        kept_chunks.append(block)
    return "\n\n".join(kept_chunks)


def extract_list_after_heading(text: str, heading: str, limit: int = 5) -> list[str]:
    pattern = re.compile(rf"^##+\s+.*{re.escape(heading)}.*$", re.I | re.M)
    match = pattern.search(text)
    if not match:
        return []
    tail = text[match.end() :]
    stop = re.search(r"^##\s+", tail, re.M)
    block = tail[: stop.start()] if stop else tail
    items = []
    for line in block.splitlines():
        m = re.match(r"\s*(?:\d+\.|[-*])\s+(.*)", line)
        if m:
            items.append(m.group(1).strip())
            if len(items) >= limit:
                break
    return items


_CIRCLED = {"1": "①", "2": "②", "3": "③", "4": "④", "5": "⑤", "6": "⑥", "7": "⑦"}


def section_summary(summary: str, section_number: str, fallback: str = "") -> str:
    """Find the per-section block in the prep summary and return an intro
    snippet for the dashboard. Supports `### 1 — Title`, `## ① Title (1-todo)`,
    and `## ... (1-todo)` heading shapes.

    Output rules (per project policy — NEVER emit template waste text):
      * 0 bullets / 0 paragraph found  → return fallback (default empty string).
      * 1 bullet                       → return that bullet as plain string
                                          (rendered as `<p>` by _intro_html).
      * ≥2 bullets                     → return a sentinel string starting with
                                          "<ul>" so each bullet is its own list
                                          item (avoids dense one-paragraph dump).
    """
    circled = _CIRCLED.get(section_number, "")
    patterns = [
        rf"^###\s+{re.escape(section_number)}\s+[—-].*$",
        rf"^##\s+{re.escape(circled)}\s+.*\({section_number}-[\w-]+\).*$" if circled else None,
        rf"^##\s+.*\({section_number}-[\w-]+\).*$",
    ]
    match = None
    for pat in patterns:
        if not pat:
            continue
        match = re.search(pat, summary, re.M)
        if match:
            break
    if not match:
        return fallback
    tail = summary[match.end() :]
    stop = re.search(r"^##\s+|^###\s+\d+\s+[—-]", tail, re.M)
    block = tail[: stop.start()] if stop else tail
    bullets = extract_bullets(block)
    if len(bullets) >= 2:
        return "<ul>" + "".join(f"<li>{inline_md(b)}</li>" for b in bullets) + "</ul>"
    if len(bullets) == 1:
        return bullets[0]
    for para in re.split(r"\n\s*\n", block.strip()):
        para = para.strip()
        if para and not para.startswith("|") and not para.startswith("#"):
            return re.sub(r"\s+", " ", para)
    return fallback


def extract_bullets(block: str) -> list[str]:
    out = []
    for line in block.splitlines():
        m = re.match(r"\s*[-*]\s+(.*)", line)
        if m:
            out.append(m.group(1).strip())
    return out


def extract_between(text: str, start_pat: str, end_pat: str) -> str:
    start = re.search(start_pat, text, re.I | re.M)
    if not start:
        return ""
    tail = text[start.end() :]
    end = re.search(end_pat, tail, re.I | re.M)
    return tail[: end.start()] if end else tail


def extract_heading_block(text: str, heading: str) -> str:
    match = re.search(rf"^###\s+{re.escape(heading)}\s*$", text, re.I | re.M)
    if not match:
        return ""
    tail = text[match.end() :]
    stop = re.search(r"^###\s+", tail, re.M)
    return tail[: stop.start()] if stop else tail


def remove_heading_block(text: str, heading: str) -> str:
    pattern = re.compile(rf"^###\s+{re.escape(heading)}\s*$", re.I | re.M)
    match = pattern.search(text)
    if not match:
        return text
    tail = text[match.end() :]
    stop = re.search(r"^###\s+", tail, re.M)
    end = match.end() + (stop.start() if stop else len(tail))
    return text[: match.start()] + text[end:]


def parse_todo_rows(text: str) -> list[list[str]]:
    items_block = extract_between(text, r"###\s+Action Items", r"\n###\s+|\Z") or text
    lines = [ln.strip() for ln in items_block.splitlines() if ln.strip()]
    starts = [idx for idx, ln in enumerate(lines) if re.fullmatch(r"\d+", ln)]
    rows = []
    for pos, start in enumerate(starts):
        end = starts[pos + 1] if pos + 1 < len(starts) else len(lines)
        chunk = lines[start + 1 : end]
        if not chunk:
            continue
        item = chunk[0]
        rest = chunk[1:]
        owner, eta, progress, notes = "-", "-", "-", ""
        progress_idx = next(
            (
                i
                for i, val in enumerate(rest)
                if val.lower() in {"in progress", "completed", "not started"}
            ),
            None,
        )
        if progress_idx is not None:
            progress = rest[progress_idx]
            before = rest[:progress_idx]
            after = rest[progress_idx + 1 :]
            eta_idx = next(
                (
                    i
                    for i, val in enumerate(before)
                    if re.search(r"\d{4}年|\d{4}-\d{2}-\d{2}|ETA|周", val, re.I)
                ),
                None,
            )
            if eta_idx is not None:
                eta = " ".join(before[eta_idx : eta_idx + 1])
                owner = " / ".join(before[:eta_idx]) or "-"
            else:
                owner = " / ".join(before) or "-"
            notes = " ".join(after)
        else:
            owner = " / ".join(rest[:2]) if rest else "-"
            notes = " ".join(rest[2:])
        rows.append([str(len(rows) + 1), item, owner, eta, progress, notes])
    return rows


def markdown_to_html(text: str) -> str:
    lines = text.strip().splitlines()
    out: list[str] = []
    paragraph: list[str] = []
    idx = 0
    while idx < len(lines):
        line = lines[idx]
        if is_table_start(lines, idx):
            flush_paragraph(out, paragraph)
            headers, rows, consumed = parse_table_at(lines, idx)
            out.append(table_html(headers, rows))
            idx += consumed
            continue
        stripped = line.strip()
        if not stripped:
            flush_paragraph(out, paragraph)
        elif stripped.startswith("### "):
            flush_paragraph(out, paragraph)
            out.append(f"<h3>{inline_md(stripped[4:].strip())}</h3>")
        elif stripped.startswith("## "):
            flush_paragraph(out, paragraph)
            out.append(f"<h3>{inline_md(stripped[3:].strip())}</h3>")
        elif re.match(r"^[-*]\s+", stripped):
            flush_paragraph(out, paragraph)
            bullets = []
            while idx < len(lines) and re.match(r"^\s*[-*]\s+", lines[idx].strip()):
                bullets.append(re.sub(r"^[-*]\s+", "", lines[idx].strip()))
                idx += 1
            out.append("<ul>" + "".join(f"<li>{inline_md(b)}</li>" for b in bullets) + "</ul>")
            continue
        else:
            paragraph.append(stripped)
        idx += 1
    flush_paragraph(out, paragraph)
    return "\n".join(out) or "<p><em>本周无更新。</em></p>"


def flush_paragraph(out: list[str], paragraph: list[str]) -> None:
    if paragraph:
        out.append(f"<p>{inline_md(' '.join(paragraph))}</p>")
        paragraph.clear()


def inline_md(text: str) -> str:
    escaped = html.escape(text)
    escaped = re.sub(r"\*\*(.+?)\*\*", r"<strong>\1</strong>", escaped)
    escaped = re.sub(r"`([^`]+)`", r"<code>\1</code>", escaped)
    escaped = re.sub(r"\[([^\]]+)\]\(([^)]+)\)", r'<a href="\2">\1</a>', escaped)
    return escaped


def first_markdown_table(text: str) -> tuple[list[str], list[list[str]]] | None:
    lines = text.splitlines()
    for idx in range(len(lines)):
        if is_table_start(lines, idx):
            headers, rows, _ = parse_table_at(lines, idx)
            return headers, rows
    return None


def is_table_start(lines: list[str], idx: int) -> bool:
    return (
        idx + 1 < len(lines)
        and lines[idx].lstrip().startswith("|")
        and re.match(r"^\s*\|?\s*:?-{3,}:?", lines[idx + 1]) is not None
    )


def parse_table_at(lines: list[str], idx: int) -> tuple[list[str], list[list[str]], int]:
    headers = split_table_row(lines[idx])
    rows: list[list[str]] = []
    consumed = 2
    for line in lines[idx + 2 :]:
        if not line.lstrip().startswith("|"):
            break
        rows.append(split_table_row(line))
        consumed += 1
    return headers, rows, consumed


def split_table_row(line: str) -> list[str]:
    line = line.strip().strip("|")
    return [cell.strip() for cell in line.split("|")]


def table_html(headers: list[str], rows: list[list[str]]) -> str:
    if not rows:
        return ""
    head = "".join(f"<th>{inline_md(h)}</th>" for h in headers)
    body = []
    for row in rows:
        padded = row + [""] * max(0, len(headers) - len(row))
        body.append(
            "<tr>" + "".join(f"<td>{inline_md(c)}</td>" for c in padded[: len(headers)]) + "</tr>"
        )
    return f"<table><thead><tr>{head}</tr></thead><tbody>{''.join(body)}</tbody></table>"


def cell(row: list[str], col: dict[str, int], name: str) -> str:
    idx = col.get(name)
    if idx is None or idx >= len(row):
        return ""
    return row[idx]
