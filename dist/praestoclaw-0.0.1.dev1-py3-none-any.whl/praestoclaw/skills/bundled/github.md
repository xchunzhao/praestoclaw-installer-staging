---
name: github
description: GitHub PRs, issues, reviews, releases, and repo operations via gh CLI
metadata:
  activation:
    keywords: [github, gh, gist, github actions]
    patterns:
      - "(?i)\\bgithub\\.com/[\\w-]+/[\\w-]+"
      - "(?i)\\bgh\\s+(pr|issue|release|repo|gist|search|run|api)\\b"
      - "(?i)\\b(create|open|list|show|close|merge|review)\\s+(\\w+\\s+)?(pr|pull\\s*request)s?\\b"
      - "(?i)\\b(create|open|list|show|close)\\s+(\\w+\\s+)?issues?\\b"
      - "(?i)\\bmy\\s+(pr|pull\\s*request|issue)s?\\b"
    context:
      git-remote: ["github\\.com"]
      files: [".github", ".github/workflows"]
  requires:
    bins: [gh]
  superseded-by:
    tools: [MCP_github]
  # Read-only `gh` commands are safe to chain without per-call approval.
  # These already score ≤1 via shell pattern matching; declaring them here
  # also covers `gh search`, `gh workflow` and `gh gist` calls which the
  # shell regex doesn't cover.
  #
  # Each verb is anchored by a CONSUMING-but-BOUNDED tail
  # `(?:[ \t][^;|&$`<>\n\r]*)?\Z` for three reasons:
  #   1. AllowlistManager._matches uses ``re.fullmatch``, so the pattern
  #      MUST consume the whole input.  A zero-width lookahead like
  #      ``(?=\s|$)`` leaves trailing args unconsumed and fullmatch fails
  #      for legitimate calls like ``gh pr view 42``.
  #   2. The leading ``[ \t]`` (NOT ``\s``) deliberately rejects newlines
  #      and other whitespace forms — otherwise ``gh pr list\nrm -rf /``
  #      would fullmatch (``\s`` matches ``\n``) and bypass approval.
  #   3. ``[^;|&$`<>\n\r]+`` rejects shell metacharacters in the tail so
  #      ``gh pr list ; rm -rf /`` cannot bypass via compound chaining.
  # Inter-token separators also use ``[ \t]+`` (not ``\s+``) for the same
  # reason — keeps the rejected-character set uniform across the regex.
  # Hyphen-extension verbs (e.g. a future ``gh release view-secrets``)
  # still don't match because the verb group ends at a literal alternation
  # and the next char must be either end-of-string or a single space.
  #
  # SECURITY — `gh api` is intentionally NOT in this allowlist.
  #
  # `gh api` has too many syntactically-valid mutation forms (-X POST,
  # -XPOST, -X=POST, --method POST, -f / -F / --field / --raw-field /
  # --input which auto-promote to POST, the `graphql` endpoint which is
  # always POST, X-HTTP-Method-Override headers honoured by GHES, …).
  # Every regex we tried was bypassable through shell-level string
  # concatenation that the regex cannot see, e.g.
  #     gh api -X DEL''''ETE repos/o/r
  #     gh api repos/o/r -''f title=evil
  #     gh api repos/o/r --raw''-field x=1
  # All of those collapse to working POST/DELETE calls AFTER the shell
  # has unquoted them, but the regex still sees `DEL''''ETE`, `-''f`,
  # `--raw''-field` and lets them through any negative-lookahead.  See
  # tests/test_skills.py::TestBundledSafeToolsRedTeam (the
  # `test_github_gh_api_method_override_header_never_bypasses` and
  # `test_github_gh_api_never_short_circuits` parametrised tests) for
  # the red-team matrix that pins this property.  Until ShellTool gains
  # real argv tokenisation, all `gh api` calls must go through the
  # LLM-scored approval pipeline.
  safe-tools:
    - tool: shell
      match:
        command: "^gh[ \\t]+(pr|issue|repo|run|release|workflow|gist)[ \\t]+(list|view|status|checks|diff|log)(?:[ \\t][^;|&$`<>\\n\\r]*)?\\Z"
    - tool: shell
      match:
        command: "^gh[ \\t]+search[ \\t]+(prs|issues|code|commits|repos)(?:[ \\t][^;|&$`<>\\n\\r]*)?\\Z"
    - tool: shell
      match:
        command: "^gh[ \\t]+auth[ \\t]+status(?:[ \\t][^;|&$`<>\\n\\r]*)?\\Z"
---
## GitHub Operations

Use the `shell` tool with `gh` CLI commands. Output is JSON by default with `--json`.

### Authentication

```
gh auth status                         # check current auth
gh auth login                          # interactive login
```

### Pull Requests

Create:
```
gh pr create --title "feat: add X" --body "## Summary\n- ...\n\n## Test Plan\n- ..." --base main
gh pr create --fill                    # auto-fill from commits
gh pr create --draft                   # draft PR
gh pr create --reviewer user1,user2
```

List & View:
```
gh pr list --state open --json number,title,author,updatedAt
gh pr view {NUMBER} --json title,body,state,reviews,mergeable,statusCheckRollup
gh pr view {NUMBER} --comments        # show review comments
gh pr diff {NUMBER}                    # show diff
```

Review:
```
gh pr review {NUMBER} --approve
gh pr review {NUMBER} --request-changes --body "..."
gh pr review {NUMBER} --comment --body "..."
gh pr checks {NUMBER}                  # CI status
```

Merge & Close:
```
gh pr merge {NUMBER} --squash --delete-branch
gh pr merge {NUMBER} --merge           # merge commit
gh pr merge {NUMBER} --rebase
gh pr close {NUMBER}
```

### Issues

Create:
```
gh issue create --title "Bug: ..." --body "## Steps\n1. ...\n\n## Expected\n...\n\n## Actual\n..."
gh issue create --label bug,priority:high --assignee @me
```

List & View:
```
gh issue list --state open --json number,title,labels,assignees,updatedAt
gh issue list --label "bug" --assignee @me
gh issue view {NUMBER} --json title,body,state,comments
```

Update & Close:
```
gh issue close {NUMBER} --reason completed
gh issue edit {NUMBER} --add-label "in-progress" --add-assignee @me
gh issue comment {NUMBER} --body "Fixed in #456"
```

### Repo Operations

```
gh repo view --json name,description,defaultBranchRef
gh repo clone {OWNER}/{REPO}
gh repo fork {OWNER}/{REPO} --clone
```

### Releases

```
gh release list --json tagName,name,publishedAt
gh release view {TAG}
gh release create {TAG} --title "v1.0" --notes "## Changes\n- ..."
gh release create {TAG} --generate-notes    # auto-generate from commits
gh release upload {TAG} ./dist/*.tar.gz
```

### Gists

```
gh gist create {FILE} --public --desc "..."
gh gist list --json id,description,updatedAt
gh gist view {ID}
```

### Searches

```
gh search prs --repo {OWNER}/{REPO} --state open --json number,title
gh search issues --label "bug" --state open --json number,title,repository
gh search code "pattern" --repo {OWNER}/{REPO}
```

### Cross-Repo References

When given a GitHub URL, extract owner/repo/number:
```
# https://github.com/owner/repo/pull/123
gh pr view 123 --repo owner/repo --json title,body,state
# https://github.com/owner/repo/issues/456
gh issue view 456 --repo owner/repo --json title,body,state
```

### Guidelines
- Use `--json` fields to get structured output; pipe to `jq` for filtering
- Use `--jq` for inline filtering: `gh pr list --json number,title --jq '.[].title'`
- Link issues in PR body with `Fixes #123` or `Closes #456`
- Draft PRs for work-in-progress: `--draft`
- Read operations (list, view, search) are low-risk
- Write operations (create, edit, comment) are medium-risk — confirm with user
- Destructive operations (close, merge, delete-branch) are high-risk — always confirm
- Use `--repo owner/repo` for cross-repo operations
