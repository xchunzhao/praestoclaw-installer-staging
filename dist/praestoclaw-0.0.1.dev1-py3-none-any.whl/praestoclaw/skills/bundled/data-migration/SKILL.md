---
name: data-migration
description: |
  Safe data migration / schema change / bulk import: dry-run → sample → full run → verify counts → cleanup.
  Activates for migration, import/export, schema change requests.
metadata:
  activation:
    keywords: [migration, migrate data, import data, schema change, backfill, 迁移, 数据迁移, 导入数据]
    patterns:
      - "(?i)\\b(migrate|backfill|import|export)\\b.*\\b(data|table|database|schema)\\b"
      - "(?i)\\bschema\\s+(change|migration)\\b"
  workflow:
    phases: [dry_run, sample, full, verify, cleanup]
    requires_user_confirm: [full, cleanup]
    max_turns: 120
---
## Data Migration SOP

### Step 0 — Plan first

```
plan(action="create", workflow="data-migration", items=[
  {title: "Dry-run on empty / mocked target",
   acceptance: "Migration script runs cleanly with no writes; logs reviewed"},
  {title: "Sample run on small subset (e.g. 100 rows)",
   acceptance: "Sample completes; spot-check shows correct transformations"},
  {title: "Full run with backup + rollback plan",
   acceptance: "Backup taken; full run completes; logs preserved"},
  {title: "Verify counts and integrity",
   acceptance: "Source/target row counts match; sampling shows correct values"},
  {title: "Cleanup temp data + document migration",
   acceptance: "Temp tables/files removed; runbook entry added"}
])
```

### Hard rules

1. **No bare full-runs.** Dry-run + sample-run are mandatory before `full`. The plan tool's checkpoint(ask_user=true) is required before `full` and `cleanup`.
2. **Always take a backup before `full`.** Capture backup location as evidence on the full-run item.
3. **Verify with counts AND sampling.** Counts alone hide silent data corruption.
4. **Preserve logs.** Migration logs are evidence — attach them to the verify item.

### Anti-patterns

- ❌ Skipping dry-run because "the script is simple"
- ❌ Marking full-run done without count verification
- ❌ Cleanup before verification
