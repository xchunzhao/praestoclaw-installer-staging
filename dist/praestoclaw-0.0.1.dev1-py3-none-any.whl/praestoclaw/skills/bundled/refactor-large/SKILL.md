---
name: refactor-large
description: |
  Safe execution of large refactors: inventory → plan → stepwise small edits → verify each step → keep rollback ready.
  Activates for big refactors, package splits, or large migrations.
metadata:
  activation:
    keywords: [refactor, restructure, split package, large refactor, 重构, 拆分, 迁移]
    patterns:
      - "(?i)\\b(major|large|big)\\s+(refactor|rewrite|restructure)\\b"
      - "(?i)\\b(split|extract|move)\\s+(package|module)\\b"
  workflow:
    phases: [inventory, plan, stepwise, verify, finalize]
    requires_user_confirm: [plan, finalize]
    max_turns: 300
---
## Large Refactor SOP

### Step 0 — Plan first

```
plan(action="create", workflow="refactor-large", items=[
  {title: "Inventory: list affected files + dependencies",
   acceptance: "Complete file list + import graph snapshot"},
  {title: "Refactor plan with reversible steps (≤5 files each)",
   acceptance: "Numbered step list, each independently testable"},
  {title: "Execute steps one at a time, lint/test after each",
   acceptance: "All steps committed; tests green at each commit"},
  {title: "Full verification: tests, lints, smoke run",
   acceptance: "Full test suite output + lint output, both clean"},
  {title: "Finalize: docs / changelog / migration notes",
   acceptance: "Updated docs and migration guidance"}
])
```

### Rules

1. **Never edit more than 5 files in one batch.** Smaller batches = safer rollback.
2. **Run tests/lints between batches.** Capture their output as evidence per item.
3. **Keep the tree green after every commit.** No "I'll fix this later" commits.
4. **Plan checkpoint required** before any execution: `plan(action="checkpoint", summary="Refactor plan ready", ask_user=true)`.
5. **Finalize checkpoint required** before merge: explicit user confirmation.

### Anti-patterns

- ❌ Big-bang refactor with no intermediate checkpoints
- ❌ Skipping tests because "it's just a rename"
- ❌ Marking the plan done before docs are updated
