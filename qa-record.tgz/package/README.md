# qa-record

薄壳包装 `playwright codegen`，让 tester **一条命令**录制 webapp test case。

## 一次配置（工程师做）

```bash
npm install
cp qa.config.example.js qa.config.js
# 编辑 qa.config.js，填 baseURL、channel、loginCheck
```

## tester 只用记一条命令

```bash
npx qa-record <case-name>
```

- **首次运行** → 自动弹浏览器让你登录，登完关掉浏览器。
- **登录态还有效** → 直接跳到录制，浏览器打开就是登录状态。
- **登录态过期了** → 自动检测到，重新弹登录，然后再录制。
- **想强制重登**：`npx qa-record <case-name> --relogin`

录完关闭浏览器，脚本自动保存到 `tests/<case-name>.spec.ts`，把这个文件交出去就行。

## qa.config.js 示例

```js
module.exports = {
  baseURL: 'https://your-app.com',
  storageState: './auth.json',
  channel: 'chrome',                       // 用系统 Chrome
  loginCheck: { urlIncludes: '/login' },   // 打开首页被跳登录页 = 失效
};
```

## 常见问题

- **浏览器起不来 / profile 被锁**：完全退出你日常的 Chrome（Cmd+Q）再试。
- **登录有 SSO/MFA**：正常走完就行，Playwright 全程跟着。
- **auth.json 要不要提交**：不要，已在 `.gitignore`。
