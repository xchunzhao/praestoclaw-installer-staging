module.exports = {
  baseURL: 'https://staging.societas.microsoft.com',
  storageState: './auth.json',
  channel: 'chrome',          // 用系统 Chrome；或 'msedge'

  // 登录失效检测（三选一，都不填则不检测、信任本地 auth.json）
  loginCheck: {
    urlIncludes: '/login',    // 打开 baseURL 后被重定向到含 /login 的地址 = 失效
    // selector: '#user-avatar', // 或：登录后才会出现的元素存在 = 有效
  },
};
